# integration_api.py - API для связи между ботом, веб-аппом и админ панелью
import asyncio
import aiohttp
import requests
from datetime import datetime
import json
import os

class IntegrationAPI:
    """Класс для интеграции всех приложений SeoSerm"""
    
    def __init__(self):
        # URL всех приложений на Amvera
        self.bot_url = os.getenv("BOT_URL", "https://bot-angel2804.amvera.io")
        self.webapp_url = os.getenv("WEBAPP_URL", "https://seowebapp-angel2804.amvera.io") 
        self.admin_url = os.getenv("ADMIN_URL", "https://adminpanelseoserm-angel2804.amvera.io")
        
    def sync_notify_bot_submission_sent(self, user_id, task_title, submission_id):
        """Синхронное уведомление бота о отправке заявки"""
        try:
            requests.post(f"{self.bot_url}/api/submission_sent", json={
                'user_id': user_id,
                'task_title': task_title,
                'submission_id': submission_id
            }, timeout=5)
        except Exception as e:
            print(f"Ошибка уведомления бота (отправка): {e}")
    
    def sync_notify_bot_submission_approved(self, user_id, submission_id, reward_money, task_title='Задание'):
        """Синхронное уведомление бота об одобрении заявки"""
        try:
            requests.post(f"{self.bot_url}/api/submission_approved", json={
                'user_id': user_id,
                'submission_id': submission_id,
                'reward_money': float(reward_money),
                'reward_amount': float(reward_money),
                'task_title': task_title
            }, timeout=5)
        except Exception as e:
            print(f"Ошибка уведомления бота (одобрение): {e}")
    
    def sync_notify_bot_submission_rejected(self, user_id, submission_id, reason, task_title='Задание'):
        """Синхронное уведомление бота об отклонении заявки"""
        try:
            requests.post(f"{self.bot_url}/api/submission_rejected", json={
                'user_id': user_id,
                'submission_id': submission_id,
                'reason': reason,
                'task_title': task_title
            }, timeout=5)
        except Exception as e:
            print(f"Ошибка уведомления бота (отклонение): {e}")
    
    def sync_notify_admin_new_submission(self, submission_data):
        """Синхронное уведомление админ панели о новой заявке"""
        try:
            requests.post(f"{self.admin_url}/api/new_submission", json=submission_data, timeout=5)
        except Exception as e:
            print(f"Ошибка уведомления админ панели: {e}")
    
    def sync_notify_bot_new_task(self, task_id):
        """Синхронное уведомление бота о новом задании"""
        try:
            requests.post(f"{self.bot_url}/api/new_task", json={'task_id': task_id}, timeout=5)
        except Exception as e:
            print(f"Ошибка уведомления бота (новое задание): {e}")
    
    # Асинхронные версии для работы с aiogram
    async def async_notify_bot_submission_sent(self, user_id, task_title, submission_id):
        """Асинхронное уведомление бота о отправке заявки"""
        try:
            async with aiohttp.ClientSession() as session:
                await session.post(f"{self.bot_url}/api/submission_sent", json={
                    'user_id': user_id,
                    'task_title': task_title,
                    'submission_id': submission_id
                })
        except Exception as e:
            print(f"Ошибка асинхронного уведомления бота: {e}")
    
    async def async_notify_bot_submission_approved(self, user_id, submission_id, reward_money, task_title='Задание'):
        """Асинхронное уведомление бота об одобрении заявки"""
        try:
            async with aiohttp.ClientSession() as session:
                await session.post(f"{self.bot_url}/api/submission_approved", json={
                    'user_id': user_id,
                    'submission_id': submission_id,
                    'reward_money': float(reward_money),
                    'reward_amount': float(reward_money),
                    'task_title': task_title
                })
        except Exception as e:
            print(f"Ошибка асинхронного уведомления об одобрении: {e}")
    
    async def async_notify_bot_submission_rejected(self, user_id, submission_id, reason, task_title='Задание'):
        """Асинхронное уведомление бота об отклонении заявки"""
        try:
            async with aiohttp.ClientSession() as session:
                await session.post(f"{self.bot_url}/api/submission_rejected", json={
                    'user_id': user_id,
                    'submission_id': submission_id,
                    'reason': reason,
                    'task_title': task_title
                })
        except Exception as e:
            print(f"Ошибка асинхронного уведомления об отклонении: {e}")

# Создаем глобальный экземпляр API
integration_api = IntegrationAPI()

# Удобные функции для использования в приложениях
def notify_bot_submission_sent(user_id, task_title, submission_id):
    """Уведомить бот о отправке заявки (синхронно)"""
    integration_api.sync_notify_bot_submission_sent(user_id, task_title, submission_id)

def notify_bot_submission_approved(user_id, submission_id, reward_money, task_title='Задание'):
    """Уведомить бот об одобрении заявки (синхронно)"""
    integration_api.sync_notify_bot_submission_approved(user_id, submission_id, reward_money, task_title)

def notify_bot_submission_rejected(user_id, submission_id, reason, task_title='Задание'):
    """Уведомить бот об отклонении заявки (синхронно)"""
    integration_api.sync_notify_bot_submission_rejected(user_id, submission_id, reason, task_title)

def notify_admin_new_submission(submission_data):
    """Уведомить админ панель о новой заявке (синхронно)"""
    integration_api.sync_notify_admin_new_submission(submission_data)

def notify_bot_new_task(task_id):
    """Уведомить бот о новом задании (синхронно)"""
    integration_api.sync_notify_bot_new_task(task_id)

# Асинхронные версии для бота
async def async_notify_bot_submission_sent(user_id, task_title, submission_id):
    """Уведомить бот о отправке заявки (асинхронно)"""
    await integration_api.async_notify_bot_submission_sent(user_id, task_title, submission_id)

async def async_notify_bot_submission_approved(user_id, submission_id, reward_money, task_title='Задание'):
    """Уведомить бот об одобрении заявки (асинхронно)"""
    await integration_api.async_notify_bot_submission_approved(user_id, submission_id, reward_money, task_title)

async def async_notify_bot_submission_rejected(user_id, submission_id, reason, task_title='Задание'):
    """Уведомить бот об отклонении заявки (асинхронно)"""
    await integration_api.async_notify_bot_submission_rejected(user_id, submission_id, reason, task_title)
