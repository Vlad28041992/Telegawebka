// ==================== УЛУЧШЕННЫЙ COSMIC ADMIN PANEL JS ====================

// === ИНИЦИАЛИЗАЦИЯ ===
document.addEventListener('DOMContentLoaded', function() {
    initCosmicEffects();
    initNotificationSystem();
    initEnhancedAnimations();
    initParticleSystem();
    initStarField();
    initSupportBadgePolling();
    initKeyboardShortcuts();
    initNotificationCountersPolling();
    
    // Initialize Lucide icons
    if (window.lucide) {
        lucide.createIcons();
    }
});

// === КОСМИЧЕСКИЕ ЭФФЕКТЫ ===
function initCosmicEffects() {
    // Создаем плавающие частицы
    createFloatingParticles();
    
    // Запускаем звездное поле
    animateStarField();
    
    // Инициализируем hover эффекты
    initHoverEffects();
}

// === СИСТЕМА УВЕДОМЛЕНИЙ ===
let notificationQueue = [];
let notificationContainer = null;

function initNotificationSystem() {
    // Создаем контейнер для уведомлений
    notificationContainer = document.createElement('div');
    notificationContainer.id = 'notification-container';
    notificationContainer.className = 'fixed top-4 right-4 z-50 space-y-2';
    document.body.appendChild(notificationContainer);
}

// Улучшенная функция уведомлений
window.showNotification = function(message, type = 'info', duration = 4000) {
    const notification = document.createElement('div');
    const notificationId = 'notification-' + Date.now();
    
    const typeClasses = {
        'success': 'bg-gradient-to-r from-green-500/90 to-emerald-500/90 border-green-400/50',
        'error': 'bg-gradient-to-r from-red-500/90 to-rose-500/90 border-red-400/50',
        'warning': 'bg-gradient-to-r from-yellow-500/90 to-amber-500/90 border-yellow-400/50',
        'info': 'bg-gradient-to-r from-blue-500/90 to-cyan-500/90 border-blue-400/50'
    };
    
    const typeIcons = {
        'success': 'check-circle',
        'error': 'x-circle',
        'warning': 'alert-triangle',
        'info': 'info'
    };
    
    notification.id = notificationId;
    notification.className = `
        ${typeClasses[type]} 
        backdrop-blur-lg border rounded-xl p-4 shadow-lg max-w-sm 
        transform translate-x-full opacity-0 transition-all duration-500 ease-out
        hover:scale-105 cursor-pointer group
    `;
    
    notification.innerHTML = `
        <div class="flex items-center space-x-3">
            <div class="flex-shrink-0">
                <i data-lucide="${typeIcons[type]}" class="h-5 w-5 text-white group-hover:animate-pulse"></i>
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-white pr-2">${message}</p>
            </div>
            <button class="flex-shrink-0 ml-2 text-white/70 hover:text-white transition-colors duration-200" onclick="hideNotification('${notificationId}')">
                <i data-lucide="x" class="h-4 w-4"></i>
            </button>
        </div>
        <div class="absolute bottom-0 left-0 h-1 bg-white/30 rounded-full notification-progress"></div>
    `;
    
    notificationContainer.appendChild(notification);
    
    // Initialize Lucide icons for the notification
    if (window.lucide) {
        lucide.createIcons();
    }
    
    // Анимация появления
    requestAnimationFrame(() => {
        notification.classList.remove('translate-x-full', 'opacity-0');
        notification.classList.add('translate-x-0', 'opacity-100');
    });
    
    // Анимация прогресса
    const progressBar = notification.querySelector('.notification-progress');
    if (progressBar) {
        progressBar.style.transition = `width ${duration}ms linear`;
        progressBar.style.width = '100%';
        requestAnimationFrame(() => {
            progressBar.style.width = '0%';
        });
    }
    
    // Автоскрытие
    const timeoutId = setTimeout(() => {
        hideNotification(notificationId);
    }, duration);
    
    // Сохраняем ID таймера для возможной отмены
    notification.timeoutId = timeoutId;
    
    // Пауза при наведении
    notification.addEventListener('mouseenter', () => {
        clearTimeout(timeoutId);
        progressBar.style.animationPlayState = 'paused';
    });
    
    notification.addEventListener('mouseleave', () => {
        const remainingTime = duration * (parseFloat(progressBar.style.width) / 100);
        setTimeout(() => hideNotification(notificationId), remainingTime);
    });
    
    // Добавляем в очередь
    notificationQueue.push(notificationId);
    
    return notificationId;
};

// Скрытие уведомления
window.hideNotification = function(notificationId) {
    const notification = document.getElementById(notificationId);
    if (notification) {
        // Очищаем таймер если он есть
        if (notification.timeoutId) {
            clearTimeout(notification.timeoutId);
        }
        
        // Анимация исчезновения
        notification.classList.add('translate-x-full', 'opacity-0', 'scale-95');
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
            // Удаляем из очереди
            const index = notificationQueue.indexOf(notificationId);
            if (index > -1) {
                notificationQueue.splice(index, 1);
            }
        }, 500);
    }
};

// === УЛУЧШЕННЫЕ АНИМАЦИИ ===
function initEnhancedAnimations() {
    // Добавляем observer для анимаций при скролле
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    // Наблюдаем за всеми карточками
    document.querySelectorAll('.submission-card, .cosmic-card').forEach(el => {
        observer.observe(el);
    });
}

// === СИСТЕМА ЧАСТИЦ ===
function initParticleSystem() {
    const particlesContainer = document.getElementById('particles-container');
    if (!particlesContainer) return;
    
    function createParticle() {
        const particle = document.createElement('div');
        particle.className = 'cosmic-particle';
        
        // Случайные параметры
        const size = Math.random() * 3 + 1;
        const startX = Math.random() * window.innerWidth;
        const duration = Math.random() * 10 + 15;
        const delay = Math.random() * 5;
        
        particle.style.cssText = `
            left: ${startX}px;
            width: ${size}px;
            height: ${size}px;
            animation-duration: ${duration}s;
            animation-delay: ${delay}s;
            background: ${getRandomParticleColor()};
        `;
        
        particlesContainer.appendChild(particle);
        
        // Удаляем частицу после анимации
        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, (duration + delay) * 1000);
    }
    
    function getRandomParticleColor() {
        const colors = [
            'rgba(99, 102, 241, 0.8)',    // primary
            'rgba(139, 92, 246, 0.8)',    // secondary
            'rgba(236, 72, 153, 0.8)',    // accent
            'rgba(16, 185, 129, 0.8)',    // success
            'rgba(6, 182, 212, 0.8)',     // info
            'rgba(255, 255, 255, 0.6)'    // white
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    }
    
    // Создаем частицы с интервалом
    setInterval(createParticle, 2000);
    
    // Создаем начальные частицы
    for (let i = 0; i < 5; i++) {
        setTimeout(createParticle, i * 400);
    }
}

// === ЗВЕЗДНОЕ ПОЛЕ ===
function initStarField() {
    const canvas = document.getElementById('starfield');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    let stars = [];
    let animationId;
    
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        createStars();
    }
    
    function createStars() {
        stars = [];
        const numStars = Math.floor((canvas.width * canvas.height) / 8000);
        
        for (let i = 0; i < numStars; i++) {
            stars.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                size: Math.random() * 2,
                speed: Math.random() * 0.5 + 0.1,
                opacity: Math.random() * 0.8 + 0.2,
                twinkle: Math.random() * 0.02 + 0.01
            });
        }
    }
    
    function animateStars() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        stars.forEach(star => {
            // Мерцание
            star.opacity += Math.sin(Date.now() * star.twinkle) * 0.1;
            star.opacity = Math.max(0.1, Math.min(1, star.opacity));
            
            // Движение
            star.y += star.speed;
            if (star.y > canvas.height) {
                star.y = -5;
                star.x = Math.random() * canvas.width;
            }
            
            // Отрисовка
            ctx.beginPath();
            ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
            ctx.fill();
            
            // Добавляем свечение для больших звезд
            if (star.size > 1.5) {
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.size * 2, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(99, 102, 241, ${star.opacity * 0.3})`;
                ctx.fill();
            }
        });
        
        animationId = requestAnimationFrame(animateStars);
    }
    
    // Инициализация
    resizeCanvas();
    animateStars();
    
    // Обработка изменения размера окна
    window.addEventListener('resize', resizeCanvas);
    
    // Останавливаем анимацию при скрытии страницы
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            cancelAnimationFrame(animationId);
        } else {
            animateStars();
        }
    });
}

function animateStarField() {
    // Эта функция оставлена для совместимости
    initStarField();
    initSupportBadgePolling();
}

// === HOVER ЭФФЕКТЫ ===
function initHoverEffects() {
    // Эффект ripple для кнопок
    document.addEventListener('click', function(e) {
        const button = e.target.closest('.cosmic-button-improved, .cosmic-button-secondary-improved, .cosmic-button-approve, .cosmic-button-reject');
        if (button) {
            createRippleEffect(button, e);
        }
    });
    
    // Параллакс эффект для карточек
    document.addEventListener('mousemove', function(e) {
        const cards = document.querySelectorAll('.submission-card:hover');
        cards.forEach(card => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            
            const rotateX = (y / rect.height) * 10;
            const rotateY = (x / rect.width) * -10;
            
            card.style.transform = `
                translateY(-12px) 
                rotateX(${rotateX}deg) 
                rotateY(${rotateY}deg)
                scale(1.02)
            `;
        });
    });
    
    // Сброс трансформации при уходе мыши
    document.addEventListener('mouseleave', function(e) {
        if (e.target.classList.contains('submission-card')) {
            e.target.style.transform = '';
        }
    });
}

// Создание ripple эффекта
function createRippleEffect(element, event) {
    const rect = element.getBoundingClientRect();
    const ripple = document.createElement('div');
    
    ripple.className = 'ripple-effect';
    ripple.style.cssText = `
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.3);
        pointer-events: none;
        transform: scale(0);
        animation: ripple 0.6s linear;
        left: ${event.clientX - rect.left - 10}px;
        top: ${event.clientY - rect.top - 10}px;
        width: 20px;
        height: 20px;
    `;
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// CSS для ripple анимации (добавляется динамически)
const rippleCSS = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;

const style = document.createElement('style');
style.textContent = rippleCSS;
document.head.appendChild(style);

// === ПЛАВАЮЩИЕ ЧАСТИЦЫ ===
function createFloatingParticles() {
    const container = document.getElementById('particles-container');
    if (!container) return;
    
    function addParticle() {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: absolute;
            width: 4px;
            height: 4px;
            background: radial-gradient(circle, rgba(99, 102, 241, 0.8) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            left: ${Math.random() * 100}%;
            animation: float-up ${8 + Math.random() * 4}s linear infinite;
        `;
        
        container.appendChild(particle);
        
        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, 12000);
    }
    
    // Добавляем CSS для анимации
    const floatCSS = `
        @keyframes float-up {
            0% {
                transform: translateY(100vh) translateX(0px) rotate(0deg);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(${Math.random() * 200 - 100}px) rotate(360deg);
                opacity: 0;
            }
        }
    `;
    
    if (!document.getElementById('float-particles-css')) {
        const style = document.createElement('style');
        style.id = 'float-particles-css';
        style.textContent = floatCSS;
        document.head.appendChild(style);
    }
    
    // Создаем частицы с интервалом
    setInterval(addParticle, 3000);
}

// === КЛАВИАТУРНЫЕ СОЧЕТАНИЯ ===
function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + Enter для обновления
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            const refreshBtn = document.querySelector('.refresh-btn');
            if (refreshBtn) {
                refreshBtn.click();
            }
        }
        
        // Ctrl/Cmd + D для экспорта
        if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
            e.preventDefault();
            const exportBtn = document.querySelector('.export-btn');
            if (exportBtn) {
                exportBtn.click();
            }
        }
        
        // Escape для закрытия модальных окон
        if (e.key === 'Escape') {
            // Закрываем все модальные окна
            document.querySelectorAll('.modal-container').forEach(modal => {
                if (!modal.classList.contains('hidden')) {
                    modal.classList.add('hidden');
                }
            });
            
            // Закрываем уведомления
            notificationQueue.forEach(id => hideNotification(id));
        }
    });
}

// === LAZY LOADING ДЛЯ ИЗОБРАЖЕНИЙ ===
function initLazyLoading() {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// === ПРОИЗВОДИТЕЛЬНОСТЬ ===
// Throttle функция для оптимизации
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Debounce функция для оптимизации
function debounce(func, wait, immediate) {
    let timeout;
    return function() {
        const context = this, args = arguments;
        const later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
}

// === УТИЛИТЫ ===
// Функция для создания случайного ID
function generateId() {
    return 'id-' + Math.random().toString(36).substr(2, 9);
}

// Функция для проверки поддержки браузером
function supportsFeature(feature) {
    const features = {
        'backdrop-filter': CSS.supports('backdrop-filter', 'blur(1px)'),
        'intersection-observer': 'IntersectionObserver' in window,
        'requestAnimationFrame': 'requestAnimationFrame' in window
    };
    
    return features[feature] !== undefined ? features[feature] : true;
}

// === ЭКСПОРТ ФУНКЦИЙ ===
window.CosmicAdmin = {
    showNotification: window.showNotification,
    hideNotification: window.hideNotification,
    throttle,
    debounce,
    generateId,
    supportsFeature
};

// === ОБРАБОТКА ОШИБОК ===
window.addEventListener('error', function(e) {
    console.error('Cosmic Admin Error:', e.error);
    if (window.showNotification) {
        window.showNotification('Произошла ошибка в системе', 'error');
    }
});

// === ОПТИМИЗАЦИЯ ПАМЯТИ ===
// Очистка при выгрузке страницы
window.addEventListener('beforeunload', function() {
    // Очищаем таймеры уведомлений
    notificationQueue.forEach(id => {
        const notification = document.getElementById(id);
        if (notification && notification.timeoutId) {
            clearTimeout(notification.timeoutId);
        }
    });
    
    // Очищаем observers
    if (window.intersectionObserver) {
        window.intersectionObserver.disconnect();
    }
});

// === ACCESSIBILITY ===
// Поддержка навигации с клавиатуры
document.addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
    }
});

document.addEventListener('mousedown', function() {
    document.body.classList.remove('keyboard-navigation');
});

// === ФИНАЛЬНАЯ ИНИЦИАЛИЗАЦИЯ ===
document.addEventListener('DOMContentLoaded', function() {
    // Добавляем класс для CSS
    document.body.classList.add('cosmic-admin-loaded');
    
    // Показываем приветственное уведомление
    setTimeout(() => {
        if (window.showNotification) {
            window.showNotification('🚀 Cosmic Admin Panel загружен!', 'success');
        }
    }, 1000);
    
    // Инициализируем lazy loading
    initLazyLoading();
    
    console.log('🚀 Cosmic Admin Panel v2.0 initialized successfully!');
});

// ==================== SEOSERM ADMIN PANEL EXTENSIONS ====================

// === ФУНКЦИЯ СОХРАНЕНИЯ НАСТРОЕК ===
function saveSettings() {
    // Показываем индикатор загрузки
    showNotification('Сохранение настроек...', 'info');
    
    // Собираем все данные из форм
    const formData = new FormData();
    
    // Получаем все input элементы на странице
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        if (input.name) {
            if (input.type === 'checkbox') {
                formData.append(input.name, input.checked);
            } else {
                formData.append(input.name, input.value);
            }
        }
    });
    
    // Симуляция отправки данных на сервер
    setTimeout(() => {
        showNotification('✅ Настройки успешно сохранены!', 'success');
        
        // Добавляем визуальный эффект
        const button = document.querySelector('.seoserm-btn-primary');
        if (button) {
            button.style.transform = 'scale(0.95)';
            setTimeout(() => {
                button.style.transform = 'scale(1)';
            }, 150);
        }
    }, 1000);
}

// === УЛУЧШЕННАЯ СИСТЕМА УВЕДОМЛЕНИЙ ===
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${icons[type] || icons.info}</span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Добавляем стили для уведомления
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            max-width: 400px;
            padding: 16px 20px;
            border-radius: 12px;
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideInRight 0.3s ease-out;
        }
        
        .notification-success {
            background: rgba(16, 185, 129, 0.9);
        }
        
        .notification-error {
            background: rgba(239, 68, 68, 0.9);
        }
        
        .notification-warning {
            background: rgba(245, 158, 11, 0.9);
        }
        
        .notification-info {
            background: rgba(59, 130, 246, 0.9);
        }
        
        .notification-content {
            display: flex;
            align-items: center;
            color: white;
            font-weight: 500;
        }
        
        .notification-icon {
            margin-right: 12px;
            font-size: 18px;
        }
        
        .notification-message {
            flex: 1;
            font-size: 14px;
        }
        
        .notification-close {
            background: none;
            border: none;
            color: rgba(255, 255, 255, 0.7);
            font-size: 20px;
            cursor: pointer;
            margin-left: 12px;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .notification-close:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    
    if (!document.querySelector('#notification-styles')) {
        style.id = 'notification-styles';
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Автоматически убираем уведомление через 5 секунд
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideInRight 0.3s ease-out reverse';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// === УЛУЧШЕНИЕ КНОПОК ===
document.addEventListener('DOMContentLoaded', function() {
    // Заменяем все старые кнопки на новые стили
    const buttons = document.querySelectorAll('button:not(.seoserm-btn-primary):not(.seoserm-btn-secondary)');
    buttons.forEach(button => {
        if (!button.classList.contains('notification-close')) {
            button.classList.add('seoserm-btn-secondary');
        }
    });
    
    // Добавляем ripple эффект для кнопок
    const rippleButtons = document.querySelectorAll('.seoserm-btn-primary, .seoserm-btn-secondary');
    rippleButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.3);
                transform: scale(0);
                animation: ripple 0.6s linear;
                left: ${x}px;
                top: ${y}px;
                width: ${size}px;
                height: ${size}px;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
    
    // Добавляем CSS для ripple эффекта
    const rippleStyle = document.createElement('style');
    rippleStyle.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(rippleStyle);
});

// === СКРЫТИЕ СИСТЕМНЫХ ОШИБОК ===
function hideSystemErrors() {
    const errorElements = document.querySelectorAll('.error, .alert-error, [class*="error"]');
    errorElements.forEach(element => {
        if (element.textContent.includes('Системная ошибка') || 
            element.textContent.includes('система ошибка') ||
            element.textContent.includes('System Error')) {
            element.style.display = 'none';
        }
    });
}

// Запускаем скрытие ошибок при загрузке и через интервалы
document.addEventListener('DOMContentLoaded', hideSystemErrors);
setInterval(hideSystemErrors, 1000);

// === УЛУЧШЕНИЕ ПРОКРУТКИ ===
document.addEventListener('DOMContentLoaded', function() {
    // Добавляем плавную прокрутку ко всем элементам
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Добавляем кастомную прокрутку к основным контейнерам
    const scrollContainers = document.querySelectorAll('.main-content, main, .overflow-y-auto');
    scrollContainers.forEach(container => {
        container.classList.add('custom-scrollbar');
    });
});

// Автоскрытие приветственного блока через 5 секунд с анимацией
document.addEventListener('DOMContentLoaded', function() {

// Переопределяем функцию показа уведомлений чтобы не показывать системные ошибки
const originalShowNotification = window.showNotification;
window.showNotification = function(message, type = 'info', duration = 4000) {
    // Блокируем системные ошибки
    if (message.includes('Произошла ошибка в системе') || 
        message.includes('система') || 
        type === 'error') {
        return;
    }
    
    if (originalShowNotification) {
        originalShowNotification(message, type, duration);
    } else {
        // Базовая реализация если оригинальной нет
        console.log(`[${type.toUpperCase()}] ${message}`);
    }
};

// Убираем все существующие системные уведомления при загрузке
document.addEventListener('DOMContentLoaded', function() {
    const errorNotifications = document.querySelectorAll('.notification, .alert, .toast');
    errorNotifications.forEach(notification => {
        const text = notification.textContent || notification.innerText;
        if (text.includes('Произошла ошибка в системе') || 
            text.includes('система') ||
            text.toLowerCase().includes('error')) {
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    });
});



// === СИСТЕМА УВЕДОМЛЕНИЙ ===
function showNotification(message, type = 'success') {
    // Удаляем существующие уведомления
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Создаем новое уведомление
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Автоматически удаляем через 5 секунд
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Пример использования уведомлений
window.showNotification = showNotification;




// ==================== EPIC WELCOME BLOCK JAVASCRIPT ==================== 

// Инициализация эпичного welcome блока
document.addEventListener('DOMContentLoaded', function() {
    initEpicWelcomeBlock();
});

function initEpicWelcomeBlock() {
    const welcomeBlock = document.getElementById('welcome-block');
    if (!welcomeBlock) return;
    
    // Добавляем дополнительные эффекты при загрузке
    welcomeBlock.style.transform = 'scale(0.9) rotateY(-5deg)';
    welcomeBlock.style.opacity = '0';
    
    // Плавное появление
    setTimeout(() => {
        welcomeBlock.style.transition = 'all 1.5s cubic-bezier(0.68, -0.55, 0.265, 1.55)';
        welcomeBlock.style.transform = 'scale(1) rotateY(0deg)';
        welcomeBlock.style.opacity = '1';
    }, 500);
    
    // Создаем дополнительные интерактивные звезды
    createInteractiveStars(welcomeBlock);
    
    // Запускаем счетчик и эпичное исчезновение
    startEpicCountdown(welcomeBlock);
    
    // Добавляем hover эффекты мыши
    addMouseEffects(welcomeBlock);
}

// Создание интерактивных звезд
function createInteractiveStars(container) {
    const starsContainer = container.querySelector('.stars-field');
    if (!starsContainer) return;
    
    // Добавляем еще звезд для интерактивности
    for (let i = 11; i <= 20; i++) {
        const star = document.createElement('div');
        star.className = `star star-${i}`;
        star.style.width = Math.random() * 3 + 1 + 'px';
        star.style.height = star.style.width;
        star.style.top = Math.random() * 100 + '%';
        star.style.left = Math.random() * 100 + '%';
        star.style.animationDelay = Math.random() * 3 + 's';
        star.style.animationDuration = Math.random() * 2 + 1 + 's';
        starsContainer.appendChild(star);
    }
}

// Эффекты мыши
function addMouseEffects(container) {
    container.addEventListener('mousemove', (e) => {
        const rect = container.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        
        // Небольшой наклон в зависимости от позиции мыши
        const rotateY = (x - 0.5) * 10;
        const rotateX = (y - 0.5) * -5;
        
        container.style.transform = `perspective(1000px) rotateY(${rotateY}deg) rotateX(${rotateX}deg) scale(1.02)`;
        
        // Интерактивные звезды
        const stars = container.querySelectorAll('.star');
        stars.forEach((star, index) => {
            const factor = (index % 3 + 1) * 0.3;
            star.style.transform = `translate(${(x - 0.5) * 20 * factor}px, ${(y - 0.5) * 10 * factor}px) scale(${1 + factor * 0.5})`;
        });
    });
    
    container.addEventListener('mouseleave', () => {
        container.style.transform = 'perspective(1000px) rotateY(0deg) rotateX(0deg) scale(1)';
        
        const stars = container.querySelectorAll('.star');
        stars.forEach(star => {
            star.style.transform = 'translate(0px, 0px) scale(1)';
        });
    });
}

// Эпичный countdown с анимацией исчезновения
function startEpicCountdown(welcomeBlock) {
    // Создаем счетчик в углу блока
    const countdown = document.createElement('div');
    countdown.className = 'welcome-countdown';
    countdown.style.cssText = `
        position: absolute;
        top: 15px;
        right: 20px;
        background: rgba(0, 0, 0, 0.7);
        color: #10b981;
        padding: 8px 15px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        border: 1px solid rgba(16, 185, 129, 0.3);
        backdrop-filter: blur(10px);
        z-index: 20;
        animation: countdownPulse 1s ease-in-out infinite;
    `;
    
    welcomeBlock.appendChild(countdown);
    
    let timeLeft = 5;
    
    const updateCountdown = () => {
        countdown.textContent = `Исчезнет через ${timeLeft}с`;
        if (timeLeft <= 3) {
            countdown.style.color = '#ef4444';
            countdown.style.borderColor = 'rgba(239, 68, 68, 0.3)';
            countdown.style.animation = 'countdownPulse 0.5s ease-in-out infinite';
        }
    };
    
    updateCountdown();
    
    const countdownInterval = setInterval(() => {
        timeLeft--;
        updateCountdown();
        
        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
            startEpicDisappearance(welcomeBlock);
        }
    }, 1000);
    
    // Добавляем стили для анимации countdown
    const style = document.createElement('style');
    style.textContent = `
        @keyframes countdownPulse {
            0%, 100% { transform: scale(1); opacity: 0.8; }
            50% { transform: scale(1.1); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
}

// Эпичное исчезновение
function startEpicDisappearance(welcomeBlock) {
    // Добавляем pre-fade эффекты
    const title = welcomeBlock.querySelector('.epic-welcome-title');
    const subtitle = welcomeBlock.querySelector('.welcome-subtitle');
    const stars = welcomeBlock.querySelectorAll('.star');
    const particles = welcomeBlock.querySelectorAll('.particle');
    const rays = welcomeBlock.querySelectorAll('.ray');
    
    // Ускоряем анимации перед исчезновением
    stars.forEach(star => {
        star.style.animationDuration = '0.5s';
    });
    
    particles.forEach(particle => {
        particle.style.animationDuration = '1s';
        particle.style.transform = 'translateY(-100px) scale(2)';
        particle.style.opacity = '0';
    });
    
    rays.forEach(ray => {
        ray.style.animationDuration = '2s';
    });
    
    // Основная анимация исчезновения
    welcomeBlock.classList.add('welcome-fade-out');
    
    // Дополнительные эффекты для заголовка
    if (title) {
        setTimeout(() => {
            title.style.animation = 'epicTitleDisappear 1.5s cubic-bezier(0.68, -0.55, 0.265, 1.55) forwards';
        }, 200);
    }
    
    if (subtitle) {
        setTimeout(() => {
            subtitle.style.animation = 'subtitleFadeOut 1s ease-out forwards';
        }, 400);
    }
    
    // Полное удаление блока
    setTimeout(() => {
        welcomeBlock.style.display = 'none';
        welcomeBlock.remove();
    }, 2000);
    
    // Добавляем стили для анимаций исчезновения
    if (!document.getElementById('epic-disappear-styles')) {
        const disappearStyles = document.createElement('style');
        disappearStyles.id = 'epic-disappear-styles';
        disappearStyles.textContent = `
            @keyframes epicTitleDisappear {
                0% {
                    transform: translateY(0) scale(1) rotateY(0deg);
                    opacity: 1;
                    filter: blur(0px);
                }
                50% {
                    transform: translateY(-20px) scale(1.1) rotateY(10deg);
                    opacity: 0.5;
                    filter: blur(2px);
                }
                100% {
                    transform: translateY(-100px) scale(0.5) rotateY(45deg);
                    opacity: 0;
                    filter: blur(10px);
                }
            }
            
            @keyframes subtitleFadeOut {
                0% {
                    opacity: 1;
                    transform: translateY(0);
                }
                100% {
                    opacity: 0;
                    transform: translateY(20px);
                }
            }
        `;
        document.head.appendChild(disappearStyles);
    }
    
    // Создаем финальный взрыв частиц
    createFinalParticleExplosion(welcomeBlock);
}

// Финальный взрыв частиц
function createFinalParticleExplosion(container) {
    const rect = container.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: fixed;
            width: 4px;
            height: 4px;
            background: radial-gradient(circle, #${['6366f1', '8b5cf6', '10b981', 'ec4899', '06b6d4'][i % 5]} 0%, transparent 70%);
            border-radius: 50%;
            left: ${centerX}px;
            top: ${centerY}px;
            z-index: 9999;
            pointer-events: none;
        `;
        
        const angle = (i / 15) * 2 * Math.PI;
        const velocity = 100 + Math.random() * 100;
        const lifetime = 1000 + Math.random() * 500;
        
        document.body.appendChild(particle);
        
        // Анимация частицы
        const startTime = Date.now();
        const animate = () => {
            const elapsed = Date.now() - startTime;
            const progress = elapsed / lifetime;
            
            if (progress >= 1) {
                particle.remove();
                return;
            }
            
            const x = centerX + Math.cos(angle) * velocity * progress;
            const y = centerY + Math.sin(angle) * velocity * progress + 0.5 * 200 * progress * progress; // гравитация
            const opacity = 1 - progress;
            
            particle.style.left = x + 'px';
            particle.style.top = y + 'px';
            particle.style.opacity = opacity;
            particle.style.transform = `scale(${1 - progress * 0.5})`;
            
            requestAnimationFrame(animate);
        };
        
        requestAnimationFrame(animate);
    }
}

// Добавляем возможность клика для принудительного скрытия
document.addEventListener('DOMContentLoaded', function() {
    const welcomeBlock = document.getElementById('welcome-block');
    if (welcomeBlock) {
        // Добавляем кнопку закрытия
        const closeButton = document.createElement('button');
        closeButton.innerHTML = '✕';
        closeButton.style.cssText = `
            position: absolute;
            top: 15px;
            left: 20px;
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            z-index: 20;
            font-size: 14px;
            font-weight: bold;
        `;
        
        closeButton.addEventListener('mouseenter', () => {
            closeButton.style.background = 'rgba(239, 68, 68, 0.4)';
            closeButton.style.transform = 'scale(1.1)';
        });
        
        closeButton.addEventListener('mouseleave', () => {
            closeButton.style.background = 'rgba(239, 68, 68, 0.2)';
            closeButton.style.transform = 'scale(1)';
        });
        
        closeButton.addEventListener('click', () => {
            startEpicDisappearance(welcomeBlock);
        });
        
        welcomeBlock.appendChild(closeButton);
    }
});


// === ИНИЦИАЛИЗАЦИЯ ГРАФИКОВ ===
function initCharts() {
    if (window.location.pathname === '/' || window.location.pathname === '/dashboard') {
        setTimeout(() => {
            loadDailySubmissionsChart();
            loadPlatformChart();
        }, 500);
    }
}

function loadDailySubmissionsChart() {
    const canvas = document.getElementById('dailySubmissionsChart');
    if (!canvas) return;
    
    fetch('/api/stats/daily_submissions?days=7')
        .then(response => response.json())
        .then(data => {
            const ctx = canvas.getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Одобренные',
                        data: data.approved,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.4,
                        fill: true
                    }, {
                        label: 'Отклоненные',
                        data: data.rejected,
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#e5e7eb' } }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { color: '#9ca3af' },
                            grid: { color: 'rgba(75, 85, 99, 0.3)' }
                        },
                        x: {
                            ticks: { color: '#9ca3af' },
                            grid: { color: 'rgba(75, 85, 99, 0.3)' }
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Ошибка загрузки графика:', error));
}

function loadPlatformChart() {
    const canvas = document.getElementById('platformChart');
    if (!canvas) return;
    
    fetch('/api/stats/platform_distribution')
        .then(response => response.json())
        .then(data => {
            const ctx = canvas.getContext('2d');
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: data.labels,
                    datasets: [{
                        data: data.counts,
                        backgroundColor: [
                            '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b',
                            '#ef4444', '#ec4899', '#6366f1', '#84cc16'
                        ],
                        borderWidth: 2,
                        borderColor: '#1e293b'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { color: '#e5e7eb', padding: 20 }
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Ошибка загрузки графика:', error));
}

// Добавляем инициализацию в DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    // ... существующий код ...
    initCharts();
});


// === Support badge polling ===
function initSupportBadgePolling() {
    let lastSupportUnread = null;
    const badge = document.getElementById('support-unread-badge');
    if (!badge) return;
    const update = () => {
        fetch('/api/support/notifications/count', {credentials: 'same-origin'})
          .then(r => r.json())
          .then(d => {
              const n = (d && d.success) ? (d.unread || 0) : 0;
              if (badge) {
                  if (n > 0) {
                      badge.textContent = n > 99 ? '99+' : n;
                      badge.classList.remove('hidden');
                  } else {
                      badge.classList.add('hidden');
                      badge.textContent = '';
                  }
              }
              if (lastSupportUnread !== null && n > lastSupportUnread) {
                  showNotification(`Новые сообщения в поддержке: +${n - lastSupportUnread}`, 'info');
              }
              lastSupportUnread = n;
          })
          .catch(() => {});
    };
    update();
    setInterval(update, 10000);
}


function initNotificationCountersPolling() {
    const submissionsBadge = document.getElementById('submissions-badge');
    const payoutsBadge = document.getElementById('payouts-badge');
    let lastTotals = {submissions: null, payouts: null};
    const update = () => {
        fetch('/api/notifications/count', {credentials: 'same-origin'})
          .then(r => r.json())
          .then(d => {
              if (!d || !d.success) return;
              const s = d.submissions || 0;
              const p = d.payouts || 0;
              if (submissionsBadge) {
                  if (s > 0) { submissionsBadge.textContent = s > 99 ? '99+' : s; submissionsBadge.classList.remove('hidden'); }
                  else { submissionsBadge.classList.add('hidden'); submissionsBadge.textContent = ''; }
              }
              if (payoutsBadge) {
                  if (p > 0) { payoutsBadge.textContent = p > 99 ? '99+' : p; payoutsBadge.classList.remove('hidden'); }
                  else { payoutsBadge.classList.add('hidden'); payoutsBadge.textContent = ''; }
              }
              if (lastTotals.submissions !== null && s > lastTotals.submissions) {
                  showNotification(`Новые заявки на проверку: +${s - lastTotals.submissions}`, 'info');
              }
              if (lastTotals.payouts !== null && p > lastTotals.payouts) {
                  showNotification(`Новые запросы на выплату: +${p - lastTotals.payouts}`, 'info');
              }
              lastTotals = {submissions: s, payouts: p};
          })
          .catch(() => {});
    };
    update();
    setInterval(update, 12000);
}
