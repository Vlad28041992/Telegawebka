import os
import datetime
import hashlib
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func, case, desc, and_, or_, cast, String, distinct
from sqlalchemy.exc import IntegrityError
import json
import requests
import csv
import io
from datetime import timedelta, datetime
from flask import send_from_directory
import requests
import logging



from sqlalchemy import desc

# --- ИНИЦИАЛИЗАЦИЯ ПРИЛОЖЕНИЯ И КОНФИГУРАЦИЯ ---


# ИСПРАВЛЕННЫЕ ФУНКЦИИ ДЛЯ РАБОТЫ С ТЕКСТАМИ ОТЗЫВОВ

def reset_assigned_review_texts():
    """
    Сбрасывает статус assigned текстов, которые висят слишком долго без использования
    """
    try:
        from sqlalchemy import text as _sqltext
        from datetime import datetime, timedelta
        
        # Сбрасываем тексты, которые assigned более 2 часов назад
        cutoff_time = datetime.utcnow() - timedelta(hours=2)
        
        sql = _sqltext("""
            UPDATE task_review_texts 
            SET status = 'free', assigned_user_id = NULL, assigned_at = NULL
            WHERE status = 'assigned' AND assigned_at < :cutoff_time
        """)
        
        result = db.session.execute(sql, {'cutoff_time': cutoff_time})
        db.session.commit()
        
        return result.rowcount
    except Exception as e:
        try:
            db.session.rollback()
        except:
            pass
        print(f'Error resetting assigned texts: {e}')
        return 0

def get_review_texts_stats(task_id=None):
    """
    Получает статистику по текстам отзывов
    """
    try:
        from sqlalchemy import text as _sqltext, func
        
        if task_id:
            # Статистика для конкретного задания
            stats = db.session.query(
                TaskReviewText.status,
                func.count(TaskReviewText.id).label('count')
            ).filter_by(task_id=task_id).group_by(TaskReviewText.status).all()
        else:
            # Общая статистика
            stats = db.session.query(
                TaskReviewText.status,
                func.count(TaskReviewText.id).label('count')
            ).group_by(TaskReviewText.status).all()
        
        return {stat.status: stat.count for stat in stats}
    except Exception as e:
        print(f'Error getting review texts stats: {e}')
        return {}

def get_next_review_text(user_id, task_id):
    """
    Получает следующий свободный текст отзыва для пользователя и задания
    """
    try:
        # Сначала сбрасываем зависшие assigned тексты
        reset_assigned_review_texts()
        
        # Ищем свободный текст для данного задания
        text = TaskReviewText.query.filter_by(
            task_id=task_id,
            status='free'
        ).first()
        
        if text:
            # Помечаем текст как назначенный
            text.status = 'assigned'
            text.assigned_user_id = user_id
            text.assigned_at = datetime.utcnow()
            db.session.commit()
            
            return text.text
        else:
            return None
            
    except Exception as e:
        try:
            db.session.rollback()
        except:
            pass
        print(f'Error getting review text: {e}')
        return None

def mark_review_text_as_used(user_id, task_id, review_text_str):
    """
    Помечает текст отзыва как использованный
    """
    try:
        text = TaskReviewText.query.filter_by(
            task_id=task_id,
            text=review_text_str,
            assigned_user_id=user_id
        ).first()
        
        if text:
            text.status = 'used'
            text.used_at = datetime.utcnow()
            db.session.commit()
            return True
    except Exception as e:
        try:
            db.session.rollback()
        except:
            pass
        print(f'Error marking text as used: {e}')
    return False

def check_and_auto_delete_completed_tasks():
    """Автоматически удаляет задания когда их лимит достигнут (0 оставшихся выполнений)"""
    try:
        # Находим все активные задания с лимитом
        completed_tasks = Task.query.filter(
            Task.is_active == True,
            Task.submission_limit.isnot(None),
            Task.submission_limit > 0
        ).all()
        
        deleted_count = 0
        for task in completed_tasks:
            current_submissions = Submission.query.filter_by(task_id=task.id).count()
            
            # Если количество выполнений достигло лимита
            if current_submissions >= task.submission_limit:
                # Проверяем есть ли pending submissions (в ожидании проверки)
                pending_submissions = Submission.query.filter_by(
                    task_id=task.id, 
                    status='pending'
                ).count()
                
                if pending_submissions == 0:
                    # Если нет pending submissions - можно удалять задание
                    # НО НЕ УДАЛЯЕМ APPROVED/REJECTED submissions - они должны остаться
                    task.is_active = False
                    task.status = 'completed'
                    deleted_count += 1
                    log_action('AUTO_DELETE', 'task', task.id, f'Задание автоматически завершено (лимит {task.submission_limit} достигнут)')
        
        if deleted_count > 0:
            db.session.commit()
            logging.info(f"Автоматически завершено {deleted_count} заданий")
        
        return deleted_count
    except Exception as e:
        logging.error(f"Ошибка при автоматическом завершении заданий: {e}")
        db.session.rollback()
        return 0

# === Owner/Partner helpers ===
PRESET_PARTNERS = ['Нытик', 'Эдик', 'Месячник', 'Алекс']

def get_partners_list():
    try:
        vals = [v[0] for v in db.session.query(distinct(Task.direction)).filter(
            and_(Task.direction.isnot(None), Task.direction != '')
        ).all()]
        vals = [v.strip() for v in vals if v and isinstance(v, str) and v.strip()]
        others = sorted([v for v in vals if v not in PRESET_PARTNERS], key=lambda s: s.lower())
        return PRESET_PARTNERS + others
    except Exception:
        return PRESET_PARTNERS

app = Flask(__name__)

@app.context_processor
def inject_screenshot_src():
    def screenshot_src(filename):
        if not filename:
            return '/static/images/placeholder.jpg'
        webapp_url = os.environ.get('WEBAPP_URL', 'https://seowebapp-angel2804.amvera.io')
        return f"{webapp_url}/static/uploads/{filename}"
    return dict(screenshot_src=screenshot_src)




@app.context_processor
def endpoint_utilities():
    def endpoint_exists(name):
        try:
            url_for(name)
            return True
        except Exception:
            return False
    return dict(endpoint_exists=endpoint_exists)


# === ИСПРАВЛЕННЫЕ Helpers для шаблонов (правильный резолвер screenshot URL) ===
@app.context_processor
def template_helpers():
    import os
    # ИСПРАВЛЕНО: Используем правильный URL веб-приложения
    WEBAPP_URL = os.environ.get('WEBAPP_URL', 'https://seowebapp-angel2804.amvera.io')
    
    def screenshot_src(submission):
        try:
            url = getattr(submission, 'screenshot_url', None) or ''
            if not url:
                return ''
            # Если URL уже полный - возвращаем как есть
            if url.startswith('http://') or url.startswith('https://'):
                return url
            # ИСПРАВЛЕНО: Правильно формируем URL для статических файлов
            return f"{WEBAPP_URL}/static/uploads/{url}"
        except Exception as e:
            print(f"Error in screenshot_src: {e}")
            return ''
    
    return dict(screenshot_src=screenshot_src)

# === Owner/Partner helpers ===
PRESET_PARTNERS = ['Нытик', 'Эдик', 'Месячник', 'Алекс']

def get_partners_list():
    try:
        vals = [v[0] for v in db.session.query(distinct(Task.direction)).filter(
            or_(Task.direction.isnot(None), Task.direction != '')
        ).all()]
        vals = [v.strip() for v in vals if v and isinstance(v, str) and v.strip()]
        others = sorted([v for v in vals if v not in PRESET_PARTNERS], key=lambda s: s.lower())
        return PRESET_PARTNERS + others
    except Exception:
        return PRESET_PARTNERS


def check_and_auto_delete_completed_tasks():
    """Автоматически удаляет задания когда их лимит достигнут (0 оставшихся выполнений)"""
    try:
        # Находим все активные задания с лимитом
        completed_tasks = Task.query.filter(
            Task.is_active == True,
            Task.submission_limit.isnot(None),
            Task.submission_limit > 0
        ).all()
        
        deleted_count = 0
        for task in completed_tasks:
            current_submissions = Submission.query.filter_by(task_id=task.id).count()
            
            # Если количество выполнений достигло лимита
            if current_submissions >= task.submission_limit:
                # Проверяем есть ли pending submissions (в ожидании проверки)
                pending_submissions = Submission.query.filter_by(
                    task_id=task.id, 
                    status='pending'
                ).count()
                
                if pending_submissions == 0:
                    # Если нет pending submissions - можно удалять задание
                    # НО НЕ УДАЛЯЕМ APPROVED/REJECTED submissions - они должны остаться
                    task.is_active = False
                    task.status = 'completed'
                    deleted_count += 1
                    log_action('AUTO_DELETE', 'task', task.id, f'Задание автоматически завершено (лимит {task.submission_limit} достигнут)')
        
        if deleted_count > 0:
            db.session.commit()
            logging.info(f"Автоматически завершено {deleted_count} заданий")
        
        return deleted_count
    except Exception as e:
        logging.error(f"Ошибка при автоматическом завершении заданий: {e}")
        db.session.rollback()
        return 0

@app.route('/debug/screenshots')
@login_required
def debug_screenshots():
    """Страница отладки скриншотов для проверки доступности изображений"""
    submissions_with_screenshots = Submission.query.filter(
        Submission.screenshot_url.isnot(None), 
        Submission.screenshot_url != ''
    ).order_by(desc(Submission.submission_time)).limit(20).all()
    
    debug_info = []
    webapp_url = os.environ.get('WEBAPP_URL', 'https://seowebapp-angel2804.amvera.io')
    
    for submission in submissions_with_screenshots:
        if submission.screenshot_url:
            full_url = f"{webapp_url}/static/uploads/{submission.screenshot_url}"
            
            # Проверяем доступность изображения
            try:
                response = requests.head(full_url, timeout=5)
                status = f"HTTP {response.status_code}"
                accessible = response.status_code == 200
            except Exception as e:
                status = f"Error: {str(e)}"
                accessible = False
            
            debug_info.append({
                'submission_id': submission.id,
                'screenshot_url': submission.screenshot_url,
                'full_url': full_url,
                'status': status,
                'accessible': accessible,
                'user_id': submission.user_id,
                'task_id': submission.task_id,
                'submission_time': submission.submission_time
            })
    
    return render_template('debug_screenshots.html', debug_info=debug_info, webapp_url=webapp_url)


# ДОБАВЛЕНО: Роут для раздачи изображений через админ-панель (fallback)
@app.route('/static/uploads/<filename>')
def serve_uploaded_file(filename):
    """Раздает загруженные файлы если они не доступны через основной веб-апп"""
    try:
        uploads_dir = os.path.join(app.root_path, 'static', 'uploads')
        if os.path.exists(os.path.join(uploads_dir, filename)):
            return send_from_directory(uploads_dir, filename)
        else:
            # Если файла нет локально - пытаемся проксировать с веб-аппа
            webapp_url = os.environ.get('WEBAPP_URL', 'https://seowebapp-angel2804.amvera.io')
            proxy_url = f"{webapp_url}/static/uploads/{filename}"
            response = requests.get(proxy_url, timeout=10)
            if response.status_code == 200:
                from flask import Response
                return Response(response.content, 
                              content_type=response.headers.get('content-type', 'image/jpeg'))
    except Exception as e:
        print(f"Error serving file {filename}: {e}")
    
    # Возвращаем placeholder если файл не найден
    return '', 404

# Uploads config (для обслуживания скриншотов)
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Строка подключения к БД теперь будет браться из переменных окружения на Amvera
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-super-secret-key-for-dev')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ECHO'] = False # Поставить True для отладки SQL запросов

# Инициализация расширений
db = SQLAlchemy(app)
login_manager = LoginManager(app)

with app.app_context():
    try:
        from sqlalchemy import text as _sqltext
        db.session.execute(_sqltext("""
        CREATE TABLE IF NOT EXISTS task_review_texts (
            id SERIAL PRIMARY KEY,
            task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
            text TEXT NOT NULL,
            status VARCHAR(20) DEFAULT 'free',
            assigned_user_id BIGINT,
            assigned_at TIMESTAMP,
            used_submission_id INTEGER,
            created_at TIMESTAMP DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_trt_task_status ON task_review_texts(task_id, status);
        """))
        db.session.commit()
    except Exception as _e:
        print('init table err:', _e)

login_manager.login_view = 'login'
login_manager.login_message = "Пожалуйста, войдите, чтобы получить доступ к этой странице."
login_manager.login_message_category = "info"

# --- КОНСТАНТЫ ---
PLATFORMS = ['Яндекс Карты', 'Google Карты', 'Авито', '2ГИС', 'Яндекс Браузер', 'Ozon', 'Wildberries', 'Zoon', 'Другое']
PAYMENT_METHODS = ['Яндекс Деньги', 'Qiwi', 'Карта']
MIN_WITHDRAWAL_AMOUNT = 200

# --- МОДЕЛИ БАЗЫ ДАННЫХ (SQLAlchemy ORM) ---

class Admin(UserMixin, db.Model):
    __tablename__ = 'admin'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)

    def set_password(self, password):
        """Хеширует и устанавливает пароль для администратора."""
        self.password = generate_password_hash(password)

    def check_password(self, password):
        """Проверяет введенный пароль с хешированным паролем администратора."""
        return check_password_hash(self.password, password)

    def get_id(self):
        """Возвращает ID пользователя, необходимый для Flask-Login."""
        return str(self.id)

class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.BigInteger, primary_key=True)
    username = db.Column(db.String(255))
    full_name = db.Column(db.String(255))
    balance = db.Column(db.Integer, default=0)  # Изменено на Integer как в реальной БД
    points = db.Column(db.Integer, default=0)
    total_points = db.Column(db.Integer, default=0)
    total_earnings = db.Column(db.Integer, default=0)  # Изменено на Integer
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    is_banned = db.Column(db.Boolean, default=False)
    ban_reason = db.Column(db.Text)

    # Реферальные поля (для совместимости c ботом/вебаппом)
    referrer_id = db.Column(db.BigInteger)
    earnings_from_referrals = db.Column(db.Integer, default=0)
    referral_earnings_1 = db.Column(db.Numeric(10, 2), default=0)
    referral_earnings_2 = db.Column(db.Numeric(10, 2), default=0)


    # Обновленная связь - используем правильную таблицу submissions
    submissions = db.relationship('Submission', back_populates='user')
    withdraw_requests = db.relationship('WithdrawRequest', back_populates='user')

class Task(db.Model):
    __tablename__ = 'tasks'  # ИСПРАВЛЕНО: используем таблицу 'tasks' как в веб-аппе
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)  # ДОБАВЛЕНО: заголовок задания
    platform = db.Column(db.Text, nullable=False)  # ИСПРАВЛЕНО: text вместо string
    description = db.Column(db.Text, nullable=False)
    city = db.Column(db.Text)  # ИСПРАВЛЕНО: text как в реальной БД
    direction = db.Column(db.Text)  # ИСПРАВЛЕНО: text как в реальной БД
    category = db.Column(db.String(255))  # ДОБАВЛЕНО: категория задания
    status = db.Column(db.String(50), default='active')  # ДОБАВЛЕНО: статус задания
    price = db.Column(db.Float)  # ОСТАВЛЕНО: для совместимости
    instruction_link = db.Column(db.Text)  # Добавлено как в реальной БД
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # created_by поле отсутствует в реальной таблице tasks
    reward_money = db.Column(db.Numeric)  # Добавлено как в реальной БД
    reward_points = db.Column(db.Integer)  # Добавлено как в реальной БД
    submission_limit = db.Column(db.Integer, default=10)
    task_url = db.Column(db.String(500))
    expires_at = db.Column(db.DateTime)
    priority = db.Column(db.Integer, default=0)

    # Обновленная связь - используем правильную таблицу submissions
    submissions = db.relationship('Submission', back_populates='task', passive_deletes=True)

    @property
    def current_submissions(self):
        try:
            from sqlalchemy import func
            return db.session.query(func.count(Submission.id)).filter(Submission.task_id == self.id).scalar() or 0
        except Exception:
            try:
                return len(self.submissions or [])
            except Exception:
                return 0

    @property
    def remaining_submissions(self):
        try:
            if self.submission_limit is None:
                return None
            return max(int(self.submission_limit or 0) - int(self.current_submissions or 0), 0)
        except Exception:
            return 0

class Submission(db.Model):
    __tablename__ = 'submissions'  # ИСПРАВЛЕНО: используем правильную таблицу submissions
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id'), nullable=False)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')
    submission_time = db.Column(db.DateTime, default=datetime.utcnow)
    screenshot_file_id = db.Column(db.String(500))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)  # created_at - timestamp with time zone
    description = db.Column(db.Text)
    fio = db.Column(db.String(255))
    full_name = db.Column(db.String(255))
    screenshot_url = db.Column(db.String(500))
    review_time = db.Column(db.DateTime)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    rejection_reason = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime)  # ДОБАВЛЕНО: поле из реальной БД
    approved_at = db.Column(db.DateTime)   # ДОБАВЛЕНО: поле из реальной БД
    admin_comment = db.Column(db.Text)     # ДОБАВЛЕНО: поле из реальной БД

    user = db.relationship('User', back_populates='submissions')
    task = db.relationship('Task', back_populates='submissions')
    reviewer = db.relationship('Admin')


class WithdrawRequest(db.Model):
    __tablename__ = 'withdraw_requests'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id'), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    status = db.Column(db.Text, default='pending')
    request_time = db.Column(db.DateTime)
    processed_at = db.Column(db.DateTime)
    processed_time = db.Column(db.DateTime)
    processor_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    transaction_id = db.Column(db.String(255))
    created_at = db.Column(db.BigInteger)

    # Canonical columns in DB
    method = db.Column('method', db.Text)  # kept for back-compat
    details = db.Column('details', db.Text)
    notes = db.Column('notes', db.Text)

    # Alternative payment_* columns also exist in schema — map их для совместимости
    payment_method = db.Column('payment_method', db.String(100))
    payment_details = db.Column('payment_details', db.Text)
    payment_notes = db.Column('payment_notes', db.Text)
    payment_transaction_id = db.Column('payment_transaction_id', db.String(255))

    user = db.relationship('User', back_populates='withdraw_requests')
    processor = db.relationship('Admin')


class TaskReviewText(db.Model):
    __tablename__ = "task_review_texts"
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey("tasks.id"), nullable=False)
    text = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default="free")
    assigned_user_id = db.Column(db.BigInteger)
    assigned_at = db.Column(db.DateTime)
    used_submission_id = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
class SystemLog(db.Model):
    __tablename__ = 'system_logs'
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    action = db.Column(db.String(100), nullable=False)
    entity_type = db.Column(db.String(50))
    entity_id = db.Column(db.Integer)
    details = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))

    admin = db.relationship('Admin')


class ActivityLog(db.Model):
    __tablename__ = 'activity_logs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id'))
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User')
    admin = db.relationship('Admin')
class SystemSettings(db.Model):
    __tablename__ = 'system_settings'
    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), nullable=False)  # Исправлено на setting_key как в реальной БД
    setting_value = db.Column(db.Text)  # Исправлено на setting_value как в реальной БД
    key = db.Column(db.String(100))  # Добавлено как в реальной БД
    value = db.Column(db.Text)  # Добавлено как в реальной БД
    description = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_by = db.Column(db.Integer, db.ForeignKey('admin.id'))

    updater = db.relationship('Admin')

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---

@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

def log_action(action, entity_type=None, entity_id=None, details=None):
    """Записывает действие в лог системы"""
    try:
        log_entry = SystemLog(
            admin_id=current_user.id if current_user.is_authenticated else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details,
            ip_address=request.remote_addr
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        print(f"Ошибка записи в лог: {e}")

@app.context_processor
def inject_pending_counts():
    """Внедряет количество ожидающих элементов в шаблоны"""
    if current_user.is_authenticated:
        pending_submissions = Submission.query.filter_by(status='pending').count()
        pending_payouts = WithdrawRequest.query.filter_by(status='pending').count()
        return {
            'pending_submissions_count': pending_submissions,
            'pending_payouts_count': pending_payouts,
            'support_unread_count': get_support_unread_count()
        }
    return {}




# --- Jinja filter: map status codes to Russian labels ---
@app.template_filter('status_label')
def status_label(value):
    mp = {
        'pending': 'На проверке',
        'approved': 'Одобрено',
        'rejected': 'Отклонено',
        'paid': 'Выплачено',
        'processing': 'В обработке',
        'active': 'Активно',
        'inactive': 'Неактивно',
        'open': 'Открыт',
        'answered': 'С ответом',
        'closed': 'Закрыт'
    }
    return mp.get((value or '').lower(), value)
# --- Jinja filter: format various date/time representations to 'dd.mm.YYYY HH:MM' ---
@app.template_filter('format_dt')
def format_dt(value):
    try:
        if value is None:
            return ''
        # epoch as int/float or string digits
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(int(value)).strftime('%d.%m.%Y %H:%M')
        if isinstance(value, str) and value.isdigit():
            return datetime.fromtimestamp(int(value)).strftime('%d.%m.%Y %H:%M')
        # datetime-like object
        if hasattr(value, 'strftime'):
            return value.strftime('%d.%m.%Y %H:%M')
        # fallback: try to cast
        try:
            iv = int(value)
            return datetime.fromtimestamp(iv).strftime('%d.%m.%Y %H:%M')
        except Exception:
            return str(value)
    except Exception:
        return ''

# --- РОУТЫ ---


# ========== ИСПРАВЛЕНИЕ: API ДЛЯ УВЕДОМЛЕНИЙ ==========

def get_support_unread_count():
    try:
        from sqlalchemy import text as _sqltext
        sql = _sqltext("""
            SELECT COUNT(*) FROM (
              SELECT t.id,
                     COALESCE((SELECT m.sender FROM support_messages m WHERE m.ticket_id = t.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1), 'user') AS last_sender,
                     t.status
              FROM support_tickets t
              WHERE t.status != 'closed'
            ) s
            WHERE s.last_sender = 'user'
        """)
        res = db.session.execute(sql)
        return int(res.scalar() or 0)
    except Exception as e:
        try: db.session.rollback()
        except Exception: pass
        print('get_support_unread_count error:', e)
        return 0

@app.route('/api/support/notifications/count')
@login_required
def api_support_notifications_count():
    try:
        return jsonify({'success': True, 'unread': get_support_unread_count()})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/notifications/count')
@login_required
def notifications_count():
    """API для получения количества уведомлений"""
    try:
        pending_submissions = Submission.query.filter_by(status='pending').count()
        pending_payouts = WithdrawRequest.query.filter_by(status='pending').count()
        return jsonify({
            'success': True,
            'total': pending_submissions + pending_payouts,
            'submissions': pending_submissions,
            'payouts': pending_payouts
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/notifications/list')
@login_required  
def notifications_list():
    """API для получения списка уведомлений"""
    try:
        notifications = []
        # Заявки на выполнение
        pending_submissions = Submission.query.filter_by(status='pending').order_by(desc(Submission.submission_time)).limit(5).all()
        for sub in pending_submissions:
            notifications.append({
                'type': 'submission', 'id': sub.id, 'title': 'Новое выполнение задания',
                'message': f'Пользователь выполнил задание #{sub.task_id}',
                'time': sub.submission_time.strftime('%H:%M') if sub.submission_time else '',
                'url': url_for('submissions', status='pending')
            })
        # Заявки на вывод
        pending_payouts = WithdrawRequest.query.filter_by(status='pending').order_by(desc(WithdrawRequest.request_time)).limit(5).all()
        for payout in pending_payouts:
            notifications.append({
                'type': 'payout', 'id': payout.id, 'title': 'Новая заявка на вывод',
                'message': f'Запрос на вывод {payout.amount}₽',
                'time': payout.request_time.strftime('%H:%M') if payout.request_time else '',
                'url': url_for('payouts', status='pending')
            })
        notifications.sort(key=lambda x: x['time'], reverse=True)
        return jsonify({'success': True, 'notifications': notifications[:10]})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/login', methods=['GET', 'POST'])
def login():
    # ИСПРАВЛЕНИЕ: передаем пустые счетчики для неавторизованных пользователей
    context = {
        'pending_submissions_count': 0,
        'pending_payouts_count': 0
    }
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and admin.check_password(password) and admin.is_active:
            login_user(admin)
            admin.last_login = datetime.utcnow()
            db.session.commit()
            log_action('LOGIN', details=f'Успешный вход пользователя {username}')
            flash('Добро пожаловать!', 'success')
            return redirect(url_for('dashboard'))
        else:
            log_action('LOGIN_FAILED', details=f'Неудачная попытка входа: {username}')
            flash('Неверное имя пользователя или пароль', 'danger')
    
    return render_template('login.html', **context)

@app.route('/logout')
@login_required
def logout():
    log_action('LOGOUT', details=f'Выход пользователя {current_user.username}')
    logout_user()
    flash('Вы успешно вышли из системы', 'info')
    return redirect(url_for('login'))

@app.route('/')
@app.route('/dashboard')
@login_required
def dashboard():
    # Статистика для карточек
    stats = {
        'total_users': User.query.count(),
        'active_users': db.session.query(func.count(distinct(Submission.user_id))).filter(Submission.submission_time >= datetime.utcnow() - timedelta(days=7)).scalar() or 0,
        'active_tasks': Task.query.filter_by(status='active').count(),
        'total_earnings': db.session.query(func.sum(User.total_earnings)).scalar() or 0,
        'pending_withdrawals': WithdrawRequest.query.filter_by(status='pending').count(),
        'total_submissions': Submission.query.count(),
        'pending_submissions': Submission.query.filter_by(status='pending').count(),
        'approved_submissions': Submission.query.filter_by(status='approved').count(),
        'rejected_submissions': Submission.query.filter_by(status='rejected').count(),
    }
    
    # Последние ожидающие заявки
    recent_submissions = Submission.query.filter_by(status='pending')\
        .order_by(desc(Submission.submission_time)).limit(10).all()
    
    # Статистика по платформам
    platform_stats = db.session.query(
        Task.platform,
        func.count(Submission.id).label('submissions_count')
    ).join(Submission).group_by(Task.platform).all()
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         recent_submissions=recent_submissions,
                         platform_stats=platform_stats)

@app.route('/tasks')
@login_required
def tasks():
    owner = (request.args.get('owner') or '').strip()
    partner = (request.args.get('partner') or '').strip()

    # Default filter: if neither owner nor partner provided, treat as owner='my'
    if not owner and not partner:
        owner = 'my'
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 15))
    show = (request.args.get('show') or 'active').strip()
    platform_filter = (request.args.get('platform') or '').strip()

    query = Task.query
    if show != 'all':
        if show == 'archived':
            query = query.filter(Task.status == 'archived')
        else:
            query = query.filter(Task.status != 'archived')
    if owner == 'my':
        query = query.filter(or_(Task.direction.is_(None), Task.direction == ''))
    elif partner:
        query = query.filter(Task.direction == partner)

    # platform filter
    if platform_filter and platform_filter.lower() not in ['all','все']:
        query = query.filter(Task.platform == platform_filter)

    tasks = query.order_by(desc(Task.created_at)).paginate(page=page, per_page=per_page, error_out=False)

    partners = get_partners_list()
    current_owner = 'my' if owner == 'my' else (partner or 'my')

    
    return render_template('tasks_fixed_final.html', tasks=tasks, platforms=PLATFORMS, partners=partners, current_owner=current_owner, show=show, current_platform=platform_filter)



@app.route('/tasks/reset_assigned_texts', methods=['POST'])
@login_required
def reset_assigned_texts():
    """Сбрасывает assigned тексты отзывов в статус free"""
    try:
        reset_count = reset_assigned_review_texts()
        if reset_count > 0:
            flash(f'Сброшено {reset_count} зависших текстов отзывов в статус "свободный"', 'success')
        else:
            flash('Нет зависших текстов для сброса', 'info')
    except Exception as e:
        flash(f'Ошибка при сбросе текстов: {e}', 'danger')
    
    return redirect(url_for('tasks'))

@app.route('/tasks/new', methods=['GET', 'POST'])
@login_required
def new_task():
    owner = (request.args.get('owner') or '').strip()
    partner_arg = (request.args.get('partner') or '').strip()
    selected_owner = 'my' if owner == 'my' else (partner_arg or 'my')

    if request.method == 'POST':
        try:
            # Получаем данные из формы с защитой от None и пустых строк
            reward_money = request.form.get('reward_money', '').strip()
            if not reward_money:
                reward_money = request.form.get('price', '0').strip()
            
            reward_points = request.form.get('reward_points', '').strip()
            submission_limit = request.form.get('submission_limit', '').strip()
            priority = request.form.get('priority', '').strip()
            
            # Конвертируем в числа с защитой от ошибок
            try:
                reward_money_val = float(reward_money) if reward_money else 0.0
            except (ValueError, TypeError):
                reward_money_val = 0.0
                
            try:
                reward_points_val = int(reward_points) if reward_points else 0
            except (ValueError, TypeError):
                reward_points_val = 0
                
            try:
                submission_limit_val = int(submission_limit) if submission_limit else 10
            except (ValueError, TypeError):
                submission_limit_val = 10
                
            try:
                priority_val = int(priority) if priority else 0
            except (ValueError, TypeError):
                priority_val = 0
            
            # ИСПРАВЛЕНИЕ: Правильно определяем direction
            direction = None
            if owner == 'my':
                direction = ''  # Пустая строка для "Мои задания"
            elif partner_arg:
                direction = partner_arg  # Конкретный посредник
            else:
                # Дополнительная проверка из формы
                form_direction = request.form.get('direction', '').strip()
                if form_direction and form_direction != 'my':
                    direction = form_direction
                else:
                    direction = ''
            
            task = Task(
                title=request.form.get('title', f"Задание на {request.form['platform']}"),
                platform=request.form['platform'],
                description=request.form['description'],
                category=request.form.get('category', 'review'),
                status='active',
                price=reward_money_val,
                reward_money=reward_money_val,
                reward_points=reward_points_val,
                submission_limit=submission_limit_val,
                task_url=request.form.get('task_url', ''),
                instruction_link=request.form.get('instruction_link', ''),
                city=request.form.get('city', ''),
                is_active=True,
                priority=priority_val,
                created_at=datetime.utcnow(),
                direction=direction  # ИСПРАВЛЕНИЕ: Устанавливаем правильную direction
            )
            
            db.session.add(task)
            db.session.flush()  # Получаем ID задания
            
            # Обрабатываем тексты отзывов
            new_texts_list = request.form.getlist('new_review_texts[]')
            # Normalize and filter empty lines
            texts = [t.strip() for t in new_texts_list if (t or '').strip()]
            if texts and task.category == 'review':
                for text in texts:
                    review_text = TaskReviewText(
                        task_id=task.id,
                        text=text,
                        status='free'
                    )
                    db.session.add(review_text)
            
            db.session.commit()
            flash('Задание создано успешно!', 'success')
            
            # Перенаправляем обратно в нужную категорию
            if direction:
                return redirect(url_for('tasks', partner=direction))
            else:
                return redirect(url_for('tasks', owner='my'))
                
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка при создании задания: {str(e)}', 'error')
            print(f"Error creating task: {e}")
    
    partners = get_partners_list()
    return render_template('task_form.html', platforms=PLATFORMS, partners=partners, selected_owner=selected_owner, owner=owner, partner=partner_arg)

@app.route('/tasks/edit/<int:task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = Task.query.get_or_404(task_id)
    
    owner = (request.args.get('owner') or '').strip()
    partner_arg = (request.args.get('partner') or '').strip()
    selected_owner = 'my' if owner == 'my' else (partner_arg or 'my')

    if request.method == 'POST':
        try:
            # Получаем данные из формы с защитой от None и пустых строк
            reward_money = request.form.get('reward_money', '').strip()
            if not reward_money:
                reward_money = request.form.get('price', str(task.price or 0)).strip()
            
            reward_points = request.form.get('reward_points', '').strip()  
            submission_limit = request.form.get('submission_limit', '').strip()
            priority = request.form.get('priority', '').strip()
            
            # Конвертируем в числа с защитой от ошибок
            try:
                reward_money_val = float(reward_money) if reward_money else (task.reward_money or 0.0)
            except (ValueError, TypeError):
                reward_money_val = task.reward_money or 0.0
                
            try:
                reward_points_val = int(reward_points) if reward_points else (task.reward_points or 0)
            except (ValueError, TypeError):
                reward_points_val = task.reward_points or 0
                
            try:
                submission_limit_val = int(submission_limit) if submission_limit else (task.submission_limit or 10)
            except (ValueError, TypeError):
                submission_limit_val = task.submission_limit or 10
                
            try:
                priority_val = int(priority) if priority else (task.priority or 0)
            except (ValueError, TypeError):
                priority_val = task.priority or 0
            
            # Обновляем поля задания
            task.title = request.form.get('title', task.title)
            task.platform = request.form['platform']
            task.description = request.form['description']
            task.category = request.form.get('category', task.category or 'review')
            task.price = reward_money_val
            task.reward_money = reward_money_val
            task.reward_points = reward_points_val
            task.submission_limit = submission_limit_val
            task.task_url = request.form.get('task_url', task.task_url or '')
            task.instruction_link = request.form.get('instruction_link', task.instruction_link or '')
            task.city = request.form.get('city', task.city or '')
            task.is_active = 'is_active' in request.form
            task.priority = priority_val
            # ИСПРАВЛЕНО: Сохраняем текущую direction если не выбрана новая
            form_direction = (request.form.get('direction') or '').strip()
            partner_select = (request.form.get('partner_select') or '').strip()
            partner_new = (request.form.get('partner_new') or '').strip()

            # Определяем новое значение direction
            new_direction = partner_new or partner_select or form_direction
            
            if new_direction == 'my':
                # Явно выбрано "Мои задания"
                task.direction = ''
            elif new_direction:
                # Выбран конкретный посредник
                task.direction = new_direction
            else:
                # Ничего не выбрано - СОХРАНЯЕМ ТЕКУЩЕЕ ЗНАЧЕНИЕ
                # Не меняем task.direction вообще!
                pass
            db.session.commit()

            # Синхронизация текстов отзывов: обновление/удаление/добавление
            try:
                # Обновление существующих
                ids = request.form.getlist('existing_review_texts_ids[]')
                vals = request.form.getlist('existing_review_texts_values[]')
                for _id, _val in zip(ids, vals):
                    try:
                        rid = int(_id)
                    except (TypeError, ValueError):
                        continue
                    trow = TaskReviewText.query.filter_by(id=rid, task_id=task.id).first()
                    if trow is not None:
                        trow.text = (_val or '').strip()
                # Удаление отмеченных
                del_ids = request.form.getlist('delete_review_texts_ids[]')
                for _id in del_ids:
                    try:
                        rid = int(_id)
                    except (TypeError, ValueError):
                        continue
                    TaskReviewText.query.filter_by(id=rid, task_id=task.id).delete()
                # Добавление новых
                new_list = request.form.getlist('new_review_texts[]')
                for line in new_list:
                    t = (line or '').strip()
                    if t:
                        db.session.add(TaskReviewText(task_id=task.id, text=t))
                db.session.commit()
            except Exception as _e:
                db.session.rollback()
                db.session.rollback()
            log_action('UPDATE_TASK', 'task', task.id, f'Обновлено задание: {task.description[:50]}')
            flash('Задание успешно обновлено!', 'success')

            show = (request.args.get('show') or None)
            platform_value = (request.args.get('platform') or None)
            page = (request.args.get('page') or None)
            per_page = (request.args.get('per_page') or None)

            if (task.direction or '').strip():
                return redirect(url_for('tasks', partner=task.direction, show=show, platform=platform_value, page=page, per_page=per_page))
            else:
                return redirect(url_for('tasks', owner='my', show=show, platform=platform_value, page=page, per_page=per_page))

            
        except Exception as e:
            db.session.rollback()
            log_action('ERROR', details=f'Ошибка при обновлении задания {task_id}: {str(e)}')
            flash(f'Ошибка при обновлении задания: {str(e)}', 'danger')
    
    return render_template('task_form.html', platforms=PLATFORMS, task=task, review_texts=TaskReviewText.query.filter_by(task_id=task.id).order_by(TaskReviewText.id).all(), title='Редактировать задание')


@app.route('/tasks/deactivate/<int:task_id>', methods=['POST'])
@login_required
def deactivate_task(task_id):
    task = Task.query.get_or_404(task_id)
    try:
        task.is_active = False
        task.status = 'inactive'
        db.session.commit()
        log_action('DEACTIVATE_TASK', 'task', task_id, f'Деактивировано задание: {task.description[:50]}')
        flash('Задание деактивировано.', 'info')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при деактивации задания: {str(e)}', 'danger')
    return redirect(url_for('tasks'))

@app.route('/tasks/activate/<int:task_id>', methods=['POST'])
@login_required
def activate_task(task_id):
    task = Task.query.get_or_404(task_id)
    try:
        task.is_active = True
        task.status = 'active'
        db.session.commit()
        log_action('ACTIVATE_TASK', 'task', task_id, f'Активировано задание: {task.description[:50]}')
        flash('Задание активировано.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при активации задания: {str(e)}', 'danger')
    return redirect(url_for('tasks'))

@app.route('/tasks/delete/<int:task_id>', methods=['POST'])
@login_required
def delete_task(task_id):
    """
    Удаление задания безопасно для выполнений:
    - Если у задания есть любые выполнения (pending/approved/rejected), мы их НЕ трогаем.
      Само задание скрываем из списка: is_active=False, status='archived'. Заголовок НЕ меняем.
    - Если выполнений нет — удаляем запись задания полностью.
    """
    task = Task.query.get_or_404(task_id)
    try:
        pending_count = db.session.query(func.count(Submission.id)).filter(Submission.task_id==task_id, Submission.status=='pending').scalar() or 0
        approved_count = db.session.query(func.count(Submission.id)).filter(Submission.task_id==task_id, Submission.status=='approved').scalar() or 0
        rejected_count = db.session.query(func.count(Submission.id)).filter(Submission.task_id==task_id, Submission.status=='rejected').scalar() or 0
        total_count = pending_count + approved_count + rejected_count

        if total_count > 0:
            # Прячем задание, но оставляем все выполнения как есть
            was_changed = False
            if getattr(task, 'is_active', True):
                task.is_active = False
                was_changed = True
            if getattr(task, 'status', None) != 'archived':
                task.status = 'archived'
                was_changed = True
            if was_changed:
                db.session.commit()
            flash(
                f'Задание скрыто. Выполнения сохранены (ожидают: {pending_count}, одобрено: {approved_count}, отклонено: {rejected_count}).',
                'success'
            )
        else:
            # Без выполнений — удаляем полностью
            description = (getattr(task, 'description', '') or '')[:50]
            db.session.delete(task)
            db.session.commit()
            try:
                log_action('DELETE_TASK', 'task', task_id, f'Удалено задание без выполнений: {description}')
            except Exception:
                pass
            flash('Задание удалено (выполнений не было).', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при удалении задания: {str(e)}', 'danger')
    return redirect(url_for('tasks'))
@app.route('/submissions', endpoint='submissions')
@login_required
def submissions():
    from sqlalchemy import or_, desc, func
    status = request.args.get('status', 'pending')
    owner = (request.args.get('owner') or '').strip()
    partner = (request.args.get('partner') or '').strip()

    # Default filter: if neither owner nor partner provided, treat as owner='my'
    if not owner and not partner:
        owner = 'my'
    platform = (request.args.get('platform') or 'all').strip()
    q = (request.args.get('q') or '').strip()
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 50))

    # Aliases for platform shortcuts
    aliases = {
        'yandex': 'Яндекс Карты', 'яндекс': 'Яндекс Карты', 'ymaps': 'Яндекс Карты',
        'google': 'Google Карты', 'гугл': 'Google Карты', 'gmap': 'Google Карты',
        '2gis': '2ГИС', 'дегис': '2ГИС',
        'avito': 'Авито', 'авито': 'Авито',
        'ozon': 'Ozon', 'озон': 'Ozon',
        'wb': 'Wildberries', 'wildberries': 'Wildberries', 'вб': 'Wildberries',
        'zoon': 'Zoon', 'зун': 'Zoon',
        'browser': 'Яндекс Браузер', 'yabrowser': 'Яндекс Браузер',
        'other': 'Другое', 'другое': 'Другое'
    }
    platform_value = None if platform == 'all' else aliases.get(platform.lower(), platform)

    # Base query with join to Task for platform filtering
    query = db.session.query(Submission).join(Task, Task.id == Submission.task_id)

    # Filter by owner/partner (Task.direction)
    if owner == 'my':
        query = query.filter(or_(Task.direction.is_(None), Task.direction == ''))
    elif partner:
        query = query.filter(Task.direction == partner)

    if status != 'all':
        query = query.filter(Submission.status == status)
    if platform_value:
        query = query.filter(Task.platform.ilike(platform_value))

    # Search across several fields
    search_filters = []
    if q:
        if q.isdigit():
            search_filters.extend([
                Submission.user_id == int(q),
                Submission.task_id == int(q)
            ])
        like_q = '%' + q + '%'
        search_filters.extend([
            Submission.fio.ilike(like_q),
            Submission.notes.ilike(like_q),
            Task.title.ilike(like_q),
            Task.description.ilike(like_q),
            Task.platform.ilike(like_q)
        ])
        query = query.filter(or_(*search_filters))

    submissions = query.order_by(desc(Submission.submission_time)).paginate(page=page, per_page=per_page, error_out=False)

    # Counts per platform for current filters (status and search), to show badges
    count_q = db.session.query(Task.platform, func.count(Submission.id)).join(Submission)
    if status != 'all':
        count_q = count_q.filter(Submission.status == status)
    if q:
        count_q = count_q.filter(or_(*search_filters))
    
    # Apply owner/partner filters to counts as well
    if owner == 'my':
        count_q = count_q.filter(or_(Task.direction.is_(None), Task.direction == ''))
    elif partner:
        count_q = count_q.filter(Task.direction == partner)
    platform_counts_pairs = count_q.group_by(Task.platform).all()
    platform_counts = {k: int(v) for k, v in platform_counts_pairs}

    # Ensure all known platforms present in dict
    try:
        all_platforms = PLATFORMS
    except Exception:
        all_platforms = sorted({k for k in platform_counts.keys()})
    for p in all_platforms:
        platform_counts.setdefault(p, 0)

    pending_count = db.session.query(func.count(Submission.id)).filter(Submission.status == 'pending').scalar() or 0


    current_owner = "my" if owner == "my" else (partner or "my")
    return render_template('submissions.html', submissions=submissions, current_status=status, platform=platform, platform_counts=platform_counts, pending_count=pending_count, q=q, owner=owner, partner=partner, per_page=per_page, partners=get_partners_list(), PLATFORMS=PLATFORMS, current_owner=current_owner)
@app.route('/submissions/process/<int:submission_id>/<action>', methods=['POST'])
@login_required
def process_submission(submission_id, action):
    submission = Submission.query.get_or_404(submission_id)
    
    if submission.status != 'pending':
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': 'Это задание уже было обработано'}), 400
        flash('Это задание уже было обработано', 'warning')
        return redirect(request.referrer or url_for('submissions'))
    
    try:
        if action == 'approve':
            submission.status = 'approved'
            submission.review_time = datetime.utcnow()
            submission.approved_at = datetime.utcnow()
            submission.reviewer_id = current_user.id
            
            # Начисляем награду пользователю
            if submission.user and submission.task:
                # Используем правильные поля из реальной структуры БД
                reward_money = (getattr(submission.task, "reward_money", 0) or 0) or (getattr(submission.task, "price", 0) or 0)
                base_reward_money = float(reward_money or 0)
                reward_points = submission.task.reward_points or 0
                
                submission.user.balance += int(reward_money)
                submission.user.points += reward_points
                submission.user.total_earnings += int(reward_money)
                
                log_action('APPROVE_SUBMISSION', 'submission', submission_id, 
                      f'Одобрено выполнение задания пользователем {submission.user.username if submission.user else "N/A"} с реферальными начислениями')
            
            message = 'Задание одобрено, награда начислена, реферальные проценты выплачены!'
            
        elif action == 'reject':
            payload = (request.get_json(silent=True) or {}) if (request.is_json or request.content_type == 'application/json') else {}
            reason = payload.get('reason') or request.form.get('reason', 'Не указана')
            submission.status = 'rejected'
            submission.review_time = datetime.utcnow()
            submission.approved_at = datetime.utcnow()
            submission.reviewer_id = current_user.id
            submission.rejection_reason = reason
            
            log_action('REJECT_SUBMISSION', 'submission', submission_id, 
                      f'Отклонено выполнение задания: {reason}')
            message = 'Задание отклонено'
        
        db.session.commit()
        
        # === Notify bot about decision (best-effort, non-blocking) ===
        try:
            if submission and getattr(submission, 'user_id', None) and getattr(submission, 'id', None):
                if action == 'approve':
                    reward_money = 0.0
                    try:
                        if getattr(submission, 'task', None):
                            reward_money = float((getattr(submission.task, 'price', 0) or 0) or (getattr(submission.task, 'reward_money', 0) or 0))
                    except Exception:
                        reward_money = 0.0
                    paid_reward = int(float(reward_money or 0))
                    notify_bot_about_approval(submission.user_id, submission.id, paid_reward)
                elif action == 'reject':
                    reason = getattr(submission, 'rejection_reason', None) or 'Не указана'
                    notify_bot_about_rejection(submission.user_id, submission.id, reason)
        except Exception as notify_error:
            print(f'[notify_error] {notify_error}')
        # === End notification ===
        
        # Если это AJAX запрос, возвращаем JSON
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.content_type == 'application/json':
            return jsonify({
                'success': True, 
                'message': message,
                'submission_id': submission_id,
                'action': action
            })
        
        # Обычный запрос - redirect как раньше
        flash(message, 'success' if action == 'approve' else 'info')
        
    except Exception as e:
        db.session.rollback()
        error_msg = f'Ошибка при обработке задания: {str(e)}'
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.content_type == 'application/json':
            return jsonify({'success': False, 'message': error_msg}), 500
        flash(error_msg, 'danger')
    
    return redirect(request.referrer or url_for('submissions'))

@app.route('/payouts')
@login_required
def payouts():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        current_status = request.args.get('status', 'pending')  # По умолчанию показываем pending

        query = WithdrawRequest.query.filter_by(status=current_status)
        payouts = query.order_by(desc(WithdrawRequest.created_at)).paginate(page=page, per_page=per_page, error_out=False)

        for payout in getattr(payouts, 'items', []):
            try:
                payout.user = User.query.filter_by(user_id=payout.user_id).first()
            except Exception:
                payout.user = None

        pending_payouts_count = WithdrawRequest.query.filter_by(status='pending').count()
        return render_template('payouts.html', payouts=payouts, current_status=current_status, pending_payouts_count=pending_payouts_count)

    except Exception as e:
        flash(f'Ошибка загрузки выплат: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

@app.route('/payouts/approve/<int:request_id>', methods=['POST'])
@login_required
def approve_payout(request_id):
    payout_request = WithdrawRequest.query.get_or_404(request_id)
    
    if payout_request.status != 'pending':
        flash('Эта заявка уже была обработана', 'warning')
        return redirect(url_for('payouts'))
    
    try:
        payout_request.status = 'approved'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.notes = request.form.get('notes', '')
        
        db.session.commit()

        try:
            notify_bot_withdraw(payout_request.user_id, payout_request.id, 'approved', payout_request.amount)
        except Exception as _e:
            print(f'Notify bot withdraw failed: {_e}')

        
        log_action('APPROVE_PAYOUT', 'withdraw_request', request_id, 
                  f'Одобрена заявка на вывод {payout_request.amount}₽')
        flash('Заявка на вывод одобрена!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при одобрении заявки: {str(e)}', 'danger')
    
    return redirect(url_for('payouts'))

@app.route('/payouts/mark_paid/<int:request_id>', methods=['POST'])
@login_required
def mark_payout_paid(request_id):
    payout_request = WithdrawRequest.query.get_or_404(request_id)
    
    if payout_request.status not in ['approved', 'pending']:
        flash('Эта заявка не может быть отмечена как оплаченная', 'warning')
        return redirect(url_for('payouts'))
    
    try:
        payout_request.status = 'paid'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.transaction_id = request.form.get('transaction_id', '')
        payout_request.notes = request.form.get('notes', '')
        
        db.session.commit()

        try:
            notify_bot_withdraw(
                payout_request.user_id, 
                payout_request.id, 
                'paid', 
                payout_request.amount,
                notes=payout_request.notes,
                transaction_id=payout_request.transaction_id
            )
        except Exception as _e:
            print(f'Notify bot withdraw failed: {_e}')

        
        log_action('MARK_PAID_PAYOUT', 'withdraw_request', request_id, 
                  f'Отмечена как оплаченная заявка на {payout_request.amount}₽, ID транзакции: {payout_request.transaction_id}')
        flash('Заявка отмечена как оплаченная!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при отметке заявки: {str(e)}', 'danger')
    
    return redirect(url_for('payouts'))

@app.route('/payouts/reject/<int:request_id>', methods=['POST'])
@login_required
def reject_payout(request_id):
    payout_request = WithdrawRequest.query.get_or_404(request_id)

    if payout_request.status == 'paid':
        flash('Нельзя отклонить уже оплаченную заявку', 'warning')
        return redirect(url_for('payouts'))

    try:
        reason = request.form.get('reason', 'Не указана')

        # Возвращаем деньги на баланс для статусов pending/approved
        if payout_request.user and payout_request.status in ['pending', 'approved']:
            payout_request.user.balance += int(payout_request.amount or 0)
            try:
                db.session.execute(
                    """INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at)
                    VALUES (:uid, :amt, 'withdraw_reject', :rid, extract(epoch from now())::bigint)""",
                    { 'uid': int(payout_request.user_id), 'amt': int(payout_request.amount or 0), 'rid': int(payout_request.id) }
                )
            except Exception as _e:
                print(f'Balance log insert failed: {_e}')

        payout_request.status = 'rejected'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.notes = reason

        db.session.commit()

        try:
            notify_bot_withdraw(payout_request.user_id, payout_request.id, 'rejected', payout_request.amount, reason)
        except Exception as _e:
            print(f'Notify bot withdraw failed: {_e}')

        log_action('REJECT_PAYOUT', 'withdraw_request', request_id, f'Отклонена заявка на вывод {payout_request.amount}₽: {reason}')
        flash('Заявка на вывод отклонена!', 'info')

    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при отклонении заявки: {str(e)}', 'danger')

    return redirect(url_for('payouts'))

    
    try:
        reason = request.form.get('reason', 'Не указана')
        
        # Возвращаем деньги на баланс пользователя если заявка была одобрена
        if payout_request.status == 'approved' and payout_request.user:
            payout_request.user.balance += payout_request.amount
        
        payout_request.status = 'rejected'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.notes = reason
        
        db.session.commit()
        
        log_action('REJECT_PAYOUT', 'withdraw_request', request_id, 
                  f'Отклонена заявка на вывод {payout_request.amount}₽: {reason}')
        flash('Заявка на вывод отклонена!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при отклонении заявки: {str(e)}', 'danger')
    
    return redirect(url_for('payouts'))

@app.route('/users')
@login_required
def users():
    search_query = request.args.get('q', '')
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 20))
    
    query = User.query
    if search_query:
        if search_query.isdigit():
            query = query.filter(or_(
                User.username.ilike(f'%{search_query}%'),
                User.full_name.ilike(f'%{search_query}%'),
                User.user_id == int(search_query)
            ))
        else:
            query = query.filter(or_(
                User.username.ilike(f'%{search_query}%'),
                User.full_name.ilike(f'%{search_query}%'),
                cast(User.user_id, String).ilike(f'%{search_query}%')
            ))
    
    users = query.order_by(desc(User.registration_date))\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Статистика пользователей
    user_stats = {
        'total_users': User.query.count(),
        'active_users': db.session.query(func.count(distinct(Submission.user_id))).filter(Submission.submission_time >= datetime.utcnow() - timedelta(days=7)).scalar() or 0,
        'banned_users': User.query.filter_by(is_banned=True).count(),
        'total_balance': db.session.query(func.sum(User.balance)).scalar() or 0
    }
    
    # ==== Referral stats for current page users ====
    page_user_ids = [u.user_id for u in users.items]
    referral_counts = {}
    referral_earnings = {}
    if page_user_ids:
        # Count direct referrals per user (level 1)
        ref_rows = db.session.query(User.referrer_id, func.count(User.user_id))\
            .filter(User.referrer_id.in_(page_user_ids))\
            .group_by(User.referrer_id).all()
        referral_counts = {int(rid): int(cnt) for rid, cnt in ref_rows}
        # Earnings from referrals for each user (sum of lvl1 + lvl2)
        for u in users.items:
            try:
                r1 = float(u.referral_earnings_1 or 0)
            except Exception:
                r1 = 0.0
            try:
                r2 = float(u.referral_earnings_2 or 0)
            except Exception:
                r2 = 0.0
            referral_earnings[int(u.user_id)] = round(r1 + r2, 2)

    return render_template('users_with_referrals.html',  users=users, 
                         search_query=search_query,
                         user_stats=user_stats, referral_counts=referral_counts, referral_earnings=referral_earnings)

@app.route('/users/ban/<int:user_id>', methods=['POST'])
@login_required
def ban_user(user_id):
    user = User.query.get_or_404(user_id)
    reason = request.form.get('reason', 'Не указана')
    
    try:
        user.is_banned = True
        user.ban_reason = reason
        db.session.commit()
        
        log_action('BAN_USER', 'user', user_id, f'Заблокирован пользователь {user.username}: {reason}')
        flash(f'Пользователь {user.username} заблокирован!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при блокировке пользователя: {str(e)}', 'danger')
    
    return redirect(url_for('users'))

@app.route('/users/unban/<int:user_id>', methods=['POST'])
@login_required
def unban_user(user_id):
    user = User.query.get_or_404(user_id)
    
    try:
        user.is_banned = False
        user.ban_reason = None
        db.session.commit()
        
        log_action('UNBAN_USER', 'user', user_id, f'Разблокирован пользователь {user.username}')
        flash(f'Пользователь {user.username} разблокирован!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при разблокировке пользователя: {str(e)}', 'danger')
    
    return redirect(url_for('users'))

@app.route('/analytics')
@login_required
def analytics():
    # Статистика за последние 30 дней
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    
    # Основная статистика
    stats = {
        'total_users': User.query.count(),
        'active_users': db.session.query(func.count(distinct(Submission.user_id))).filter(Submission.submission_time >= datetime.utcnow() - timedelta(days=7)).scalar() or 0,
        'active_tasks': Task.query.filter_by(status='active').count(),
        'total_earnings': db.session.query(func.sum(User.total_earnings)).scalar() or 0,
        'pending_withdrawals': WithdrawRequest.query.filter_by(status='pending').count(),
        'total_submissions': Submission.query.count(),
        'pending_submissions': Submission.query.filter_by(status='pending').count(),
        'approved_submissions': Submission.query.filter_by(status='approved').count(),
        'rejected_submissions': Submission.query.filter_by(status='rejected').count(),
    }
    
    # Ежедневная статистика
    daily_stats = db.session.query(
        func.date(Submission.submission_time).label('date'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved'),
        func.count(case([(Submission.status == 'rejected', 1)])).label('rejected'),
        func.count(case([(Submission.status == 'pending', 1)])).label('pending')
    ).filter(Submission.submission_time >= thirty_days_ago)\
     .group_by(func.date(Submission.submission_time))\
     .order_by(func.date(Submission.submission_time)).all()
    
    # Статистика по платформам
    platform_stats = db.session.query(
        Task.platform,
        func.count(Submission.id).label('total_submissions'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved_submissions'),
        func.sum(case([(Submission.status == 'approved', Task.price)])).label('total_paid')
    ).join(Submission).group_by(Task.platform).all()
    
    # Топ пользователи
    top_users = db.session.query(
        User,
        func.count(Submission.id).label('submissions_count'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved_count')
    ).join(Submission).group_by(User.user_id)\
     .order_by(desc('approved_count')).limit(10).all()
    
    return render_template('analytics.html',
                         stats=stats,
                         daily_stats=daily_stats,
                         platform_stats=platform_stats,
                         top_users=top_users)

@app.route('/settings')
@login_required
def settings():
    settings = SystemSettings.query.all()
    settings_dict = {}
    for setting in settings:
        key = setting.key or setting.setting_key
        value = setting.value or setting.setting_value
        if key:
            settings_dict[key] = value
    return render_template('settings.html', 
                         settings=settings,
                         settings_dict=settings_dict)

@app.route('/settings/update', methods=['POST'])
@login_required
def update_settings():
    try:
        for key, value in request.form.items():
            if key != 'csrf_token':
                setting = SystemSettings.query.filter(
                    or_(SystemSettings.key == key, SystemSettings.setting_key == key)
                ).first()
                
                if setting:
                    if setting.key:
                        setting.value = value
                    if setting.setting_key:
                        setting.setting_value = value
                    setting.updated_at = datetime.utcnow()
                    setting.updated_by = current_user.id
                else:
                    setting = SystemSettings(
                        key=key,
                        value=value,
                        setting_key=key,
                        setting_value=value,
                        updated_by=current_user.id
                    )
                    db.session.add(setting)
        
        db.session.commit()
        log_action('UPDATE_SETTINGS', details='Обновлены настройки системы')
        flash('Настройки успешно обновлены!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при обновлении настроек: {str(e)}', 'danger')
    
    return redirect(url_for('settings'))

@app.route('/logs')
@login_required
def logs():
    page = request.args.get('page', 1, type=int)
    action_filter = (request.args.get('action') or '').strip()
    per_page = int(request.args.get('per_page', 50))
    log_type = (request.args.get('type') or 'all').lower()  # all|system|user

    # Build base queries
    sys_q = db.session.query(
        SystemLog.timestamp.label('timestamp'),
        SystemLog.action.label('action'),
        SystemLog.details.label('details'),
        func.cast(SystemLog.ip_address, db.String).label('ip_address'),
        Admin.username.label('actor_username'),
        db.literal('system').label('source')
    ).outerjoin(Admin, SystemLog.admin_id == Admin.id)

    act_q = db.session.query(
        ActivityLog.created_at.label('timestamp'),
        ActivityLog.action.label('action'),
        ActivityLog.details.label('details'),
        func.cast(ActivityLog.ip_address, db.String).label('ip_address'),
        User.username.label('actor_username'),
        db.literal('user').label('source')
    ).outerjoin(User, ActivityLog.user_id == User.user_id)

    if action_filter:
        sys_q = sys_q.filter(SystemLog.action.ilike(f'%{action_filter}%'))
        act_q = act_q.filter(ActivityLog.action.ilike(f'%{action_filter}%'))

    # Apply type filter
    if log_type == 'system':
        combined_q = sys_q
        total = sys_q.count()
    elif log_type == 'user':
        combined_q = act_q
        total = act_q.count()
    else:
        combined_q = sys_q.union_all(act_q)
        total = sys_q.count() + act_q.count()

    ordered = combined_q.order_by(desc('timestamp'))
    offset = (page - 1) * per_page
    rows = ordered.limit(per_page).offset(offset).all()

    items = []
    for r in rows:
        items.append({
            'timestamp': r.timestamp,
            'action': r.action,
            'details': r.details,
            'ip_address': r.ip_address,
            'user': {'username': r.actor_username} if r.actor_username else None
        })

    class SimplePagination:
        def __init__(self, page, per_page, total):
            self.page = page
            self.per_page = per_page
            self.total = total
            self.pages = max(1, (total + per_page - 1) // per_page)
        @property
        def has_prev(self):
            return self.page > 1
        @property
        def has_next(self):
            return self.page < self.pages
        @property
        def prev_num(self):
            return max(1, self.page - 1)
        @property
        def next_num(self):
            return min(self.pages, self.page + 1)
        def iter_pages(self, left_edge=2, left_current=2, right_current=2, right_edge=2):
            last = 0
            for num in range(1, self.pages + 1):
                if num <= left_edge or                    (num >= self.page - left_current and num <= self.page + right_current) or                    num > self.pages - right_edge:
                    if last + 1 != num:
                        yield None
                    yield num
                    last = num

    logs_pagination = SimplePagination(page, per_page, total)

    # Collect distinct actions
    try:
        actions = [a[0] for a in db.session.query(SystemLog.action).distinct().all()]
        user_actions = [a[0] for a in db.session.query(ActivityLog.action).distinct().all()]
        actions = sorted(set(actions + user_actions))
    except Exception:
        actions = [a[0] for a in db.session.query(SystemLog.action).distinct().all()]

    return render_template('logs.html', 
                         logs=logs_pagination,
                         logs_items=items,
                         logs_total=total,
                         actions=actions,
                         current_action=action_filter)


    # Fallback: if no user ActivityLog present, synthesize from Submissions and WithdrawRequest
    try:
        synth_rows = []
        # Submissions
        sub_q = db.session.query(
            func.coalesce(Submission.submission_time, Submission.submitted_at, Submission.created_at).label('timestamp'),
            Submission.status.label('status'),
            Submission.notes.label('details'),
            User.username.label('actor_username')
        ).outerjoin(User, Submission.user_id == User.user_id).order_by(desc('timestamp')).limit(per_page)
        for r in sub_q.all():
            if r.timestamp is None:
                continue
            synth_rows.append({
                'timestamp': r.timestamp,
                'action': f"SUBMISSION_{(r.status or '').upper()}",
                'details': r.details,
                'ip_address': None,
                'user': {'username': r.actor_username} if r.actor_username else None
            })
        # Withdraw requests
        wr_q = db.session.query(
            func.coalesce(WithdrawRequest.request_time, WithdrawRequest.processed_at).label('timestamp'),
            WithdrawRequest.status.label('status'),
            WithdrawRequest.amount.label('amount'),
            User.username.label('actor_username')
        ).outerjoin(User, WithdrawRequest.user_id == User.user_id).order_by(desc('timestamp')).limit(per_page)
        for r in wr_q.all():
            if r.timestamp is None:
                continue
            details = f"withdraw {r.amount}"
            synth_rows.append({
                'timestamp': r.timestamp,
                'action': f"WITHDRAW_{(r.status or '').upper()}",
                'details': details,
                'ip_address': None,
                'user': {'username': r.actor_username} if r.actor_username else None
            })
        # Merge synth rows into items if items empty
        if not items and synth_rows:
            synth_rows = sorted(synth_rows, key=lambda x: x['timestamp'], reverse=True)
            items = synth_rows[:per_page]
            logs_pagination = SimplePagination(page, per_page, len(items))
    except Exception as _e:
        try:
            print('synth activity error:', _e)
        except Exception:
            pass

@app.route('/export/users')
@login_required
def export_users():
    users = User.query.all()
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Username', 'Full Name', 'Balance', 'Points', 'Total Earnings', 'Registration Date', 'Is Banned'])
    
    for user in users:
        writer.writerow([
            user.user_id,
            user.username,
            user.full_name,
            user.balance,
            user.points,
            user.total_earnings,
            user.registration_date.strftime('%Y-%m-%d %H:%M:%S') if user.registration_date else '',
            user.is_banned
        ])
    
    output.seek(0)
    log_action('EXPORT_USERS', details='Экспорт данных пользователей')
    
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'users_export_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    )

# --- API ENDPOINTS ---

@app.route('/api/stats/daily_submissions')
@login_required
def api_daily_submissions():
    """API для получения ежедневной статистики выполнений"""
    days = request.args.get('days', 7, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    stats = db.session.query(
        func.date(Submission.submission_time).label('date'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved'),
        func.count(case([(Submission.status == 'rejected', 1)])).label('rejected')
    ).filter(Submission.submission_time >= start_date)\
     .group_by(func.date(Submission.submission_time))\
     .order_by(func.date(Submission.submission_time)).all()
    
    labels = []
    approved_data = []
    rejected_data = []
    
    for stat in stats:
        labels.append(stat.date.strftime('%d.%m'))
        approved_data.append(stat.approved)
        rejected_data.append(stat.rejected)
    
    return jsonify({
        'labels': labels,
        'approved': approved_data,
        'rejected': rejected_data
    })

@app.route('/api/stats/platform_distribution')
@login_required
def api_platform_distribution():
    """API для получения распределения заданий по платформам"""
    stats = db.session.query(
        Task.platform,
        func.count(Task.id).label('count')
    ).group_by(Task.platform).all()
    
    return jsonify({
        'labels': [stat.platform for stat in stats],
        'data': [stat.count for stat in stats]
    })

@app.route('/api/stats/earnings_timeline')
@login_required
def api_earnings_timeline():
    """API для получения временной линии заработка"""
    days = request.args.get('days', 30, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    stats = db.session.query(
        func.date(Submission.review_time).label('date'),
        func.sum(func.coalesce(Task.reward_money, Task.price, 0)).label('total_earned')
    ).join(Task).filter(
        and_(
            Submission.status == 'approved',
            Submission.review_time >= start_date
        )
    ).group_by(func.date(Submission.review_time))\
     .order_by(func.date(Submission.review_time)).all()
    
    labels = []
    earnings_data = []
    
    for stat in stats:
        labels.append(stat.date.strftime('%d.%m'))
        earnings_data.append(float(stat.total_earned or 0))
    
    return jsonify({
        'labels': labels,
        'earnings': earnings_data
    })

@app.route('/create-first-admin-temp')
def create_first_admin_temp():
    """Временный роут для создания первого администратора"""
    try:
        # Проверяем, есть ли уже администраторы
        if Admin.query.count() > 0:
            return "Администратор уже существует!"
        
        # Создаем первого администратора
        admin = Admin(username='admin', role='super_admin')
        admin.set_password('admin123')  # Измените на безопасный пароль!
        
        db.session.add(admin)
        db.session.commit()
        
        return "Первый администратор создан! Username: admin, Password: admin123"
    except Exception as e:
        return f"Ошибка при создании администратора: {str(e)}"

# --- ОБРАБОТЧИКИ ОШИБОК ---

@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html', 
                         error_code=404, 
                         error_message="Страница не найдена"), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('error.html', 
                         error_code=500, 
                         error_message="Внутренняя ошибка сервера"), 500

# --- ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ ---

def init_default_settings():
    """Инициализация настроек по умолчанию"""
    default_settings = [
        ('min_withdrawal_amount', '200', 'Минимальная сумма для вывода средств'),
        ('max_withdrawal_amount', '50000', 'Максимальная сумма для вывода средств'),
        ('withdrawal_fee_percent', '0', 'Комиссия за вывод средств (%)'),
        ('auto_approve_threshold', '1000', 'Автоматическое одобрение для пользователей с суммарным заработком выше'),
        ('daily_withdrawal_limit', '3', 'Лимит заявок на вывод в день на пользователя'),
        ('system_maintenance', 'false', 'Режим технического обслуживания'),
        ('new_user_bonus', '10', 'Бонус для новых пользователей'),
    ]
    
    for key, value, description in default_settings:
        existing = SystemSettings.query.filter(
            or_(SystemSettings.key == key, SystemSettings.setting_key == key)
        ).first()
        
        if not existing:
            setting = SystemSettings(
                key=key, 
                value=value, 
                setting_key=key,
                setting_value=value,
                description=description
            )
            db.session.add(setting)
    
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Ошибка при инициализации настроек: {e}")

# --- ЗАПУСК ПРИЛОЖЕНИЯ ---

# Защита от повторного определения роутов
if not hasattr(dashboard, '_routes_defined'):
    dashboard._routes_defined = True


# === ИНТЕГРАЦИОННЫЕ ФУНКЦИИ ===

# --- patched notify functions with logging ---
def notify_bot_about_approval(user_id, submission_id, reward_money):
    """Уведомление бота об одобрении заявки"""
    try:
        BOT_API_URL = os.getenv("BOT_API_URL", "https://botseo-angel2804.amvera.io")
        url = f"{BOT_API_URL}/api/submission_approved"
        payload = {
            'user_id': user_id,
            'submission_id': submission_id,
            'reward_money': int(float(reward_money or 0))
        }
        print(f'[notify] Отправка уведомления об одобрении: URL={url}, payload={payload}')
        response = requests.post(url, json=payload, timeout=5)
        print(f'[notify] Ответ бота: status={response.status_code}, response={response.text[:200]}')
    except Exception as e:
        print(f'[notify error] Ошибка при отправке уведомления об одобрении: {e}')

def notify_bot_about_rejection(user_id, submission_id, reason):
    """Уведомление бота об отклонении заявки"""
    try:
        BOT_API_URL = os.getenv("BOT_API_URL", "https://botseo-angel2804.amvera.io")
        url = f"{BOT_API_URL}/api/submission_rejected"
        payload = {
            'user_id': user_id,
            'submission_id': submission_id,
            'reason': reason
        }
        print(f'[notify] Отправка уведомления об отклонении: URL={url}, payload={payload}')
        response = requests.post(url, json=payload, timeout=5)
        print(f'[notify] Ответ бота: status={response.status_code}, response={response.text[:200]}')
    except Exception as e:
        print(f'[notify error] Ошибка при отправке уведомления об отклонении: {e}')
def notify_bot_withdraw(user_id, request_id, status, amount, reason=None, notes=None, transaction_id=None):
    """Уведомление бота о статусе заявки на вывод"""
    try:
        BOT_API_URL = os.getenv("BOT_API_URL", "https://botseo-angel2804.amvera.io")
        payload = {
            'user_id': user_id,
            'request_id': request_id,
            'status': status,
            'amount': int(float(amount or 0))
        }
        if reason:
            payload['reason'] = reason
        if notes:
            payload['notes'] = notes
        if transaction_id:
            payload['transaction_id'] = transaction_id
        url = f"{BOT_API_URL}/api/withdraw_update"
        print(f'[notify] Отправка уведомления о выводе: URL={url}, payload={payload}')
        response = requests.post(url, json=payload, timeout=5)
        print(f'[notify] Ответ бота: status={response.status_code}, response={response.text[:200]}')
    except Exception as e:
        print(f'[notify_bot_withdraw error] Ошибка при отправке уведомления о выводе: {e}')


# API endpoints для интеграции с веб-аппом
@app.route('/api/new_submission', methods=['POST'])
def api_new_submission():
    """API для получения уведомления о новой заявке от веб-аппа"""
    try:
        data = request.get_json()
        submission_id = data.get('submission_id')
        
        # Здесь можно добавить дополнительную логику для уведомлений админов
        # например, отправка email или push-уведомления
        
        return jsonify({'success': True, 'message': 'Уведомление получено'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# Маршрут для отдачи локальных файлов из static/uploads
@app.route('/uploads/<path:filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=False)

def _is_http_url(val: str) -> bool:
    return isinstance(val, str) and val.lower().startswith(('http://', 'https://'))

def _is_tg_file_id(val: str) -> bool:
    # file_id в ТГ обычно длинная строка из символов A–Z a–z 0–9 - _
    # Это простой хелпер, чтобы отличить от обычного имени файла
    return isinstance(val, str) and len(val) > 30 and not any(ch in val for ch in ('/', '\\', ' ')) and not _is_http_url(val)

def _download_telegram_file(file_id: str) -> str | None:
    """
    Скачиваем файл по Telegram file_id и кэшируем в static/uploads.
    Требуется TELEGRAM_BOT_TOKEN или BOT_TOKEN в env.
    Возвращаем имя сохраненного файла (str) или None.
    """
    token = os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('BOT_TOKEN')
    if not token:
        return None

    try:
        # 1) Узнаём file_path
        r = requests.get(f'https://api.telegram.org/bot{token}/getFile', params={'file_id': file_id}, timeout=10)
        r.raise_for_status()
        data = r.json()
        file_path = data.get('result', {}).get('file_path')
        if not file_path:
            return None

        # 2) Скачиваем файл
        file_url = f'https://api.telegram.org/file/bot{token}/{file_path}'
        resp = requests.get(file_url, timeout=15)
        resp.raise_for_status()

        # 3) Генерим имя и сохраняем
        ext = os.path.splitext(file_path)[1] or '.jpg'
        safe_name = hashlib.sha256(file_id.encode('utf-8')).hexdigest() + ext
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], safe_name)
        with open(save_path, 'wb') as f:
            f.write(resp.content)
        return safe_name
    except Exception as e:
        print('tg download error:', e)
        return None

def build_screenshot_url(subm) -> str | None:
    # 1) если уже есть URL — используем его
    if getattr(subm, 'screenshot_url', None):
        return subm.screenshot_url

    fid = getattr(subm, 'screenshot_file_id', None)
    if not fid:
        return None

    # 2) если это http/https — тоже сразу отдаем
    if _is_http_url(fid):
        return fid

    # 3) если это телеграм file_id — пробуем скачать и отдать локально
    if _is_tg_file_id(fid):
        fname = _download_telegram_file(fid)
        if fname:
            return url_for('uploaded_file', filename=fname)

    # 4) иначе считаем, что это имя файла, лежащее в static/uploads
    return url_for('uploaded_file', filename=fid)

# ПАТЧ роута submissions: добавляем «фолбэк» перед отдачей в шаблон
# Найди в app.py функцию submissions() и ДО return render_template(...) добавь:
# (Если не хочешь править внутри — можно оставить как есть и вставить этот «пост-хук» ниже
# через прокручивание items, как в примере.)
@app.after_request
def _no_cache(resp):
    # просто чтобы браузер не кэшировал при дебаге
    resp.headers['Cache-Control'] = 'no-store'
    return resp

# Если не хочешь править тело функции — можно использовать before_render в лоб:
# но проще отредактировать сам роут. Вот универсальный хелпер:
def enrich_submission_screenshot_urls(pagination_obj):
    try:
        items = getattr(pagination_obj, 'items', None) or []
        changed = False
        for s in items:
            if not getattr(s, 'screenshot_url', None):
                url = build_screenshot_url(s)
                if url:
                    # временно для рендера
                    s.screenshot_url = url
                    # при желании — сохраним в БД
                    try:
                        db.session.add(s)
                        changed = True
                    except Exception:
                        pass
        if changed:
            try:
                db.session.commit()
            except Exception:
                db.session.rollback()
    except Exception as e:
        print('enrich error:', e)
    return pagination_obj

# Хук: подменим render_template в одном месте, чтобы не лазить в код роута
# ВНИМАНИЕ: если не хочется, закомментируй и просто вставь вызов enrich_submission_screenshot_urls()
# прямо в конец функции submissions перед render_template(...)
from flask import _app_ctx_stack
_real_render_template = render_template
def _patched_render_template(template_name, *args, **kwargs):
    if template_name == 'submissions.html' and 'submissions' in kwargs:
        kwargs['submissions'] = enrich_submission_screenshot_urls(kwargs['submissions'])
    return _real_render_template(template_name, *args, **kwargs)
# Подмена
render_template = _patched_render_template
# === end uploads/screenshot patch ===

# Support models (добавляем в конец после других моделей)
class SupportTicket(db.Model):
    __tablename__ = 'support_tickets'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False)
    username = db.Column(db.String)
    full_name = db.Column(db.String)
    subject = db.Column(db.String)
    message = db.Column(db.Text)
    status = db.Column(db.String, default='open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

class SupportMessage(db.Model):
    __tablename__ = 'support_messages'
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, nullable=False)
    sender = db.Column(db.String)  # 'user' | 'admin'
    admin_id = db.Column(db.Integer)
    message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Support routes

@app.route('/support')
@login_required
def support_list():
    try:
        q = (request.args.get('q') or '').strip()
        status = (request.args.get('status') or '').strip()
        page = int(request.args.get('page', 1))
        per_page = 20
        query = SupportTicket.query
        if q:
            like = f"%{q}%"
            query = query.filter(or_(SupportTicket.subject.ilike(like), SupportTicket.username.ilike(like), SupportTicket.full_name.ilike(like)))
        if status:
            query = query.filter(SupportTicket.status == status)
        page_obj = query.order_by(desc(SupportTicket.updated_at)).paginate(page=page, per_page=per_page, error_out=False)
        tickets = list(getattr(page_obj, 'items', []))
        return render_template('support_list.html', tickets=tickets, q=q, status=status, pagination=page_obj)
    except Exception as e:
        flash(f'Ошибка при загрузке тикетов: {e}', 'error')
        return render_template('support_list.html', tickets=[], q='', status='', pagination=None)


@app.route('/support/<int:ticket_id>', methods=['GET', 'POST'])
@login_required
def support_detail(ticket_id):
    try:
        ticket = SupportTicket.query.get_or_404(ticket_id)
        if request.method == 'POST':
            action = (request.form.get('action') or '').strip()
            if action == 'reply':
                msg_text = (request.form.get('message') or '').strip()
                if msg_text:
                    m = SupportMessage(ticket_id=ticket.id, sender='admin', admin_id=current_user.id, message=msg_text)
                    db.session.add(m)
                    if ticket.status != 'closed':
                        ticket.status = 'answered'
                    ticket.updated_at = datetime.utcnow()
                    db.session.commit()
                    try:
                        bot_url = os.environ.get('BOT_API_URL', 'https://botseo-angel2804.amvera.io')
                        requests.post(f"{bot_url}/api/support_reply", json={
                            'user_id': int(ticket.user_id),
                            'ticket_id': ticket.id,
                            'message': msg_text
                        }, timeout=5)
                    except Exception as _e:
                        print('notify support_reply failed:', _e)
                    flash('Ответ отправлен пользователю', 'success')
            elif action == 'status':
                new_status = (request.form.get('status') or '').strip()
                if new_status and new_status != ticket.status:
                    ticket.status = new_status
                    ticket.updated_at = datetime.utcnow()
                    db.session.commit()
                    try:
                        bot_url = os.environ.get('BOT_API_URL', 'https://botseo-angel2804.amvera.io')
                        requests.post(f"{bot_url}/api/support_status", json={
                            'user_id': int(ticket.user_id),
                            'ticket_id': ticket.id,
                            'status': new_status
                        }, timeout=5)
                    except Exception as _e:
                        print('notify support_status failed:', _e)
                    flash('Статус тикета обновлен', 'success')
            return redirect(url_for('support_detail', ticket_id=ticket.id))

        messages = SupportMessage.query.filter_by(ticket_id=ticket.id).order_by(SupportMessage.created_at.asc()).all()
        return render_template('support_detail.html', ticket=ticket, messages=messages)
    except Exception as e:
        flash('Ошибка при загрузке тикета поддержки', 'error')
        return redirect(url_for('support_list'))

if __name__ == '__main__':
    with app.app_context():
        try:
            db.create_all()
            init_default_settings()
            print("База данных инициализирована успешно!")
        except Exception as e:
            print(f"Ошибка при инициализации базы данных: {e}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)


from flask import send_from_directory
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)



@app.route('/submissions/export')
@login_required
def submissions_export():
    """Экспорт текущей выборки в CSV"""
    status = request.args.get('status', 'all')
    platform = request.args.get('platform', 'all')
    q = (request.args.get('q') or '').strip()

    query = Submission.query.join(Task, Submission.task_id == Task.id).outerjoin(User, User.user_id == Submission.user_id)

    if status != 'all':
        query = query.filter(Submission.status == status)
    if platform and platform != 'all':
        query = query.filter(Task.platform == platform)
    if q:
        query = query.filter(or_(
            Task.title.ilike(f"%{q}%"),
            Task.description.ilike(f"%{q}%"),
            User.username.ilike(f"%{q}%"),
            Submission.fio.ilike(f"%{q}%"),
            Submission.full_name.ilike(f"%{q}%"),
        ))

    rows = query.order_by(desc(Submission.submission_time)).all()

    import csv, io
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(['submission_id','status','submitted_at','user_id','username','task_id','task_title','platform','reward_money','reward_points','fio','notes','screenshot_url'])
    for s in rows:
        notes_clean = (s.notes or '').replace('\n',' ').replace('\r',' ')
        writer.writerow([
            s.id,
            s.status,
            s.submission_time.strftime('%Y-%m-%d %H:%M:%S') if s.submission_time else '',
            s.user_id,
            s.user.username if getattr(s, 'user', None) else '',
            s.task_id,
            s.task.title if getattr(s, 'task', None) else '',
            s.task.platform if getattr(s, 'task', None) else '',
            str(getattr(s.task, 'reward_money', '') or ''),
            getattr(s.task, 'reward_points', '') or '',
            s.fio or s.full_name or '',
            notes_clean,
            s.screenshot_url or '',
        ])
    buf.seek(0)

    from flask import Response
    return Response(buf.getvalue(), mimetype='text/csv', headers={
        'Content-Disposition': 'attachment; filename=submissions_export.csv'
    })


@app.before_first_request
def ensure_denorm_columns():
    try:
        stmts = [
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_reward_money numeric(10,2)",
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_reward_points integer",
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_platform text",
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_task_title text"
        ]
        for s in stmts:
            try:
                db.session.execute(s)
                db.session.commit()
            except Exception:
                db.session.rollback()
    except Exception as e:
        try: db.session.rollback()
        except Exception: pass
        print('ensure_denorm_columns error:', e)


@app.route('/api/stats/active_users')
@login_required
def api_active_users():
    """Daily Active Users (DAU) for last N days based on submissions."""
    days = request.args.get('days', 30, type=int)
    if days < 1:
        days = 1
    if days > 365:
        days = 365
    start_date = (datetime.utcnow() - timedelta(days=days-1)).date()
    rows = db.session.query(
        func.date(Submission.submission_time).label('d'),
        func.count(distinct(Submission.user_id)).label('cnt')
    ).filter(Submission.submission_time >= start_date)
    rows = rows.group_by(func.date(Submission.submission_time))               .order_by(func.date(Submission.submission_time))               .all()
    data_map = {r.d: int(r.cnt or 0) for r in rows}
    labels = []
    data = []
    for i in range(days):
        d = start_date + timedelta(days=i)
        labels.append(d.strftime('%d.%m'))
        data.append(int(data_map.get(d, 0)))
    return jsonify({'labels': labels, 'data': data})


@app.route('/api/users/<int:user_id>/ping', methods=['POST', 'GET'])
def update_last_activity(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({'success': False, 'error': 'user_not_found'}), 404
    user.last_activity = datetime.utcnow()
    try:
        db.session.commit()
        return jsonify({'success': True, 'user_id': user_id, 'last_activity': user.last_activity.isoformat()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/tasks')
@login_required
def tasks():
    owner = request.args.get('owner')
    partner = request.args.get('partner')
    show = request.args.get('show', 'active')  # active | archived | all

    current_owner = 'my' if not (partner and partner.strip()) else partner.strip()

    query = Task.query
    if current_owner == 'my':
        query = query.filter(or_(Task.direction.is_(None), func.trim(Task.direction) == ''))
    else:
        query = query.filter(Task.direction == current_owner)

    if show == 'active':
        query = query.filter(Task.is_active.is_(True))
    elif show == 'archived':
        query = query.filter(Task.is_active.is_(False))

    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 15))
    tasks = query.order_by(desc(Task.created_at)).paginate(page=page, per_page=per_page, error_out=False)

    try:
        total = tasks.total
        start_idx = (tasks.page - 1) * tasks.per_page + 1 if total > 0 else 0
        end_idx = min(tasks.page * tasks.per_page, total)
        setattr(tasks, 'page_min', start_idx)
        setattr(tasks, 'page_max', end_idx)
    except Exception:
        pass

    partners = get_partners_list()

    return render_template(
        'tasks_partner_paged.html',
        tasks=tasks,
        platforms=PLATFORMS,
        partners=partners,
        current_owner=current_owner,
        show=show
    )



@app.route('/tasks/new', methods=['GET', 'POST'])
@login_required
def new_task():
    owner = request.args.get('owner')
    partner = request.args.get('partner')
    if request.method == 'POST':
        try:
            reward_money = request.form.get('reward_money', '').strip() or request.form.get('price', '0').strip()
            reward_points = request.form.get('reward_points', '').strip()
            submission_limit = request.form.get('submission_limit', '').strip()
            priority = request.form.get('priority', '').strip()
            try:
                reward_money_val = float(reward_money) if reward_money else 0.0
            except (ValueError, TypeError):
                reward_money_val = 0.0
            try:
                reward_points_val = int(reward_points) if reward_points else 0
            except (ValueError, TypeError):
                reward_points_val = 0
            try:
                submission_limit_val = int(submission_limit) if submission_limit else 10
            except (ValueError, TypeError):
                submission_limit_val = 10
            try:
                priority_val = int(priority) if priority else 0
            except (ValueError, TypeError):
                priority_val = 0

            direction_val = request.form.get('direction')
            if direction_val is None:
                direction_val = partner or ''

            task = Task(
                title=request.form.get('title', f"Задание на {request.form.get('platform','')}") ,
                platform=request.form['platform'],
                description=request.form['description'],
                category=request.form.get('category', 'review'),
                status='active',
                price=reward_money_val,
                reward_money=reward_money_val,
                reward_points=reward_points_val,
                submission_limit=submission_limit_val,
                task_url=request.form.get('task_url', ''),
                instruction_link=request.form.get('instruction_link', ''),
                city=request.form.get('city', ''),
                direction=direction_val,
                is_active='is_active' in request.form,
                priority=priority_val
            )
            db.session.add(task)
            db.session.commit()
            try:
                log_action('CREATE_TASK', 'task', task.id, f'Создано задание: {task.description[:50]}')
            except Exception:
                pass
            flash('Задание успешно создано!', 'success')
            if direction_val:
                return redirect(url_for('tasks', partner=direction_val))
            else:
                return redirect(url_for('tasks', owner='my'))
        except Exception as e:
            db.session.rollback()
            try:
                log_action('ERROR', details=f'Ошибка при создании задания: {str(e)}')
            except Exception:
                pass
            flash(f'Ошибка при создании задания: {str(e)}', 'danger')
    partners = get_partners_list()
    return render_template('task_form.html', platforms=PLATFORMS, task=None, title='Создать новое задание', owner=owner or 'my', partner=partner, partners=partners)




@app.route('/submissions')
@login_required
def submissions():
    status = request.args.get('status', 'pending')
    platform = (request.args.get('platform') or 'all').strip()
    q = (request.args.get('q') or '').strip()
    owner = request.args.get('owner')
    partner = request.args.get('partner')
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 50))

    current_owner = 'my' if not (partner and partner.strip()) else partner.strip()

    aliases = {
        'yandex': 'Яндекс Карты', 'яндекс': 'Яндекс Карты', 'ymaps': 'Яндекс Карты',
        'google': 'Google Карты', 'гугл': 'Google Карты', 'gmap': 'Google Карты',
        '2gis': '2ГИС', 'дегис': '2ГИС',
        'avito': 'Авито', 'авито': 'Авито',
        'ozon': 'Ozon', 'озон': 'Ozon',
        'wb': 'Wildberries', 'wildberries': 'Wildberries', 'вб': 'Wildberries',
        'zoon': 'Zoon', 'зун': 'Zoon',
        'browser': 'Яндекс Браузер', 'yabrowser': 'Яндекс Браузер',
        'other': 'Другое', 'другое': 'Другое'
    }
    platform_value = None if platform == 'all' else aliases.get(platform.lower(), platform)

    query = db.session.query(Submission).join(Task, Task.id == Submission.task_id)
    if status != 'all':
        query = query.filter(Submission.status == status)
    if platform_value:
        query = query.filter(Task.platform.ilike(platform_value))

    if current_owner == 'my':
        query = query.filter(or_(Task.direction.is_(None), func.trim(Task.direction) == ''))
    else:
        query = query.filter(Task.direction == current_owner)

    from sqlalchemy import or_ as _or
    search_filters = []
    if q:
        if q.isdigit():
            search_filters.extend([
                Submission.user_id == int(q),
                Submission.task_id == int(q)
            ])
        like_q = f"%{q}%"
        search_filters.extend([
            Submission.fio.ilike(like_q),
            Submission.notes.ilike(like_q),
            Task.title.ilike(like_q),
            Task.description.ilike(like_q),
            Task.platform.ilike(like_q)
        ])
        query = query.filter(_or(*search_filters))

    submissions = query.order_by(desc(Submission.submission_time)).paginate(page=page, per_page=per_page, error_out=False)

    count_q = db.session.query(Task.platform, func.count(Submission.id)).join(Submission)
    if status != 'all':
        count_q = count_q.filter(Submission.status == status)
    if q:
        count_q = count_q.filter(_or(*search_filters))
    if current_owner == 'my':
        count_q = count_q.filter(or_(Task.direction.is_(None), func.trim(Task.direction) == ''))
    else:
        count_q = count_q.filter(Task.direction == current_owner)

    platform_counts_pairs = count_q.group_by(Task.platform).all()
    platform_counts = {k: int(v) for k, v in platform_counts_pairs}

    try:
        all_platforms = PLATFORMS
    except Exception:
        all_platforms = sorted({k for k in platform_counts.keys()})
    for p in all_platforms:
        platform_counts.setdefault(p, 0)

    pending_count = db.session.query(func.count(Submission.id)).filter(Submission.status == 'pending').scalar() or 0

    partners = get_partners_list()

    return render_template(
        'submissions.html',
        submissions=submissions,
        current_status=status,
        platform=platform,
        platform_counts=platform_counts,
        PLATFORMS=all_platforms,
        q=q,
        per_page=per_page,
        pending_submissions_count=pending_count,
        partners=partners,
        current_owner=current_owner
    )



@app.route('/tools/fix_direction', methods=['GET', 'POST'])
@login_required
def fix_direction_tool():
    from datetime import datetime
    updated = 0
    if request.method == 'POST':
        partner = (request.form.get('partner') or '').strip()
        created_after = (request.form.get('created_after') or '').strip()
        created_before = (request.form.get('created_before') or '').strip()
        platform = (request.form.get('platform') or '').strip()
        q = Task.query.filter(or_(Task.direction.is_(None), func.trim(Task.direction) == ''))
        if created_after:
            try:
                dt = datetime.fromisoformat(created_after)
                q = q.filter(Task.created_at >= dt)
            except Exception:
                pass
        if created_before:
            try:
                dtb = datetime.fromisoformat(created_before)
                q = q.filter(Task.created_at <= dtb)
            except Exception:
                pass
        if platform:
            q = q.filter(Task.platform.ilike(platform))
        if partner:
            updated = q.update({Task.direction: partner}, synchronize_session=False)
            db.session.commit()
            flash(f'Обновлено задач: {updated}.', 'success')
        else:
            flash('Укажите партнёра.', 'warning')
    return render_template('tools_fix_direction.html', updated=updated)