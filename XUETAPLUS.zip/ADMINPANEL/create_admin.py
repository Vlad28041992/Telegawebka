#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Скрипт для создания администратора в админ панели
"""
import os
import sys
import datetime
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

# Конфигурация приложения
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-super-secret-key-for-dev')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Admin(UserMixin, db.Model):
    __tablename__ = 'admin'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)

    def set_password(self, password):
        self.password = str(password)

    def check_password(self, password):
        return str(self.password) == str(password)

    def get_id(self):
        return str(self.id)

def create_admin():
    """Создать администратора"""
    with app.app_context():
        try:
            # Создаем таблицы если их нет
            db.create_all()
            
            # Проверяем, есть ли уже админ
            existing_admin = Admin.query.filter_by(username='admin').first()
            if existing_admin:
                print("Администратор 'admin' уже существует")
                print(f"ID: {existing_admin.id}")
                print(f"Создан: {existing_admin.created_at}")
                print(f"Активен: {existing_admin.is_active}")
                
                # Обновляем пароль на всякий случай
                existing_admin.set_password('admin123')
                existing_admin.is_active = True
                db.session.commit()
                print("Пароль обновлен на 'admin123'")
            else:
                # Создаем нового админа
                new_admin = Admin(username='admin', role='admin')
                new_admin.set_password('admin123')
                new_admin.is_active = True
                db.session.add(new_admin)
                db.session.commit()
                print("Создан новый администратор:")
                print("Логин: admin")
                print("Пароль: admin123")
                
        except Exception as e:
            print(f"Ошибка при создании администратора: {e}")
            db.session.rollback()

if __name__ == '__main__':
    create_admin()
