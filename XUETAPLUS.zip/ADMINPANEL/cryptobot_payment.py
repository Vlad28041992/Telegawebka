import requests
from decimal import Decimal
import traceback

class CryptoBotAPI:
    """
    Класс для работы с CryptoBot API
    Документация: https://help.crypt.bot/crypto-pay-api
    """
    
    def __init__(self, api_token):
        self.api_token = api_token
        self.base_url = 'https://pay.crypt.bot/api'
        self.headers = {
            'Crypto-Pay-API-Token': api_token
        }
        
        # Минимальная сумма вывода в рублях
        self.MIN_WITHDRAWAL_RUB = 100
        
        # Курс конвертации (обновляется при инициализации)
        self.RUB_TO_USDT_RATE = 95.0  # Примерный курс, будет обновляться
        
        print(f"[CRYPTOBOT] Инициализация с токеном: {api_token[:20]}...")
    
    def get_me(self):
        """Получить информацию о приложении"""
        try:
            print("[CRYPTOBOT] Запрос getMe...")
            response = requests.get(
                f'{self.base_url}/getMe',
                headers=self.headers,
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            print(f"[CRYPTOBOT] getMe response: {data}")
            return data
        except Exception as e:
            print(f"[CRYPTOBOT ERROR] getMe failed: {e}")
            traceback.print_exc()
            return {'ok': False, 'error': str(e)}
    
    def get_balance(self):
        """Получить баланс кошелька"""
        try:
            print("[CRYPTOBOT] Запрос getBalance...")
            response = requests.get(
                f'{self.base_url}/getBalance',
                headers=self.headers,
                timeout=10
            )
            print(f"[CRYPTOBOT] getBalance status: {response.status_code}")
            response.raise_for_status()
            data = response.json()
            print(f"[CRYPTOBOT] getBalance response: {data}")
            
            if data.get('ok'):
                # Находим баланс USDT
                balances = data.get('result', [])
                print(f"[CRYPTOBOT] Доступные балансы: {balances}")
                
                for balance_info in balances:
                    currency = balance_info.get('currency_code')
                    available = balance_info.get('available', 0)
                    print(f"[CRYPTOBOT]   {currency}: {available}")
                    
                    if currency == 'USDT':
                        result = {
                            'ok': True,
                            'balance': float(available),
                            'currency': 'USDT'
                        }
                        print(f"[CRYPTOBOT] Возвращаем: {result}")
                        return result
                
                # Если USDT не найден
                print("[CRYPTOBOT] USDT не найден в балансах")
                return {'ok': True, 'balance': 0, 'currency': 'USDT'}
            
            print(f"[CRYPTOBOT ERROR] API вернул ok=False: {data}")
            return {'ok': False, 'error': 'Failed to get balance'}
        except Exception as e:
            print(f"[CRYPTOBOT ERROR] getBalance exception: {e}")
            traceback.print_exc()
            return {'ok': False, 'error': str(e)}
    
    def validate_withdrawal(self, amount_rub):
        """
        Проверка возможности вывода средств
        
        Args:
            amount_rub: Сумма в рублях
            
        Returns:
            dict: {
                'ok': bool,
                'amount_rub': float,
                'amount_usdt': float,
                'error': str (если есть)
            }
        """
        print(f"[CRYPTOBOT] Валидация вывода: {amount_rub}₽")
        
        # Проверка минимальной суммы
        if amount_rub < self.MIN_WITHDRAWAL_RUB:
            return {
                'ok': False,
                'error': f'Минимальная сумма вывода: {self.MIN_WITHDRAWAL_RUB}₽'
            }
        
        # Конвертация в USDT
        amount_usdt = round(amount_rub / self.RUB_TO_USDT_RATE, 2)
        print(f"[CRYPTOBOT] Сумма в USDT: {amount_usdt}")
        
        # Минимальная сумма в USDT (обычно 1 USDT)
        if amount_usdt < 1:
            return {
                'ok': False,
                'error': f'Сумма после конвертации слишком мала: {amount_usdt} USDT (минимум 1 USDT)'
            }
        
        # Проверка баланса
        balance_data = self.get_balance()
        if not balance_data.get('ok'):
            return {
                'ok': False,
                'error': 'Не удалось проверить баланс кошелька'
            }
        
        available_balance = balance_data.get('balance', 0)
        print(f"[CRYPTOBOT] Доступный баланс: {available_balance} USDT")
        
        if available_balance < amount_usdt:
            return {
                'ok': False,
                'error': f'Недостаточно средств на балансе CryptoBot. Доступно: {available_balance} USDT, требуется: {amount_usdt} USDT'
            }
        
        return {
            'ok': True,
            'amount_rub': amount_rub,
            'amount_usdt': amount_usdt,
            'available_balance': available_balance
        }
    
    def transfer(self, user_id, amount_rub, comment=None):
        """
        Отправить перевод пользователю
        
        Args:
            user_id: Telegram ID пользователя
            amount_rub: Сумма в рублях
            comment: Комментарий к переводу
            
        Returns:
            dict: Результат операции
        """
        print(f"[CRYPTOBOT] Перевод пользователю {user_id}: {amount_rub}₽")
        
        # Валидация
        validation = self.validate_withdrawal(amount_rub)
        if not validation.get('ok'):
            print(f"[CRYPTOBOT] Валидация провалена: {validation.get('error')}")
            return validation
        
        amount_usdt = validation['amount_usdt']
        
        try:
            # Подготовка данных для запроса
            payload = {
                'user_id': int(user_id),
                'asset': 'USDT',
                'amount': str(amount_usdt),
                'spend_id': f'payout_{user_id}_{int(amount_rub * 100)}'  # Уникальный ID
            }
            
            if comment:
                payload['comment'] = comment[:255]  # Максимум 255 символов
            
            print(f"[CRYPTOBOT] Payload: {payload}")
            
            # Отправка запроса
            response = requests.post(
                f'{self.base_url}/transfer',
                headers=self.headers,
                json=payload,
                timeout=15
            )
            print(f"[CRYPTOBOT] Transfer status: {response.status_code}")
            response.raise_for_status()
            data = response.json()
            print(f"[CRYPTOBOT] Transfer response: {data}")
            
            if data.get('ok'):
                return {
                    'ok': True,
                    'amount_rub': amount_rub,
                    'amount_usdt': amount_usdt,
                    'transfer_id': data.get('result', {}).get('transfer_id'),
                    'message': f'Успешно отправлено {amount_usdt} USDT ({amount_rub}₽)'
                }
            else:
                error_msg = data.get('error', {}).get('name', 'Unknown error')
                print(f"[CRYPTOBOT ERROR] Transfer failed: {error_msg}")
                return {
                    'ok': False,
                    'error': f'CryptoBot API Error: {error_msg}'
                }
                
        except requests.exceptions.Timeout:
            print("[CRYPTOBOT ERROR] Timeout")
            return {
                'ok': False,
                'error': 'Превышено время ожидания ответа от CryptoBot'
            }
        except requests.exceptions.RequestException as e:
            print(f"[CRYPTOBOT ERROR] Request error: {e}")
            traceback.print_exc()
            return {
                'ok': False,
                'error': f'Ошибка запроса: {str(e)}'
            }
        except Exception as e:
            print(f"[CRYPTOBOT ERROR] Unexpected error: {e}")
            traceback.print_exc()
            return {
                'ok': False,
                'error': f'Неожиданная ошибка: {str(e)}'
            }
    
    def get_exchange_rates(self):
        """Получить курсы обмена"""
        try:
            print("[CRYPTOBOT] Запрос getExchangeRates...")
            response = requests.get(
                f'{self.base_url}/getExchangeRates',
                headers=self.headers,
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            print(f"[CRYPTOBOT] getExchangeRates response: {data}")
            
            if data.get('ok'):
                rates_list = data.get('result', [])
                # Преобразуем список в словарь для удобства
                rates_dict = {'ok': True}
                for rate in rates_list:
                    if rate.get('source') == 'USDT':
                        target = rate.get('target', '')
                        rate_value = float(rate.get('rate', 1))
                        rates_dict[target] = rate_value
                        print(f"[CRYPTOBOT]   USDT -> {target}: {rate_value}")
                        
                # Обновляем курс RUB
                if 'RUB' in rates_dict:
                    self.RUB_TO_USDT_RATE = rates_dict['RUB']
                    print(f"[CRYPTOBOT] Обновлен курс RUB: {self.RUB_TO_USDT_RATE}")
                
                return rates_dict
            
            print(f"[CRYPTOBOT ERROR] Rates API вернул ok=False: {data}")
            return {'ok': False, 'error': 'Failed to get rates'}
        except Exception as e:
            print(f"[CRYPTOBOT ERROR] getExchangeRates exception: {e}")
            traceback.print_exc()
            return {'ok': False, 'error': str(e)}


# Инициализация API
API_TOKEN = '473566:AAcaALcBj6VyNvUKW7sKPTRWHKLEncsKNsL'
cryptobot = CryptoBotAPI(API_TOKEN)
