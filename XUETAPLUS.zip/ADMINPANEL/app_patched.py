import os
import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func, case, desc, and_, or_
from sqlalchemy.exc import IntegrityError
import json
import csv
import io
from datetime import timedelta, datetime

# --- ИНИЦИАЛИЗАЦИЯ ПРИЛОЖЕНИЯ И КОНФИГУРАЦИЯ ---

app = Flask(__name__)

BOT_API_URL = os.environ.get('BOT_API_URL', 'https://bot-angel2804.amvera.io')


# Uploads config (for serving screenshots)
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Строка подключения к БД теперь будет браться из переменных окружения на Amvera
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-super-secret-key-for-dev')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ECHO'] = False # Поставить True для отладки SQL запросов

# Инициализация расширений
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = "Пожалуйста, войдите, чтобы получить доступ к этой странице."
login_manager.login_message_category = "info"

# --- КОНСТАНТЫ ---
PLATFORMS = ['Яндекс Карты', 'Google Карты', 'Авито', '2ГИС', 'Ozon', 'Wildberries', 'Zoon', 'Яндекс Браузер', 'Другое']
PAYMENT_METHODS = ['Яндекс Деньги', 'Qiwi', 'Карта']
MIN_WITHDRAWAL_AMOUNT = 200

# --- МОДЕЛИ БАЗЫ ДАННЫХ (SQLAlchemy ORM) ---

class Admin(UserMixin, db.Model):
    __tablename__ = 'admin'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)

    def set_password(self, password):
        """Хеширует и устанавливает пароль для администратора."""
        self.password = generate_password_hash(password)

    def check_password(self, password):
        """Проверяет введенный пароль с хешированным паролем администратора."""
        return check_password_hash(self.password, password)

    def get_id(self):
        """Возвращает ID пользователя, необходимый для Flask-Login."""
        return str(self.id)

class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.BigInteger, primary_key=True)
    username = db.Column(db.String(255))
    full_name = db.Column(db.String(255))
    balance = db.Column(db.Integer, default=0)  # Изменено на Integer как в реальной БД
    points = db.Column(db.Integer, default=0)
    total_points = db.Column(db.Integer, default=0)
    total_earnings = db.Column(db.Integer, default=0)  # Изменено на Integer
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    is_banned = db.Column(db.Boolean, default=False)
    ban_reason = db.Column(db.Text)

    # Обновленная связь - используем правильную таблицу submissions
    submissions = db.relationship('Submission', back_populates='user')
    withdraw_requests = db.relationship('WithdrawRequest', back_populates='user')

class Task(db.Model):
    __tablename__ = 'tasks'  # ИСПРАВЛЕНО: используем таблицу 'tasks' как в веб-аппе
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)  # ДОБАВЛЕНО: заголовок задания
    platform = db.Column(db.Text, nullable=False)  # ИСПРАВЛЕНО: text вместо string
    description = db.Column(db.Text, nullable=False)
    city = db.Column(db.Text)  # ИСПРАВЛЕНО: text как в реальной БД
    direction = db.Column(db.Text)  # ИСПРАВЛЕНО: text как в реальной БД
    category = db.Column(db.String(255))  # ДОБАВЛЕНО: категория задания
    status = db.Column(db.String(50), default='active')  # ДОБАВЛЕНО: статус задания
    price = db.Column(db.Float)  # ОСТАВЛЕНО: для совместимости
    instruction_link = db.Column(db.Text)  # Добавлено как в реальной БД
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # created_by поле отсутствует в реальной таблице tasks
    reward_money = db.Column(db.Numeric)  # Добавлено как в реальной БД
    reward_points = db.Column(db.Integer)  # Добавлено как в реальной БД
    submission_limit = db.Column(db.Integer, default=10)
    task_url = db.Column(db.String(500))
    expires_at = db.Column(db.DateTime)
    priority = db.Column(db.Integer, default=0)

    # Обновленная связь - используем правильную таблицу submissions
    submissions = db.relationship('Submission', back_populates='task', cascade='all, delete-orphan')

class Submission(db.Model):
    __tablename__ = 'submissions'  # ИСПРАВЛЕНО: используем правильную таблицу submissions
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id'), nullable=False)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')
    submission_time = db.Column(db.DateTime, default=datetime.utcnow)
    screenshot_file_id = db.Column(db.String(500))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)  # created_at - timestamp with time zone
    description = db.Column(db.Text)
    fio = db.Column(db.String(255))
    full_name = db.Column(db.String(255))
    screenshot_url = db.Column(db.String(500))
    review_time = db.Column(db.DateTime)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    rejection_reason = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime)  # ДОБАВЛЕНО: поле из реальной БД
    approved_at = db.Column(db.DateTime)   # ДОБАВЛЕНО: поле из реальной БД
    admin_comment = db.Column(db.Text)     # ДОБАВЛЕНО: поле из реальной БД

    user = db.relationship('User', back_populates='submissions')
    task = db.relationship('Task', back_populates='submissions')
    reviewer = db.relationship('Admin')


class WithdrawRequest(db.Model):
    __tablename__ = 'withdraw_requests'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id'), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    status = db.Column(db.Text, default='pending')
    request_time = db.Column(db.DateTime)
    processed_at = db.Column(db.DateTime)
    processed_time = db.Column(db.DateTime)
    processor_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    transaction_id = db.Column(db.String(255))
    created_at = db.Column(db.BigInteger)

    # Canonical columns in DB
    method = db.Column('method', db.Text)  # kept for back-compat
    details = db.Column('details', db.Text)
    notes = db.Column('notes', db.Text)

    # Alternative payment_* columns also exist in schema — map их для совместимости
    payment_method = db.Column('payment_method', db.String(100))
    payment_details = db.Column('payment_details', db.Text)
    payment_notes = db.Column('payment_notes', db.Text)
    payment_transaction_id = db.Column('payment_transaction_id', db.String(255))

    user = db.relationship('User', back_populates='withdraw_requests')
    processor = db.relationship('Admin')

class SystemLog(db.Model):
    __tablename__ = 'system_logs'
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'))
    action = db.Column(db.String(100), nullable=False)
    entity_type = db.Column(db.String(50))
    entity_id = db.Column(db.Integer)
    details = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))

    admin = db.relationship('Admin')

class SystemSettings(db.Model):
    __tablename__ = 'system_settings'
    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), nullable=False)  # Исправлено на setting_key как в реальной БД
    setting_value = db.Column(db.Text)  # Исправлено на setting_value как в реальной БД
    key = db.Column(db.String(100))  # Добавлено как в реальной БД
    value = db.Column(db.Text)  # Добавлено как в реальной БД
    description = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_by = db.Column(db.Integer, db.ForeignKey('admin.id'))

    updater = db.relationship('Admin')

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---

@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

def log_action(action, entity_type=None, entity_id=None, details=None):
    """Записывает действие в лог системы"""
    try:
        log_entry = SystemLog(
            admin_id=current_user.id if current_user.is_authenticated else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details,
            ip_address=request.remote_addr
        )
        db.session.add(log_entry)
        db.session.commit()
    except Exception as e:
        print(f"Ошибка записи в лог: {e}")

@app.context_processor
def inject_pending_counts():
    """Внедряет количество ожидающих элементов в шаблоны"""
    if current_user.is_authenticated:
        pending_submissions = Submission.query.filter_by(status='pending').count()
        pending_payouts = WithdrawRequest.query.filter_by(status='pending').count()
        return {
            'pending_submissions_count': pending_submissions,
            'pending_payouts_count': pending_payouts
        }
    return {}


# --- Jinja filter: format various date/time representations to 'dd.mm.YYYY HH:MM' ---
@app.template_filter('format_dt')
def format_dt(value):
    try:
        if value is None:
            return ''
        # epoch as int/float or string digits
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(int(value)).strftime('%d.%m.%Y %H:%M')
        if isinstance(value, str) and value.isdigit():
            return datetime.fromtimestamp(int(value)).strftime('%d.%m.%Y %H:%M')
        # datetime-like object
        if hasattr(value, 'strftime'):
            return value.strftime('%d.%m.%Y %H:%M')
        # fallback: try to cast
        try:
            iv = int(value)
            return datetime.fromtimestamp(iv).strftime('%d.%m.%Y %H:%M')
        except Exception:
            return str(value)
    except Exception:
        return ''

# --- РОУТЫ ---


# ========== ИСПРАВЛЕНИЕ: API ДЛЯ УВЕДОМЛЕНИЙ ==========
@app.route('/api/notifications/count')
@login_required
def notifications_count():
    """API для получения количества уведомлений"""
    try:
        pending_submissions = Submission.query.filter_by(status='pending').count()
        pending_payouts = WithdrawRequest.query.filter_by(status='pending').count()
        return jsonify({
            'success': True,
            'total': pending_submissions + pending_payouts,
            'submissions': pending_submissions,
            'payouts': pending_payouts
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/notifications/list')
@login_required  
def notifications_list():
    """API для получения списка уведомлений"""
    try:
        notifications = []
        # Заявки на выполнение
        pending_submissions = Submission.query.filter_by(status='pending').order_by(desc(Submission.submission_time)).limit(5).all()
        for sub in pending_submissions:
            notifications.append({
                'type': 'submission', 'id': sub.id, 'title': 'Новое выполнение задания',
                'message': f'Пользователь выполнил задание #{sub.task_id}',
                'time': sub.submission_time.strftime('%H:%M') if sub.submission_time else '',
                'url': url_for('submissions', status='pending')
            })
        # Заявки на вывод
        pending_payouts = WithdrawRequest.query.filter_by(status='pending').order_by(desc(WithdrawRequest.request_time)).limit(5).all()
        for payout in pending_payouts:
            notifications.append({
                'type': 'payout', 'id': payout.id, 'title': 'Новая заявка на вывод',
                'message': f'Запрос на вывод {payout.amount}₽',
                'time': payout.request_time.strftime('%H:%M') if payout.request_time else '',
                'url': url_for('payouts', status='pending')
            })
        notifications.sort(key=lambda x: x['time'], reverse=True)
        return jsonify({'success': True, 'notifications': notifications[:10]})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/login', methods=['GET', 'POST'])
def login():
    # ИСПРАВЛЕНИЕ: передаем пустые счетчики для неавторизованных пользователей
    context = {
        'pending_submissions_count': 0,
        'pending_payouts_count': 0
    }
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and admin.check_password(password) and admin.is_active:
            login_user(admin)
            admin.last_login = datetime.utcnow()
            db.session.commit()
            log_action('LOGIN', details=f'Успешный вход пользователя {username}')
            flash('Добро пожаловать!', 'success')
            return redirect(url_for('dashboard'))
        else:
            log_action('LOGIN_FAILED', details=f'Неудачная попытка входа: {username}')
            flash('Неверное имя пользователя или пароль', 'danger')
    
    return render_template('login.html', **context)

@app.route('/logout')
@login_required
def logout():
    log_action('LOGOUT', details=f'Выход пользователя {current_user.username}')
    logout_user()
    flash('Вы успешно вышли из системы', 'info')
    return redirect(url_for('login'))

@app.route('/')
@app.route('/dashboard')
@login_required
def dashboard():
    # Статистика для карточек
    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter(User.last_activity >= datetime.utcnow() - timedelta(days=7)).count(),
        'active_tasks': Task.query.filter_by(status='active').count(),
        'total_earnings': db.session.query(func.sum(User.total_earnings)).scalar() or 0,
        'pending_withdrawals': WithdrawRequest.query.filter_by(status='pending').count(),
        'total_submissions': Submission.query.count(),
        'pending_submissions': Submission.query.filter_by(status='pending').count(),
        'approved_submissions': Submission.query.filter_by(status='approved').count(),
        'rejected_submissions': Submission.query.filter_by(status='rejected').count(),
    }
    
    # Последние ожидающие заявки
    recent_submissions = Submission.query.filter_by(status='pending')\
        .order_by(desc(Submission.submission_time)).limit(10).all()
    
    # Статистика по платформам
    platform_stats = db.session.query(
        Task.platform,
        func.count(Submission.id).label('submissions_count')
    ).join(Submission).group_by(Task.platform).all()
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         recent_submissions=recent_submissions,
                         platform_stats=platform_stats)

@app.route('/tasks')
@login_required
def tasks():
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 15))
    
    tasks = Task.query.order_by(desc(Task.created_at))\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('tasks_fixed_final.html', tasks=tasks, platforms=PLATFORMS)

@app.route('/tasks/new', methods=['GET', 'POST'])
@login_required
def new_task():
    if request.method == 'POST':
        try:
            # Получаем данные из формы с защитой от None и пустых строк
            reward_money = request.form.get('reward_money', '').strip()
            if not reward_money:
                reward_money = request.form.get('price', '0').strip()
            
            reward_points = request.form.get('reward_points', '').strip()
            submission_limit = request.form.get('submission_limit', '').strip()
            priority = request.form.get('priority', '').strip()
            
            # Конвертируем в числа с защитой от ошибок
            try:
                reward_money_val = float(reward_money) if reward_money else 0.0
            except (ValueError, TypeError):
                reward_money_val = 0.0
                
            try:
                reward_points_val = int(reward_points) if reward_points else 0
            except (ValueError, TypeError):
                reward_points_val = 0
                
            try:
                submission_limit_val = int(submission_limit) if submission_limit else 10
            except (ValueError, TypeError):
                submission_limit_val = 10
                
            try:
                priority_val = int(priority) if priority else 0
            except (ValueError, TypeError):
                priority_val = 0
            
            task = Task(
                title=request.form.get('title', f"Задание на {request.form['platform']}"),
                platform=request.form['platform'],
                description=request.form['description'],
                category=request.form.get('category', 'review'),
                status='active',
                price=reward_money_val,
                reward_money=reward_money_val,
                reward_points=reward_points_val,
                submission_limit=submission_limit_val,
                task_url=request.form.get('task_url', ''),
                instruction_link=request.form.get('instruction_link', ''),
                city=request.form.get('city', ''),
                direction=request.form.get('direction', ''),
                is_active='is_active' in request.form,
                priority=priority_val
            )
            
            db.session.add(task)
            db.session.commit()
            
            log_action('CREATE_TASK', 'task', task.id, f'Создано задание: {task.description[:50]}')
            flash('Задание успешно создано!', 'success')
            return redirect(url_for('tasks'))
            
        except Exception as e:
            db.session.rollback()
            log_action('ERROR', details=f'Ошибка при создании задания: {str(e)}')
            flash(f'Ошибка при создании задания: {str(e)}', 'danger')
    
    return render_template('task_form.html', platforms=PLATFORMS, task=None, title='Создать новое задание')

@app.route('/tasks/edit/<int:task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = Task.query.get_or_404(task_id)
    
    if request.method == 'POST':
        try:
            # Получаем данные из формы с защитой от None и пустых строк
            reward_money = request.form.get('reward_money', '').strip()
            if not reward_money:
                reward_money = request.form.get('price', str(task.price or 0)).strip()
            
            reward_points = request.form.get('reward_points', '').strip()  
            submission_limit = request.form.get('submission_limit', '').strip()
            priority = request.form.get('priority', '').strip()
            
            # Конвертируем в числа с защитой от ошибок
            try:
                reward_money_val = float(reward_money) if reward_money else (task.reward_money or 0.0)
            except (ValueError, TypeError):
                reward_money_val = task.reward_money or 0.0
                
            try:
                reward_points_val = int(reward_points) if reward_points else (task.reward_points or 0)
            except (ValueError, TypeError):
                reward_points_val = task.reward_points or 0
                
            try:
                submission_limit_val = int(submission_limit) if submission_limit else (task.submission_limit or 10)
            except (ValueError, TypeError):
                submission_limit_val = task.submission_limit or 10
                
            try:
                priority_val = int(priority) if priority else (task.priority or 0)
            except (ValueError, TypeError):
                priority_val = task.priority or 0
            
            # Обновляем поля задания
            task.title = request.form.get('title', task.title)
            task.platform = request.form['platform']
            task.description = request.form['description']
            task.category = request.form.get('category', task.category or 'review')
            task.price = reward_money_val
            task.reward_money = reward_money_val
            task.reward_points = reward_points_val
            task.submission_limit = submission_limit_val
            task.task_url = request.form.get('task_url', task.task_url or '')
            task.instruction_link = request.form.get('instruction_link', task.instruction_link or '')
            task.city = request.form.get('city', task.city or '')
            task.direction = request.form.get('direction', task.direction or '')
            task.is_active = 'is_active' in request.form
            task.priority = priority_val
            
            db.session.commit()
            
            log_action('UPDATE_TASK', 'task', task.id, f'Обновлено задание: {task.description[:50]}')
            flash('Задание успешно обновлено!', 'success')
            return redirect(url_for('tasks'))
            
        except Exception as e:
            db.session.rollback()
            log_action('ERROR', details=f'Ошибка при обновлении задания {task_id}: {str(e)}')
            flash(f'Ошибка при обновлении задания: {str(e)}', 'danger')
    
    return render_template('task_form.html', platforms=PLATFORMS, task=task, title='Редактировать задание')


@app.route('/tasks/deactivate/<int:task_id>', methods=['POST'])
@login_required
def deactivate_task(task_id):
    task = Task.query.get_or_404(task_id)
    try:
        task.is_active = False
        task.status = 'inactive'
        db.session.commit()
        log_action('DEACTIVATE_TASK', 'task', task_id, f'Деактивировано задание: {task.description[:50]}')
        flash('Задание деактивировано.', 'info')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при деактивации задания: {str(e)}', 'danger')
    return redirect(url_for('tasks'))

@app.route('/tasks/activate/<int:task_id>', methods=['POST'])
@login_required
def activate_task(task_id):
    task = Task.query.get_or_404(task_id)
    try:
        task.is_active = True
        task.status = 'active'
        db.session.commit()
        log_action('ACTIVATE_TASK', 'task', task_id, f'Активировано задание: {task.description[:50]}')
        flash('Задание активировано.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при активации задания: {str(e)}', 'danger')
    return redirect(url_for('tasks'))

@app.route('/tasks/delete/<int:task_id>', methods=['POST'])
@login_required
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    try:
        submissions_count = Submission.query.filter_by(task_id=task_id).count()
        force = request.form.get('force') == '1'
        if submissions_count > 0 and not force:
            # Вместо блокировки — мягкая деактивация
            task.is_active = False
            task.status = 'inactive'
            db.session.commit()
            flash(f'У задания есть {submissions_count} выполнений — оно деактивировано. Для полного удаления нажмите "Удалить" еще раз и подтвердите.', 'warning')
        else:
            if submissions_count > 0:
                # Жесткое удаление с очисткой связанных выполнений
                Submission.query.filter_by(task_id=task_id).delete(synchronize_session=False)
            description = (task.description or '')[:50]
            db.session.delete(task)
            db.session.commit()
            log_action('DELETE_TASK', 'task', task_id, f'Удалено задание: {description}')
            flash('Задание удалено.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при удалении задания: {str(e)}', 'danger')
    return redirect(url_for('tasks'))
              

@app.route('/submissions')
@login_required
def submissions():
    status = request.args.get('status', 'pending')
    platform = (request.args.get('platform') or 'all').strip()
    q = (request.args.get('q') or '').strip()
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 50))

    # Aliases for platform shortcuts
    aliases = {
        'yandex': 'Яндекс Карты', 'яндекс': 'Яндекс Карты', 'ymaps': 'Яндекс Карты',
        'google': 'Google Карты', 'гугл': 'Google Карты', 'gmap': 'Google Карты',
        '2gis': '2ГИС', 'дегис': '2ГИС',
        'avito': 'Авито', 'авито': 'Авито',
        'ozon': 'Ozon', 'озон': 'Ozon',
        'wb': 'Wildberries', 'wildberries': 'Wildberries', 'вб': 'Wildberries',
        'zoon': 'Zoon', 'зун': 'Zoon',
        'browser': 'Яндекс Браузер', 'yabrowser': 'Яндекс Браузер',
        'other': 'Другое', 'другое': 'Другое'
    }
    platform_value = None if platform == 'all' else aliases.get(platform.lower(), platform)

    # Base query with join to Task for platform filtering
    query = db.session.query(Submission).join(Task, Task.id == Submission.task_id)
    if status != 'all':
        query = query.filter(Submission.status == status)
    if platform_value:
        query = query.filter(Task.platform.ilike(platform_value))

    # Search across several fields
    from sqlalchemy import or_, cast, String
    search_filters = []
    if q:
        if q.isdigit():
            search_filters.extend([
                Submission.user_id == int(q),
                Submission.task_id == int(q)
            ])
        like_q = f"%{q}%"
        search_filters.extend([
            Submission.fio.ilike(like_q),
            Submission.notes.ilike(like_q),
            Task.title.ilike(like_q),
            Task.description.ilike(like_q),
            Task.platform.ilike(like_q)
        ])
        query = query.filter(or_(*search_filters))

    submissions = query.order_by(desc(Submission.submission_time))        .paginate(page=page, per_page=per_page, error_out=False)

    # Counts per platform for current filters (status and search), to show badges
    count_q = db.session.query(Task.platform, func.count(Submission.id))        .join(Submission)
    if status != 'all':
        count_q = count_q.filter(Submission.status == status)
    if q:
        count_q = count_q.filter(or_(*search_filters))
    platform_counts_pairs = count_q.group_by(Task.platform).all()
    platform_counts = {k: int(v) for k, v in platform_counts_pairs}

    # Ensure all known platforms present in dict
    try:
        all_platforms = PLATFORMS
    except Exception:
        all_platforms = sorted({k for k in platform_counts.keys()})
    for p in all_platforms:
        platform_counts.setdefault(p, 0)

    pending_count = db.session.query(func.count(Submission.id))        .filter(Submission.status == 'pending').scalar() or 0

    return render_template(
        'submissions.html',
        submissions=submissions,
        current_status=status,
        platform=platform,
        platform_counts=platform_counts,
        PLATFORMS=all_platforms,
        q=q,
        per_page=per_page,
        pending_submissions_count=pending_count
    )
@app.route('/submissions/process/<int:submission_id>/<action>', methods=['POST'])
@login_required
def process_submission(submission_id, action):
    submission = Submission.query.get_or_404(submission_id)
    
    if submission.status != 'pending':
        flash('Это задание уже было обработано', 'warning')
        return redirect(request.referrer or url_for('submissions'))
    
    try:
        if action == 'approve':
            submission.status = 'approved'
            submission.review_time = datetime.utcnow()
            submission.approved_at = datetime.utcnow()
            submission.reviewer_id = current_user.id
            
            # Начисляем награду пользователю
            if submission.user and submission.task:
                # Используем правильные поля из реальной структуры БД
                reward_money = submission.task.price or submission.task.reward_money or 0
                reward_points = submission.task.reward_points or 0
                
                submission.user.balance += int(reward_money)
                submission.user.points += reward_points
                submission.user.total_earnings += int(reward_money)
            
            log_action('APPROVE_SUBMISSION', 'submission', submission_id, 
                      f'Одобрено выполнение задания пользователем {submission.user.username if submission.user else "N/A"}')
            flash('Задание одобрено и награда начислена!', 'success')
            
        elif action == 'reject':
            reason = request.form.get('reason', 'Не указана')
            submission.status = 'rejected'
            submission.review_time = datetime.utcnow()
            submission.approved_at = datetime.utcnow()
            submission.reviewer_id = current_user.id
            submission.rejection_reason = reason
            
            log_action('REJECT_SUBMISSION', 'submission', submission_id, 
                      f'Отклонено выполнение задания: {reason}')
            flash('Задание отклонено!', 'info')
        
        db.session.commit()
        
        # === Notify bot about decision (best-effort, non-blocking) ===
        try:
            if submission and getattr(submission, 'user_id', None) and getattr(submission, 'id', None):
                if action == 'approve':
                    reward_money = 0.0
                    try:
                        if getattr(submission, 'task', None):
                            reward_money = float((getattr(submission.task, 'price', 0) or 0) or (getattr(submission.task, 'reward_money', 0) or 0))
                    except Exception:
                        reward_money = 0.0
                    notify_bot_about_approval(submission.user_id, submission.id, reward_money)
                elif action == 'reject':
                    reason = getattr(submission, 'rejection_reason', None) or 'Не указана'
                    notify_bot_about_rejection(submission.user_id, submission.id, reason)
        except Exception as _e:
            try:
                print(f'[notify] error: {_e}')
            except Exception:
                pass
        
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при обработке задания: {str(e)}', 'danger')
    
    return redirect(request.referrer or url_for('submissions'))



def notify_bot_withdraw(user_id, request_id, status, amount, reason=None):
    try:
        bot_url = os.environ.get('BOT_API_URL', 'https://bot-angel2804.amvera.io')
        payload = {
            'user_id': int(user_id),
            'request_id': int(request_id),
            'status': status,
            'amount': int(amount) if amount is not None else None,
            'reason': reason or ''
        }
        requests.post(f"{bot_url}/api/withdraw_update", json=payload, timeout=5)
    except Exception as e:
        print(f"Notify bot withdraw error: {e}")
@app.route('/payouts')
@login_required
def payouts():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        current_status = request.args.get('status', '')

        query = WithdrawRequest.query
        if current_status:
            if current_status == 'pending_approved':
                query = query.filter(WithdrawRequest.status.in_(['pending', 'approved']))
            else:
                query = query.filter_by(status=current_status)

        payouts = query.order_by(desc(WithdrawRequest.created_at)).paginate(page=page, per_page=per_page, error_out=False)

        for payout in getattr(payouts, 'items', []):
            try:
                payout.user = User.query.filter_by(user_id=payout.user_id).first()
            except Exception:
                payout.user = None

        pending_payouts_count = WithdrawRequest.query.filter_by(status='pending').count()
        return render_template('payouts.html', payouts=payouts, current_status=current_status, pending_payouts_count=pending_payouts_count)

    except Exception as e:
        flash(f'Ошибка загрузки выплат: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

@app.route('/payouts/approve/<int:request_id>', methods=['POST'])
@login_required
def approve_payout(request_id):
    payout_request = WithdrawRequest.query.get_or_404(request_id)
    
    if payout_request.status != 'pending':
        flash('Эта заявка уже была обработана', 'warning')
        return redirect(url_for('payouts'))
    
    try:
        payout_request.status = 'approved'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.notes = request.form.get('notes', '')
        
        db.session.commit()
        try:
            notify_bot_withdraw(payout_request.user_id, payout_request.id, 'approved', payout_request.amount)
        except Exception as _e:
            print(f'Notify bot withdraw failed: {_e}')
        
        log_action('APPROVE_PAYOUT', 'withdraw_request', request_id, 
                  f'Одобрена заявка на вывод {payout_request.amount}₽')
        flash('Заявка на вывод одобрена!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при одобрении заявки: {str(e)}', 'danger')
    
    return redirect(url_for('payouts'))

@app.route('/payouts/mark_paid/<int:request_id>', methods=['POST'])
@login_required
def mark_payout_paid(request_id):
    payout_request = WithdrawRequest.query.get_or_404(request_id)
    
    if payout_request.status not in ['approved', 'pending']:
        flash('Эта заявка не может быть отмечена как оплаченная', 'warning')
        return redirect(url_for('payouts'))
    
    try:
        payout_request.status = 'paid'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.transaction_id = request.form.get('transaction_id', '')
        payout_request.notes = request.form.get('notes', '')
        
        db.session.commit()
        try:
            notify_bot_withdraw(payout_request.user_id, payout_request.id, 'paid', payout_request.amount)
        except Exception as _e:
            print(f'Notify bot withdraw failed: {_e}')
        
        log_action('MARK_PAID_PAYOUT', 'withdraw_request', request_id, 
                  f'Отмечена как оплаченная заявка на {payout_request.amount}₽, ID транзакции: {payout_request.transaction_id}')
        flash('Заявка отмечена как оплаченная!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при отметке заявки: {str(e)}', 'danger')
    
    return redirect(url_for('payouts'))

@app.route('/payouts/reject/<int:request_id>', methods=['POST'])
@login_required
def reject_payout(request_id):
    payout_request = WithdrawRequest.query.get_or_404(request_id)

    if payout_request.status == 'paid':
        flash('Нельзя отклонить уже оплаченную заявку', 'warning')
        return redirect(url_for('payouts'))

    try:
        reason = request.form.get('reason', 'Не указана')

        # Возвращаем деньги на баланс для статусов pending/approved
        if payout_request.user and payout_request.status in ['pending', 'approved']:
            payout_request.user.balance += int(payout_request.amount or 0)
            try:
                db.session.execute(
                    """INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at)
                    VALUES (:uid, :amt, 'withdraw_reject', :rid, extract(epoch from now())::bigint)""",
                    { 'uid': int(payout_request.user_id), 'amt': int(payout_request.amount or 0), 'rid': int(payout_request.id) }
                )
            except Exception as _e:
                print(f'Balance log insert failed: {_e}')

        payout_request.status = 'rejected'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.notes = reason

        db.session.commit()

        try:
            notify_bot_withdraw(payout_request.user_id, payout_request.id, 'rejected', payout_request.amount, reason)
        except Exception as _e:
            print(f'Notify bot withdraw failed: {_e}')

        log_action('REJECT_PAYOUT', 'withdraw_request', request_id, f'Отклонена заявка на вывод {payout_request.amount}₽: {reason}')
        flash('Заявка на вывод отклонена!', 'info')

    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при отклонении заявки: {str(e)}', 'danger')

    return redirect(url_for('payouts'))

    
    try:
        reason = request.form.get('reason', 'Не указана')
        
        # Возвращаем деньги на баланс пользователя если заявка была одобрена
        if payout_request.status == 'approved' and payout_request.user:
            payout_request.user.balance += payout_request.amount
        
        payout_request.status = 'rejected'
        payout_request.processed_time = datetime.utcnow()
        payout_request.processor_id = current_user.id
        payout_request.notes = reason
        
        db.session.commit()
        
        log_action('REJECT_PAYOUT', 'withdraw_request', request_id, 
                  f'Отклонена заявка на вывод {payout_request.amount}₽: {reason}')
        flash('Заявка на вывод отклонена!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при отклонении заявки: {str(e)}', 'danger')
    
    return redirect(url_for('payouts'))

@app.route('/users')
@login_required
def users():
    search_query = request.args.get('q', '')
    page = request.args.get('page', 1, type=int)
    per_page = int(request.args.get('per_page', 20))
    
    query = User.query
    if search_query:
        query = query.filter(or_(
            User.username.ilike(f'%{search_query}%'),
            User.full_name.ilike(f'%{search_query}%'),
            User.user_id.like(f'%{search_query}%')
        ))
    
    users = query.order_by(desc(User.registration_date))\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Статистика пользователей
    user_stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter(User.last_activity >= datetime.utcnow() - timedelta(days=7)).count(),
        'banned_users': User.query.filter_by(is_banned=True).count(),
        'total_balance': db.session.query(func.sum(User.balance)).scalar() or 0
    }
    
    return render_template('users.html', 
                         users=users, 
                         search_query=search_query,
                         user_stats=user_stats)

@app.route('/users/ban/<int:user_id>', methods=['POST'])
@login_required
def ban_user(user_id):
    user = User.query.get_or_404(user_id)
    reason = request.form.get('reason', 'Не указана')
    
    try:
        user.is_banned = True
        user.ban_reason = reason
        db.session.commit()
        
        log_action('BAN_USER', 'user', user_id, f'Заблокирован пользователь {user.username}: {reason}')
        flash(f'Пользователь {user.username} заблокирован!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при блокировке пользователя: {str(e)}', 'danger')
    
    return redirect(url_for('users'))

@app.route('/users/unban/<int:user_id>', methods=['POST'])
@login_required
def unban_user(user_id):
    user = User.query.get_or_404(user_id)
    
    try:
        user.is_banned = False
        user.ban_reason = None
        db.session.commit()
        
        log_action('UNBAN_USER', 'user', user_id, f'Разблокирован пользователь {user.username}')
        flash(f'Пользователь {user.username} разблокирован!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при разблокировке пользователя: {str(e)}', 'danger')
    
    return redirect(url_for('users'))

@app.route('/analytics')
@login_required
def analytics():
    # Статистика за последние 30 дней
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    
    # Основная статистика
    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter(User.last_activity >= datetime.utcnow() - timedelta(days=7)).count(),
        'active_tasks': Task.query.filter_by(status='active').count(),
        'total_earnings': db.session.query(func.sum(User.total_earnings)).scalar() or 0,
        'pending_withdrawals': WithdrawRequest.query.filter_by(status='pending').count(),
        'total_submissions': Submission.query.count(),
        'pending_submissions': Submission.query.filter_by(status='pending').count(),
        'approved_submissions': Submission.query.filter_by(status='approved').count(),
        'rejected_submissions': Submission.query.filter_by(status='rejected').count(),
    }
    
    # Ежедневная статистика
    daily_stats = db.session.query(
        func.date(Submission.submission_time).label('date'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved'),
        func.count(case([(Submission.status == 'rejected', 1)])).label('rejected'),
        func.count(case([(Submission.status == 'pending', 1)])).label('pending')
    ).filter(Submission.submission_time >= thirty_days_ago)\
     .group_by(func.date(Submission.submission_time))\
     .order_by(func.date(Submission.submission_time)).all()
    
    # Статистика по платформам
    platform_stats = db.session.query(
        Task.platform,
        func.count(Submission.id).label('total_submissions'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved_submissions'),
        func.sum(case([(Submission.status == 'approved', Task.price)])).label('total_paid')
    ).join(Submission).group_by(Task.platform).all()
    
    # Топ пользователи
    top_users = db.session.query(
        User,
        func.count(Submission.id).label('submissions_count'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved_count')
    ).join(Submission).group_by(User.user_id)\
     .order_by(desc('approved_count')).limit(10).all()
    
    return render_template('analytics.html',
                         stats=stats,
                         daily_stats=daily_stats,
                         platform_stats=platform_stats,
                         top_users=top_users)

@app.route('/settings')
@login_required
def settings():
    settings = SystemSettings.query.all()
    settings_dict = {}
    for setting in settings:
        key = setting.key or setting.setting_key
        value = setting.value or setting.setting_value
        if key:
            settings_dict[key] = value
    return render_template('settings.html', 
                         settings=settings,
                         settings_dict=settings_dict)

@app.route('/settings/update', methods=['POST'])
@login_required
def update_settings():
    try:
        for key, value in request.form.items():
            if key != 'csrf_token':
                setting = SystemSettings.query.filter(
                    or_(SystemSettings.key == key, SystemSettings.setting_key == key)
                ).first()
                
                if setting:
                    if setting.key:
                        setting.value = value
                    if setting.setting_key:
                        setting.setting_value = value
                    setting.updated_at = datetime.utcnow()
                    setting.updated_by = current_user.id
                else:
                    setting = SystemSettings(
                        key=key,
                        value=value,
                        setting_key=key,
                        setting_value=value,
                        updated_by=current_user.id
                    )
                    db.session.add(setting)
        
        db.session.commit()
        log_action('UPDATE_SETTINGS', details='Обновлены настройки системы')
        flash('Настройки успешно обновлены!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при обновлении настроек: {str(e)}', 'danger')
    
    return redirect(url_for('settings'))

@app.route('/logs')
@login_required
def logs():
    page = request.args.get('page', 1, type=int)
    action_filter = request.args.get('action', '')
    per_page = int(request.args.get('per_page', 50))
    
    query = SystemLog.query
    if action_filter:
        query = query.filter(SystemLog.action.ilike(f'%{action_filter}%'))
    
    logs_pagination = query.order_by(desc(SystemLog.timestamp))\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Уникальные действия для фильтра
    actions = db.session.query(SystemLog.action).distinct().all()
    actions = [action[0] for action in actions]
    
    return render_template('logs.html', 
                         logs=logs_pagination,
                         logs_items=logs_pagination.items,
                         logs_total=logs_pagination.total,
                         actions=actions,
                         current_action=action_filter)

@app.route('/export/users')
@login_required
def export_users():
    users = User.query.all()
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Username', 'Full Name', 'Balance', 'Points', 'Total Earnings', 'Registration Date', 'Is Banned'])
    
    for user in users:
        writer.writerow([
            user.user_id,
            user.username,
            user.full_name,
            user.balance,
            user.points,
            user.total_earnings,
            user.registration_date.strftime('%Y-%m-%d %H:%M:%S') if user.registration_date else '',
            user.is_banned
        ])
    
    output.seek(0)
    log_action('EXPORT_USERS', details='Экспорт данных пользователей')
    
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'users_export_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    )

# --- API ENDPOINTS ---

@app.route('/api/stats/daily_submissions')
@login_required
def api_daily_submissions():
    """API для получения ежедневной статистики выполнений"""
    days = request.args.get('days', 7, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    stats = db.session.query(
        func.date(Submission.submission_time).label('date'),
        func.count(case([(Submission.status == 'approved', 1)])).label('approved'),
        func.count(case([(Submission.status == 'rejected', 1)])).label('rejected')
    ).filter(Submission.submission_time >= start_date)\
     .group_by(func.date(Submission.submission_time))\
     .order_by(func.date(Submission.submission_time)).all()
    
    labels = []
    approved_data = []
    rejected_data = []
    
    for stat in stats:
        labels.append(stat.date.strftime('%d.%m'))
        approved_data.append(stat.approved)
        rejected_data.append(stat.rejected)
    
    return jsonify({
        'labels': labels,
        'approved': approved_data,
        'rejected': rejected_data
    })

@app.route('/api/stats/platform_distribution')
@login_required
def api_platform_distribution():
    """API для получения распределения заданий по платформам"""
    stats = db.session.query(
        Task.platform,
        func.count(Task.id).label('count')
    ).group_by(Task.platform).all()
    
    return jsonify({
        'labels': [stat.platform for stat in stats],
        'data': [stat.count for stat in stats]
    })

@app.route('/api/stats/earnings_timeline')
@login_required
def api_earnings_timeline():
    """API для получения временной линии заработка"""
    days = request.args.get('days', 30, type=int)
    start_date = datetime.utcnow() - timedelta(days=days)
    
    stats = db.session.query(
        func.date(Submission.review_time).label('date'),
        func.sum(Task.price).label('total_earned')
    ).join(Task).filter(
        and_(
            Submission.status == 'approved',
            Submission.review_time >= start_date
        )
    ).group_by(func.date(Submission.review_time))\
     .order_by(func.date(Submission.review_time)).all()
    
    labels = []
    earnings_data = []
    
    for stat in stats:
        labels.append(stat.date.strftime('%d.%m'))
        earnings_data.append(float(stat.total_earned or 0))
    
    return jsonify({
        'labels': labels,
        'earnings': earnings_data
    })

@app.route('/create-first-admin-temp')
def create_first_admin_temp():
    """Временный роут для создания первого администратора"""
    try:
        # Проверяем, есть ли уже администраторы
        if Admin.query.count() > 0:
            return "Администратор уже существует!"
        
        # Создаем первого администратора
        admin = Admin(username='admin', role='super_admin')
        admin.set_password('admin123')  # Измените на безопасный пароль!
        
        db.session.add(admin)
        db.session.commit()
        
        return "Первый администратор создан! Username: admin, Password: admin123"
    except Exception as e:
        return f"Ошибка при создании администратора: {str(e)}"

# --- ОБРАБОТЧИКИ ОШИБОК ---

@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html', 
                         error_code=404, 
                         error_message="Страница не найдена"), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('error.html', 
                         error_code=500, 
                         error_message="Внутренняя ошибка сервера"), 500

# --- ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ ---

def init_default_settings():
    """Инициализация настроек по умолчанию"""
    default_settings = [
        ('min_withdrawal_amount', '200', 'Минимальная сумма для вывода средств'),
        ('max_withdrawal_amount', '50000', 'Максимальная сумма для вывода средств'),
        ('withdrawal_fee_percent', '0', 'Комиссия за вывод средств (%)'),
        ('auto_approve_threshold', '1000', 'Автоматическое одобрение для пользователей с суммарным заработком выше'),
        ('daily_withdrawal_limit', '3', 'Лимит заявок на вывод в день на пользователя'),
        ('system_maintenance', 'false', 'Режим технического обслуживания'),
        ('new_user_bonus', '10', 'Бонус для новых пользователей'),
    ]
    
    for key, value, description in default_settings:
        existing = SystemSettings.query.filter(
            or_(SystemSettings.key == key, SystemSettings.setting_key == key)
        ).first()
        
        if not existing:
            setting = SystemSettings(
                key=key, 
                value=value, 
                setting_key=key,
                setting_value=value,
                description=description
            )
            db.session.add(setting)
    
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Ошибка при инициализации настроек: {e}")

# --- ЗАПУСК ПРИЛОЖЕНИЯ ---

# Защита от повторного определения роутов
if not hasattr(dashboard, '_routes_defined'):
    dashboard._routes_defined = True


# === ИНТЕГРАЦИОННЫЕ ФУНКЦИИ ===

# --- patched notify functions with logging ---
def notify_bot_about_approval(user_id, submission_id, reward_money):
    """Уведомление бота об одобрении заявки"""
    try:
        import requests
        BOT_URL = os.getenv("BOT_URL", "https://bot-angel2804.amvera.io")
        requests.post(f"{BOT_URL}/api/submission_approved", json={
            'user_id': user_id,
            'submission_id': submission_id,
            'reward_money': reward_money
        }, timeout=5)
    except Exception as e:
        print(f'[notify error] {e}')

def notify_bot_about_rejection(user_id, submission_id, reason):
    """Уведомление бота об отклонении заявки"""
    try:
        import requests
        BOT_URL = os.getenv("BOT_URL", "https://bot-angel2804.amvera.io")
        requests.post(f"{BOT_URL}/api/submission_rejected", json={
            'user_id': user_id,
            'submission_id': submission_id,
            'reason': reason
        }, timeout=5)
    except Exception as e:
        print(f'[notify error] {e}')

# API endpoints для интеграции с веб-аппом
@app.route('/api/new_submission', methods=['POST'])
def api_new_submission():
    """API для получения уведомления о новой заявке от веб-аппа"""
    try:
        data = request.get_json()
        submission_id = data.get('submission_id')
        
        # Здесь можно добавить дополнительную логику для уведомлений админов
        # например, отправка email или push-уведомления
        
        return jsonify({'success': True, 'message': 'Уведомление получено'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    with app.app_context():
        try:
            db.create_all()
            init_default_settings()
            print("База данных инициализирована успешно!")
        except Exception as e:
            print(f"Ошибка при инициализации базы данных: {e}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)


from flask import send_from_directory
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
