import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'your-super-secret-key-change-in-production')
    
    # Единая база данных для всех приложений
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False  # Поставить True для отладки SQL запросов
    
    # Настройки для загрузки файлов
    UPLOAD_FOLDER = '/data/uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload
    
    # URLs других приложений
    BOT_API_URL = os.environ.get('BOT_API_URL', 'https://botseoserm-angel2804.amvera.io')
    WEBAPP_URL = os.environ.get('WEBAPP_URL', 'https://seowebapp-angel2804.amvera.io')
    
    # Настройки безопасности
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = None
    
    # Временная зона
    TIMEZONE = 'Europe/Moscow'

    # CryptoBot API
    CRYPTOBOT_API_TOKEN = os.environ.get('CRYPTOBOT_API_TOKEN', '473566:AAcaALcBj6VyNvUKW7sKPTRWHKLEncsKNsL')
