"""
Утилиты для работы с заданиями Avito - ИСПРАВЛЕНО
"""
from datetime import datetime, timedelta
from flask import session
import os
from werkzeug.utils import secure_filename

def is_avito_task(task):
    """Проверяет, является ли задание заданием Avito"""
    if not task or not task.platform:
        return False
    platform_lower = task.platform.lower()
    return 'avito' in platform_lower or 'авито' in platform_lower


def init_avito_submission(db, AvitoSubmission, user_id, task_id):
    """
    Инициализирует submission для Avito задания
    Создает запись с таймером на 2 часа для загрузки скрина переписки
    """
    # Проверяем, есть ли уже запись
    existing = AvitoSubmission.query.filter_by(
        user_id=user_id,
        task_id=task_id,
        is_expired=False
    ).first()
    
    if existing:
        return existing
    
    # Создаем новую запись
    avito_sub = AvitoSubmission(
        user_id=user_id,
        task_id=task_id,
        started_at=datetime.utcnow()
    )
    
    db.session.add(avito_sub)
    db.session.commit()
    
    return avito_sub


def get_avito_submission_status(db, AvitoSubmission, user_id, task_id):
    """
    Получает статус Avito задания для пользователя
    Возвращает словарь с информацией о статусе
    """
    avito_sub = AvitoSubmission.query.filter_by(
        user_id=user_id,
        task_id=task_id
    ).first()
    
    if not avito_sub:
        return {
            'exists': False,
            'status': 'not_started'
        }
    
    now = datetime.utcnow()
    
    # Проверяем истек ли 2-часовой таймер
    chat_upload_deadline = avito_sub.started_at + timedelta(hours=2)
    chat_upload_expired = now > chat_upload_deadline
    
    if chat_upload_expired and not avito_sub.chat_screenshot_path:
        # Таймер истек, скрин не загружен
        if not avito_sub.is_expired:
            avito_sub.is_expired = True
            db.session.commit()
        
        return {
            'exists': True,
            'status': 'expired',
            'message': 'Время на загрузку скриншота переписки истекло. Задание снято.'
        }
    
    # Проверяем статус загрузки скрина переписки
    if not avito_sub.chat_screenshot_path:
        time_left = chat_upload_deadline - now
        minutes_left = int(time_left.total_seconds() / 60)
        
        return {
            'exists': True,
            'status': 'waiting_chat_screenshot',
            'minutes_left': minutes_left,
            'deadline': chat_upload_deadline.isoformat(),
            'message': f'Загрузите скриншот переписки. Осталось {minutes_left} минут.'
        }
    
    # Скрин переписки загружен, проверяем можно ли отправить отчет
    if not avito_sub.report_available_at:
        # Устанавливаем время когда можно отправить отчет (через 24 часа)
        avito_sub.report_available_at = avito_sub.chat_screenshot_uploaded_at + timedelta(hours=24)
        db.session.commit()
    
    if now < avito_sub.report_available_at:
        time_left = avito_sub.report_available_at - now
        hours_left = int(time_left.total_seconds() / 3600)
        minutes_left = int((time_left.total_seconds() % 3600) / 60)
        
        return {
            'exists': True,
            'status': 'waiting_report',
            'hours_left': hours_left,
            'minutes_left': minutes_left,
            'report_available_at': avito_sub.report_available_at.isoformat(),
            'chat_screenshot_uploaded': True,
            'message': f'Скриншот переписки загружен. Отчет можно отправить через {hours_left}ч {minutes_left}м.'
        }
    
    # Можно отправить отчет
    return {
        'exists': True,
        'status': 'ready_for_report',
        'chat_screenshot_uploaded': True,
        'message': 'Можете отправить финальный отчет с скриншотом отзыва.'
    }


def save_chat_screenshot(file, user_id, task_id):
    """
    ИСПРАВЛЕНО: Сохраняет скриншот переписки в static/uploads/
    Возвращает путь к файлу относительно static/
    """
    if not file:
        return None
    
    # ИСПРАВЛЕНИЕ: создаем папку uploads в static
    upload_folder = 'static/uploads'
    os.makedirs(upload_folder, exist_ok=True)
    
    # Генерируем имя файла
    filename = secure_filename(file.filename)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    new_filename = f'avito_chat_{user_id}_{task_id}_{timestamp}_{filename}'
    
    filepath = os.path.join(upload_folder, new_filename)
    file.save(filepath)
    
    # ВАЖНО: возвращаем путь БЕЗ static/ для корректного отображения
    return f'/uploads/{new_filename}'


def cleanup_expired_avito_tasks(db, AvitoSubmission, Submission, Assignment):
    """
    Очищает просроченные Avito задания
    Снимает задания у пользователей, которые не загрузили скрин переписки за 2 часа
    """
    now = datetime.utcnow()
    two_hours_ago = now - timedelta(hours=2)
    
    # Находим просроченные submission'ы
    expired_subs = AvitoSubmission.query.filter(
        AvitoSubmission.started_at <= two_hours_ago,
        AvitoSubmission.chat_screenshot_path.is_(None),
        AvitoSubmission.is_expired == False
    ).all()
    
    count = 0
    for avito_sub in expired_subs:
        # Помечаем как просроченный
        avito_sub.is_expired = True
        
        # Снимаем задание с пользователя
        assignment = Assignment.query.filter_by(
            user_id=avito_sub.user_id,
            task_id=avito_sub.task_id
        ).first()
        
        if assignment:
            db.session.delete(assignment)
        
        count += 1
    
    if count > 0:
        db.session.commit()
    
    return count


def check_avito_report_available(user_id, task_id):
    """
    Проверяет, можно ли отправить отчет для Avito задания
    Возвращает (доступен, сообщение, оставшееся_время)
    """
    from models import AvitoSubmission
    from extensions import db
    
    avito_sub = AvitoSubmission.query.filter_by(
        user_id=user_id,
        task_id=task_id
    ).first()
    
    if not avito_sub:
        return (False, 'Задание Авито не найдено', 0)
    
    # Проверяем истек ли таймер на загрузку скрина переписки
    if avito_sub.is_expired:
        return (False, 'Время на загрузку скриншота переписки истекло. Задание снято.', 0)
    
    now = datetime.utcnow()
    chat_deadline = avito_sub.started_at + timedelta(hours=2)
    
    # Если скрин переписки не загружен
    if not avito_sub.chat_screenshot_path:
        if now > chat_deadline:
            avito_sub.is_expired = True
            db.session.commit()
            return (False, 'Время на загрузку скриншота переписки истекло. Задание снято.', 0)
        else:
            time_left = int((chat_deadline - now).total_seconds() / 60)
            return (False, f'Сначала загрузите скриншот переписки. Осталось {time_left} минут.', time_left)
    
    # Скрин переписки загружен, проверяем можно ли отправить отчет
    if not avito_sub.report_available_at:
        # Устанавливаем время доступности отчета
        avito_sub.report_available_at = avito_sub.chat_screenshot_uploaded_at + timedelta(hours=24)
        db.session.commit()
    
    if now < avito_sub.report_available_at:
        time_left_seconds = (avito_sub.report_available_at - now).total_seconds()
        hours_left = int(time_left_seconds / 3600)
        minutes_left = int((time_left_seconds % 3600) / 60)
        return (False, f'Отчет можно отправить через {hours_left}ч {minutes_left}м. Дождитесь истечения 24 часов.', time_left_seconds)
    
    # Можно отправить отчет
    return (True, 'Можете отправить отчет', 0)
