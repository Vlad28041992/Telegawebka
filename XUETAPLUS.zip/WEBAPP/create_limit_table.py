#!/usr/bin/env python3
"""
Скрипт для создания таблицы user_task_limits
Запускается автоматически при первом запуске приложения
"""

from extensions import db
from models import UserTaskLimit

def create_limit_table():
    """Создать таблицу лимитов, если её нет"""
    try:
        # Проверяем, существует ли таблица
        db.engine.execute("SELECT 1 FROM user_task_limits LIMIT 1")
        print("✅ Таблица user_task_limits уже существует")
    except:
        # Создаем таблицу
        db.create_all()
        print("✅ Создана таблица user_task_limits")

if __name__ == "__main__":
    from app import app
    with app.app_context():
        create_limit_table()
