"""
Миграция БД для Авито логики
Создает необходимые таблицы если их еще нет
"""

from app import app, db

def run_migration():
    """Создает новые таблицы"""
    with app.app_context():
        try:
            # Создаем все таблицы (существующие не будут пересозданы)
            db.create_all()
            print("✅ Миграция выполнена!")
            print("✅ Проверьте таблицы:")
            print("   - user_task_limits")
            print("   - assignments")
            print("   - avito_submissions")
            
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    run_migration()
