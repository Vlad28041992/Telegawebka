
import os

class Config:
    """Конфигурация веб-приложения"""
    
    # Секретный ключ для сессий
    SECRET_KEY = os.environ.get('SECRET_KEY', 'your-super-secret-key-change-in-production')
    
    # Настройки базы данных (используем ту же БД что и бот)
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL', 
        'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False  # Поставить True для отладки SQL запросов
    
    # Настройки для загрузки файлов
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    
    # ИСПРАВЛЕНО: Пробуем использовать /data/uploads, если нет прав - используем static/uploads
    UPLOAD_FOLDER = '/data/uploads'
    
    # Проверяем доступ на запись, если нет - используем резервный путь
    if not os.path.exists(UPLOAD_FOLDER):
        try:
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            os.chmod(UPLOAD_FOLDER, 0o755)
        except (OSError, PermissionError):
            # Если не удалось создать /data/uploads - используем static/uploads
            UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # URLs других приложений
    BOT_API_URL = os.environ.get('BOT_API_URL', 'https://testbot-angel2804.amvera.io/')
    ADMIN_PANEL_URL = os.environ.get('ADMIN_PANEL_URL', 'https://adminpanelseoserm-angel2804.amvera.io')
    
    # Настройки Flask-Admin
    FLASK_ADMIN_SWATCH = 'cerulean'
    
    # Настройки для разработки
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    # Настройки безопасности
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = None
    
    # ИСПРАВЛЕНИЕ: Настройки сессий для безопасности
    # Это критично для предотвращения путаницы пользователей!
    SESSION_COOKIE_SECURE = True  # True только если HTTPS
    SESSION_COOKIE_HTTPONLY = True  # Защита от XSS
    SESSION_COOKIE_SAMESITE = 'None'  # Защита от CSRF
    PERMANENT_SESSION_LIFETIME = 86400  # 24 часа
    SESSION_REFRESH_EACH_REQUEST = False  # НЕ обновлять сессию при каждом запросе
    
    # Временная зона
    TIMEZONE = 'Europe/Moscow'
