import os
import uuid
import requests
import random
import functools
from flask import send_from_directory, Flask, render_template, request, redirect, url_for, flash, jsonify, session, g
from flask_migrate import Migrate, upgrade
from datetime import datetime
from config import Config
from werkzeug.utils import secure_filename
from sqlalchemy.exc import IntegrityError

# Application secret for signing tokens / security
APP_SECRET = os.getenv('APP_SECRET') or os.getenv('BOT_TOKEN') or 'dev-secret'


from flask_admin import Admin
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db
from models import User, Task, Subtask, Submission, Achievement, UserAchievement, AdminUser, Platform, Payouts, UserTaskLimit, UserBan, YandexMapsRejection, AvitoSubmission, Assignment
from admin_views import init_admin_views




# Константы лимитов для платформ
# Формат: {'platform': (limit, hours)} 
# limit - количество заданий, hours - период в часах (None = дневной лимит)
PLATFORM_LIMITS = {
    # Яндекс Карты: 1 задание в 72 часа
    'Яндекс Карты': (1, 72),
    'Яндекс.Карты': (1, 72),
    'yandex-maps': (1, 72),
    
    # Google Карты: 2 задания в день
    'Google Карты': (2, None),
    'Гугл Карты': (2, None),
    'Google карты': (2, None),
    'google-maps': (2, None),
    
    # Яндекс Браузер: 2 задания в день
    'Яндекс Браузер': (2, None),
    'Яндекс.Браузер': (2, None),
    'Яндекс браузер': (2, None),
    'yandex-webmaster': (2, None),
    
    # Авито: 1 задание в день
    'Авито': (1, None),
    'авито': (1, None),
    'avito': (1, None),
    
    # Новые площадки - пока без лимитов (можно настроить позже)
    'cian': (999, None),
    'Циан': (999, None),
    'vk': (999, None),
    'ВКонтакте': (999, None),
    'irecommend': (999, None),
    'iRecommend': (999, None),
    'otzovik': (999, None),
    'Отзовик': (999, None),
    'zoon': (999, None),
    'Zoon': (999, None),
    'yandex-uslugi': (999, None),
    'Яндекс Услуги': (999, None),
    'prodoctorov': (999, None),
    'ПроДокторов': (999, None),
    
    # Остальные платформы без лимитов
}

# Маппинг URL-ключей платформ на их полные названия
PLATFORM_MAPPING = {
    'yandex-maps': 'Яндекс Карты',
    'google-maps': 'Google Карты', 
    'avito': 'Авито',
    'yandex-webmaster': 'Яндекс Браузер',
    'ozon': 'Ozon',
    'wildberries': 'Wildberries',
    'zoon': 'Zoon',
    'cian': 'Циан',
    'vk': 'ВКонтакте',
    'irecommend': 'iRecommend',
    'otzovik': 'Отзовик',
    'yandex-uslugi': 'Яндекс Услуги',
    'prodoctorov': 'ПроДокторов',
    'other': 'Другое'
}

# Алиасы платформ (для поддержки разных вариантов написания)
PLATFORMS_ALIASES = {
    'yandex-maps': ['Яндекс Карты', 'Яндекс.Карты', 'yandex-maps'],
    'google-maps': ['Google Карты', 'Google карты', 'Гугл Карты', 'google-maps'],
    'avito': ['Авито', 'авито', 'avito'],
    'yandex-webmaster': ['Яндекс Браузер', 'Яндекс.Браузер', 'Яндекс браузер', 'yandex-webmaster'],
    'ozon': ['Ozon', 'ozon'],
    'wildberries': ['Wildberries', 'wildberries'],
    'cian': ['Циан', 'циан', 'cian'],
    'vk': ['ВКонтакте', 'ВК', 'вконтакте', 'vk'],
    'irecommend': ['iRecommend', 'айрекомменд', 'irecommend'],
    'otzovik': ['Отзовик', 'отзовик', 'otzovik'],
    'zoon': ['ZOON', 'Zoon', 'зун', 'zoon'],
    'yandex-uslugi': ['Яндекс Услуги', 'Яндекс.Услуги', 'yandex-uslugi'],
    'prodoctorov': ['ПроДокторов', 'продокторов', 'prodoctorov'],
    'other': ['Другое', 'other']
}



# === Helpers ===

def normalize_platform_key(platform_key: str) -> str:
    """Нормализует platform_key к одному из ключей PLATFORM_MAPPING."""
    if not platform_key:
        return 'yandex-maps'
    key = str(platform_key).strip().lower()
    key = key.replace('_', '-').replace(' ', '-')
    # Прямое совпадение
    if key in PLATFORM_MAPPING:
        return key
    # Простые алиасы
    alias_map = {
        'yandex': 'yandex-maps',
        'яндекс': 'yandex-maps',
        'яндекс-карты': 'yandex-maps',
        'google': 'google-maps',
        'гугл': 'google-maps',
        'гугл-карты': 'google-maps',
        'авито': 'avito',
        'yandex-browser': 'yandex-webmaster',
        'яндекс-браузер': 'yandex-webmaster',
        'wildberries': 'wildberries',
        'wb': 'wildberries',
        'зоон': 'zoon',
        'циан': 'cian',
        'вк': 'vk',
        'вконтакте': 'vk',
        'айрекомменд': 'irecommend',
        'отзовик': 'otzovik',
        'яндекс-услуги': 'yandex-uslugi',
        'продокторов': 'prodoctorov',
    }
    if key in alias_map:
        return alias_map[key]
    # Если пришло русское название из mapping values — маппим обратно
    rev = {v.lower(): k for k, v in PLATFORM_MAPPING.items()}
    return rev.get(key, 'yandex-maps')


def has_user_submitted(user_id: int | None, task_id: int) -> bool:
    """Возвращает True если пользователь уже отправлял сабмит по этому заданию."""
    try:
        if not user_id:
            return False
        from models import Submission
        return Submission.query.filter_by(user_id=int(user_id), task_id=int(task_id)).first() is not None
    except Exception:
        return False


def get_platform_limit_info(platform_name):
    """Получить информацию о лимите для платформы"""
    return PLATFORM_LIMITS.get(platform_name, (999, None))  # 999 = без лимита

def check_user_task_limit(user_id, platform_name):
    """Проверить, может ли пользователь взять задание"""
    limit, hours = get_platform_limit_info(platform_name)
    
    if limit == 999:  # Без лимита
        return True, 0, limit
    
    # Если лимит с периодом в часах (например, 72 часа для Яндекс Карт)
    if hours is not None:
        from datetime import datetime, timedelta
        last_task_time = UserTaskLimit.get_last_task_time(user_id, platform_name)
        
        if last_task_time:
            time_passed = datetime.utcnow() - last_task_time
            hours_passed = time_passed.total_seconds() / 3600
            
            if hours_passed < hours:
                # Еще не прошло нужное время
                return False, 1, 1  # Показываем что выполнено 1 из 1
            else:
                # Прошло достаточно времени - можно взять
                return True, 0, 1
        else:
            # Никогда не выполнял - можно взять
            return True, 0, 1
    
    # Обычный дневной лимит
    tasks_today = UserTaskLimit.get_user_tasks_today(user_id, platform_name)
    can_take = tasks_today < limit
    return can_take, tasks_today, limit

def get_platform_daily_limit(platform_name):
    """Получить дневной лимит для платформы (для обратной совместимости)"""
    limit, hours = get_platform_limit_info(platform_name)
    return limit if hours is None else 1  # Для почасовых лимитов возвращаем 1




from datetime import timedelta
from sqlalchemy import text as _sqltext, or_


# === ФУНКЦИИ ДЛЯ РАБОТЫ С АВИТО (из avito_utils.py) ===
from extensions import db
from models import Task, Submission, User

# Константы для Авито
AVITO_CHAT_SCREENSHOT_TIMEOUT = 2  # 2 часа на загрузку скрина переписки
AVITO_REPORT_DELAY = 24  # 24 часа до возможности отправить отчет

def is_avito_task(task):
    """Проверяет, является ли задание Авито"""
    if not task:
        return False
    platform = task.platform.lower() if task.platform else ''
    return 'avito' in platform or 'авито' in platform

def init_avito_submission(user_id, task_id):
    """
    Инициализирует AvitoSubmission для Авито при взятии задания
    Устанавливает таймеры: 2 часа на скрин переписки, 24 часа на отчет
    
    Returns:
        avito_sub: объект AvitoSubmission или None
        error: текст ошибки или None
    """
    try:
        from models import AvitoSubmission
        
        task = Task.query.get(task_id)
        if not task:
            return None, "Задание не найдено"
        
        if not is_avito_task(task):
            return None, "Это не задание Авито"
        
        # Проверяем, нет ли уже AvitoSubmission
        existing = AvitoSubmission.query.filter_by(
            user_id=user_id,
            task_id=task_id,
            is_expired=False
        ).first()
        
        if existing:
            print(f'[AVITO] Submission уже существует для user {user_id}, task {task_id}')
            return existing, None
        
        # Создаем новый AvitoSubmission (ТОЛЬКО запись о таймерах, без Submission)
        now = datetime.utcnow()
        
        avito_sub = AvitoSubmission(
            user_id=user_id,
            task_id=task_id,
            started_at=now
        )
        
        db.session.add(avito_sub)
        db.session.commit()
        
        print(f'[AVITO] ✅ Создан AvitoSubmission для user {user_id}, task {task_id}')
        return avito_sub, None
        
    except Exception as e:
        db.session.rollback()
        print(f'[AVITO] ❌ Ошибка создания AvitoSubmission: {e}')
        return None, f"Ошибка создания: {e}"


def check_avito_report_available(user_id, task_id):
    """
    Проверяет, можно ли уже отправить отчет по Авито
    
    Args:
        user_id: ID пользователя
        task_id: ID задания
    
    Returns:
        available: bool
        message: текст сообщения
        time_left: оставшееся время в секундах (если не доступно)
    """
    try:
        from models import AvitoSubmission
        
        task = Task.query.get(task_id)
        if not task or not is_avito_task(task):
            return True, "Не Авито - можно отправлять", 0
        
        avito_sub = AvitoSubmission.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()
        
        if not avito_sub:
            return False, "⚠️ Задание не инициализировано", 0
        
        if avito_sub.is_expired:
            return False, "❌ Время на загрузку скрина переписки истекло", 0
        
        # Проверяем загружен ли скрин переписки
        if not avito_sub.chat_screenshot_path:
            return False, "⏳ Сначала загрузите скрин переписки!", 0
        
        # Проверяем таймер 24 часа
        if avito_sub.report_available_at:
            now = datetime.utcnow()
            if now >= avito_sub.report_available_at:
                return True, "✅ Отчет можно отправить!", 0
            else:
                time_left = (avito_sub.report_available_at - now).total_seconds()
                hours_left = int(time_left // 3600)
                minutes_left = int((time_left % 3600) // 60)
                return False, f"⏰ Отчет можно отправить через {hours_left}ч {minutes_left}мин", time_left
        
        return False, "⚠️ Время отправки отчета не установлено", 0
        
    except Exception as e:
        print(f'[AVITO] Ошибка check_avito_report_available: {e}')
        return False, f"Ошибка проверки: {e}", 0

def cleanup_expired_avito_tasks():
    """
    Очищает просроченные Avito задания
    (те, где не загрузили скрин переписки за 2 часа)
    
    Returns:
        count: количество очищенных заданий
    """
    try:
        from models import AvitoSubmission, Assignment
        
        now = datetime.utcnow()
        cutoff_time = now - timedelta(hours=2)  # 2 часа
        
        # Находим просроченные AvitoSubmission
        expired = AvitoSubmission.query.filter(
            AvitoSubmission.started_at < cutoff_time,
            AvitoSubmission.chat_screenshot_path.is_(None),
            AvitoSubmission.is_expired == False
        ).all()
        
        count = len(expired)
        
        for avito_sub in expired:
            # Помечаем как истекший
            avito_sub.is_expired = True
            
            # Снимаем задание с пользователя (удаляем Assignment)
            assignment = Assignment.query.filter_by(
                user_id=avito_sub.user_id,
                task_id=avito_sub.task_id
            ).first()
            
            if assignment:
                db.session.delete(assignment)
                print(f'[AVITO CLEANUP] Снято задание {avito_sub.task_id} с пользователя {avito_sub.user_id}')
        
        if count > 0:
            db.session.commit()
            print(f'[AVITO CLEANUP] ✅ Очищено {count} просроченных заданий')
        
        return count
        
    except Exception as e:
        db.session.rollback()
        print(f"[AVITO CLEANUP] ❌ Ошибка очистки: {e}")
        return 0

def get_avito_submission_status(user_id, task_id):
    """
    Получает статус submission для Авито
    
    Returns:
        dict с информацией о статусе или None
    """
    try:
        submission = Submission.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()
        
        if not submission:
            return None
        
        task = Task.query.get(task_id)
        if not is_avito_task(task):
            return None
        
        now = datetime.utcnow()
        
        result = {
            'submission_id': submission.id,
            'status': submission.avito_status,
            'task_taken_at': submission.task_taken_at,
            'chat_screenshot_verified': submission.chat_screenshot_verified,
            'report_available_at': submission.report_available_at,
        }
        
        # Вычисляем оставшееся время для скрина переписки
        if submission.avito_status == 'waiting_chat_screenshot' and submission.task_taken_at:
            screenshot_deadline = submission.task_taken_at + timedelta(hours=AVITO_CHAT_SCREENSHOT_TIMEOUT)
            if now < screenshot_deadline:
                result['chat_screenshot_time_left'] = (screenshot_deadline - now).total_seconds()
            else:
                result['chat_screenshot_expired'] = True
        
        # Вычисляем оставшееся время до отправки отчета
        if submission.report_available_at and now < submission.report_available_at:
            result['report_time_left'] = (submission.report_available_at - now).total_seconds()
        
        return result
        
    except Exception as e:
        print(f"Ошибка получения статуса Авито: {e}")
        return None


ASSIGN_TTL_MIN = 120

def release_stale_assigned_texts():
    """
    ИЗМЕНЕНО: Функция больше НЕ возвращает просроченные тексты в статус 'free'
    Тексты остаются в статусе 'assigned' навсегда - это считается использованным текстом
    
    Логика:
    - Если пользователь взял текст, он считается использованным
    - Даже если отчет не отправлен, текст не возвращается обратно
    - Это предотвращает повторную выдачу текстов
    """
    try:
        # Функция оставлена для совместимости, но ничего не делает
        # Тексты со статусом 'assigned' остаются в этом статусе навсегда
        print('[WEBAPP] ℹ️ release_stale_assigned_texts: функция отключена, тексты не возвращаются')
        return 0
    except Exception as e:
        print(f'[WEBAPP] ❌ release_stale_assigned_texts error: {e}')
        return 0





def init_task_review_texts_table():
    """Инициализация таблицы task_review_texts"""
    try:
        from sqlalchemy import text as _sqltext, or_
        db.session.execute(_sqltext("""
        CREATE TABLE IF NOT EXISTS task_review_texts (
            id SERIAL PRIMARY KEY,
            task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
            text TEXT NOT NULL,
            status VARCHAR(20) DEFAULT 'free',
            gender VARCHAR(20) DEFAULT 'neutral',
            assigned_user_id BIGINT,
            assigned_at TIMESTAMP,
            used_submission_id INTEGER,
            created_at TIMESTAMP DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_trt_task_status ON task_review_texts(task_id, status);
        CREATE INDEX IF NOT EXISTS idx_trt_assigned_user ON task_review_texts(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_trt_gender ON task_review_texts(gender);
"""))
        db.session.commit()
        print("✅ Таблица task_review_texts инициализирована")
    except Exception as _e:
        print(f'❌ Ошибка инициализации task_review_texts: {_e}')
        try:
            db.session.rollback()
        except:
            pass


# --- Pinned task helpers (2h sticky assignment) ---
PIN_TTL_MIN = 120


# ===== BAN SYSTEM =====
def check_user_ban(f):
    """
    Decorator to check if user is banned before accessing a view.
    Redirects to appropriate ban page if user is banned.
    Автобан (SYSTEM_AUTOBAN) применяется ТОЛЬКО к Яндекс Картам!
    """
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            user_id = session.get('user_id')
            if user_id:
                # Проверяем бан (защищено от падения при проблемах с БД)
                try:
                    is_banned, ban_info = UserBan.is_user_banned(int(user_id))
                except Exception as _ban_err:
                    print('[WEBAPP] ban check failed:', _ban_err)
                    is_banned, ban_info = False, None
                
                if is_banned and ban_info:
                    # Проверяем тип бана
                    if ban_info.banned_by == 'SYSTEM_AUTOBAN':
                        # Автобан - применяется ТОЛЬКО к Яндекс Картам
                        # Определяем текущую платформу
                        platform_key = request.view_args.get('platform_key') if request.view_args else None
                        platform_name = None
                        try:
                            if platform_key:
                                platform_name = PLATFORM_MAPPING.get(platform_key)
                        except Exception:
                            platform_name = None
                        # Если нет platform_key, проверяем task_id
                        if not platform_name:
                            task_id = request.view_args.get('task_id') if request.view_args else None
                            if task_id:
                                try:
                                    task = Task.query.get(task_id)
                                    if task:
                                        platform_name = task.platform
                                except Exception:
                                    pass
                        # Если это Яндекс Карты - блокируем
                        if platform_name == 'Яндекс Карты':
                            ban_data = ban_info.get_ban_info()
                            return render_template('banned_autoban_yandex.html', **ban_data)
                        # Для других платформ автобан НЕ действует - пропускаем
                    else:
                        # Обычный бан - блокируем всё
                        ban_data = ban_info.get_ban_info()
                        return render_template('banned.html', **ban_data)
        except Exception as _decor_err:
            print('[WEBAPP] check_user_ban decorator error:', _decor_err)
        
        return f(*args, **kwargs)
    
    return decorated_function

def _now_epoch():
    try:
        from datetime import datetime
        return int(datetime.utcnow().timestamp())
    except Exception:
        import time
        return int(time.time())


def _load_user_by_bi(user_id: int):
    try:
        # In our model, business id field is `user_id`
        return User.query.filter_by(user_id=user_id).first()
    except Exception:
        return None


def get_valid_pinned_task(user_id: int):
    """Return Task if user's pinned assignment is valid, otherwise clear it and return None."""
    if not user_id:
        return None
    u = _load_user_by_bi(user_id)
    if not u or not getattr(u, 'assigned_task_id', None):
        return None
    task_id = u.assigned_task_id
    # TTL check
    try:
        ts = int(u.assigned_task_time or 0)
    except Exception:
        ts = 0
    age_min = max(0, (_now_epoch() - ts) // 60) if ts else 999999
    if age_min > PIN_TTL_MIN:
        try:
            u.assigned_task_id = None
            u.assigned_task_time = None
            db.session.commit()
        except Exception:
            db.session.rollback()
        return None
    # Task existence and activity check
    t = Task.query.get(task_id)
    if not t or getattr(t, 'status', 'active') != 'active':
        try:
            u.assigned_task_id = None
            u.assigned_task_time = None
            db.session.commit()
        except Exception:
            db.session.rollback()
        return None
    # If user already has submission for this task, clear
    try:
        if has_user_submitted(user_id, task_id):
            u.assigned_task_id = None
            u.assigned_task_time = None
            db.session.commit()
            return None
    except Exception:
        pass
    return t


def assign_task_if_none(user_id: int, task_id: int):
    """ИСПРАВЛЕНО: Закрепляет задание за пользователем ВСЕГДА (перезаписывает старое если есть)"""
    if not user_id or not task_id:
        return False
    u = _load_user_by_bi(user_id)
    if not u:
        # Create user lazily if needed is risky here; just skip
        return False
    
    # КЛЮЧЕВОЕ ИЗМЕНЕНИЕ: Убрали проверку на уже закрепленное задание
    # Теперь задание ВСЕГДА закрепляется при переходе в него
    try:
        old_task_id = u.assigned_task_id
        u.assigned_task_id = int(task_id)
        u.assigned_task_time = _now_epoch()
        db.session.commit()
        if old_task_id and old_task_id != task_id:
            print(f'[WEBAPP] ✅ Задание {task_id} закреплено за user {user_id} (было закреплено {old_task_id})')
        else:
            print(f'[WEBAPP] ✅ Задание {task_id} закреплено за user {user_id}')
        return True
    except Exception as e:
        try:
            db.session.rollback()
        except Exception:
            pass
        print(f'assign_task_if_none error: {e}')
        return False


def clear_pinned_task(user_id: int, only_if_task_id: int | None = None):
    if not user_id:
        return False
    u = _load_user_by_bi(user_id)
    if not u:
        return False
    try:
        if only_if_task_id is not None and int(getattr(u, 'assigned_task_id', 0) or 0) != int(only_if_task_id):
            return False
    except Exception:
        pass
    try:
        u.assigned_task_id = None
        u.assigned_task_time = None
        db.session.commit()
        return True
    except Exception as e:
        try:
            db.session.rollback()
        except Exception:
            pass
        print(f'clear_pinned_task error: {e}')
        return False
# --- end helpers ---
def get_or_assign_review_text(task_id: int, user_id: int, user_gender: str = None):
    """
    Атомарное резервирование текста отзыва с предотвращением повторов по содержанию и гонок:
    - Возвращаем уже назначенный этому пользователю текст (assigned/used), если он есть.
    - Иначе выбираем одну строку из free с блокировкой SKIP LOCKED.
    - Гарантия уникальности по содержанию: в выборку попадает только минимальный id в группе одинаковых
      lower(trim(text)) (это исключает конкурирующую выдачу дублей). Также исключаем тексты,
      которые уже когда-либо были assigned/used для этой задачи.
    - Если указан пол (male/female), допускаем gender = user_gender или 'neutral'.
    """
    from models import TaskReviewText, User
    # Validate user_id and ensure user exists (FK safety)
    try:
        user_id_int = int(user_id)
    except Exception:
        return None
    if user_id_int <= 0:
        return None
    # ensure user exists in users table to satisfy FK
    try:
        User.get_or_create_user(user_id_int)
        db.session.flush()
    except Exception as _e:
        db.session.rollback()
        raise

    from models import TaskReviewText
    try:
        existing = (TaskReviewText.query
            .filter_by(task_id=task_id, assigned_user_id=user_id)
            .filter(TaskReviewText.status.in_(['assigned','used']))
            .order_by(TaskReviewText.id.asc())
            .first())
        if existing:
            return existing

        gender_clause = ''
        params = {'task_id': task_id, 'user_id': user_id}
        if user_gender in ('male','female'):
            gender_clause = " AND (t1.gender = :user_gender OR t1.gender = 'neutral')"
            params['user_gender'] = user_gender

        sql = _sqltext(f"""
            WITH picked AS (
                SELECT t1.id
                FROM task_review_texts t1
                WHERE t1.task_id = :task_id
                  AND t1.status = 'free'
                  {{gender_clause}}
                  -- выберем только минимальный id среди одинакового нормализованного текста
                  AND NOT EXISTS (
                      SELECT 1 FROM task_review_texts t0
                      WHERE t0.task_id = t1.task_id
                        AND lower(trim(t0.text)) = lower(trim(t1.text))
                        AND t0.id < t1.id
                  )
                  -- исключаем тексты, которые уже были назначены/использованы по содержанию
                  AND NOT EXISTS (
                      SELECT 1 FROM task_review_texts t2
                      WHERE t2.task_id = t1.task_id
                        AND lower(trim(t2.text)) = lower(trim(t1.text))
                        AND t2.status IN ('assigned','used')
                  )
                ORDER BY t1.id ASC
                FOR UPDATE SKIP LOCKED
                LIMIT 1
            )
            UPDATE task_review_texts t
            SET status = 'assigned', assigned_user_id = :user_id, assigned_at = NOW()
            FROM picked
            WHERE t.id = picked.id
            RETURNING t.id
        """.replace('{gender_clause}', gender_clause))

        res = db.session.execute(sql, params)
        row = res.fetchone()
        if not row:
            db.session.rollback()
            return None
        db.session.commit()
        return TaskReviewText.query.get(row[0])
    except Exception as e:
        try:
            db.session.rollback()
        except Exception:
            pass
        print('Error in get_or_assign_review_text:', e)
        return None
def mark_review_text_as_used(task_id: int, user_id: int, submission_id: int):
    """
    Помечает назначенный текст как использованный при отправке задания
    """
    from models import TaskReviewText
    try:
        text = TaskReviewText.query\
            .filter_by(task_id=task_id, assigned_user_id=user_id, status='assigned')\
            .first()
        
        if text:
            text.status = 'used'
            text.used_submission_id = submission_id
            db.session.commit()
            return True
    except Exception as e:
        try:
            db.session.rollback()
        except:
            pass
        print(f'Error marking text as used: {e}')
    return False

from avito_utils import (
    is_avito_task, 
    init_avito_submission, 
    save_chat_screenshot,
    check_avito_report_available, 
    cleanup_expired_avito_tasks,
    get_avito_submission_status
)
app = Flask(__name__)
app.url_map.strict_slashes = False
app.config.from_object(Config)

db.init_app(app)
migrate = Migrate(app, db)

# Создаем таблицу для текстов отзывов если её нет
with app.app_context():
    try:
        db.session.execute(_sqltext("""
        CREATE TABLE IF NOT EXISTS task_review_texts (
            id SERIAL PRIMARY KEY,
            task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
            text TEXT NOT NULL,
            status VARCHAR(20) DEFAULT 'free',
            gender VARCHAR(20) DEFAULT 'neutral',
            assigned_user_id BIGINT,
            assigned_at TIMESTAMP,
            used_submission_id INTEGER,
            created_at TIMESTAMP DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_trt_task_status ON task_review_texts(task_id, status);
        CREATE INDEX IF NOT EXISTS idx_trt_assigned_user ON task_review_texts(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_trt_gender ON task_review_texts(gender);
"""))
        db.session.commit()
    except Exception as _e:
        print('init task_review_texts error:', _e)

@app.before_request
def load_tg_user_id():
    """
    ИСПРАВЛЕНО 2.0: Загружает user_id из валидных источников с поддержкой URL параметров.
    Приоритеты:
    1. initData (самый надежный)
    2. Сессия (если уже авторизован)
    3. URL параметр user_id (только положительные ID)
    """
    # Авто-сброс просроченных броней при каждом запросе
    try:
        release_stale_assigned_texts()
    except:
        pass
    
    # Пропускаем обработку для статики
    if request.path.startswith('/static/'):
        return
    
    uid = None
    
    # 1. Пытаемся получить из initData (приоритет №1)
    init_data_sources = [
        request.form.get('initData'),
        request.args.get('initData'),
        request.form.get('tgWebAppData'),
        request.args.get('tgWebAppData'),
        request.headers.get('X-Telegram-Init-Data') or request.headers.get('X-Telegram-Web-App-Data') or request.headers.get('Telegram-Web-App-Data') or request.headers.get('X-Telegram-WebApp-Data')
    ]
    
    for init_data_raw in init_data_sources:
        if init_data_raw:
            try:
                from telegram_auth import verify_init_data
                tg_uid, tg_data = verify_init_data(init_data_raw)
                candidate_uid = int(tg_uid)
                # ЗАЩИТА: Принимаем только положительные ID
                if candidate_uid > 0:
                    uid = candidate_uid
                    session['user_id'] = uid
                    # Сохраняем дополнительные данные (если есть)
                    user_obj = (tg_data or {}).get('user') or {}
                    if 'first_name' in user_obj:
                        session['user_first_name'] = user_obj['first_name']
                    if 'username' in user_obj:
                        session['user_username'] = user_obj['username']
                    print(f'[WEBAPP] ✅ Авторизация через initData: user_id={uid}')
                    break
                else:
                    print(f'[WEBAPP] ⚠️ Отрицательный user_id из initData: {candidate_uid} - игнорируем')
            except Exception as e:
                print(f'[WEBAPP] ⚠️ Ошибка парсинга initData: {e}')
                continue
    
    # 2. Если initData не дала результата - берем из сессии (если уже авторизован)
    if not uid:
        session_uid = session.get('user_id')
        if session_uid:
            try:
                candidate_uid = int(session_uid)
                # ЗАЩИТА: Принимаем только положительные ID из сессии
                if candidate_uid > 0:
                    uid = candidate_uid
                else:
                    print(f'[WEBAPP] ⚠️ Отрицательный user_id в сессии: {candidate_uid} - очищаем')
                    session.pop('user_id', None)
            except (ValueError, TypeError):
                session.pop('user_id', None)
    
    # 3. ВОССТАНОВЛЕНО: Читаем user_id из URL параметров (с защитой от отрицательных ID)
    if not uid:
        url_uid = request.args.get('user_id') or request.form.get('user_id')
        if url_uid:
            try:
                candidate_uid = int(url_uid)
                # ЗАЩИТА: Принимаем только положительные ID
                if candidate_uid > 0:
                    uid = candidate_uid
                    session['user_id'] = uid
                    print(f'[WEBAPP] ✅ Авторизация через URL параметр: user_id={uid}')
                else:
                    print(f'[WEBAPP] ⚠️ Отрицательный user_id из URL: {candidate_uid} - игнорируем')
            except (ValueError, TypeError):
                print(f'[WEBAPP] ⚠️ Невалидный user_id в URL: {url_uid}')
                pass
    
    # Финальная валидация: если в сессии осталось что-то невалидное - чистим
    if 'user_id' in session:
        try:
            current_uid = int(session['user_id'])
            if current_uid <= 0:
                print(f'[WEBAPP] 🧹 Очистка невалидного user_id из сессии: {current_uid}')
                session.pop('user_id', None)
        except (ValueError, TypeError):
            session.pop('user_id', None)



# === ФОНОВАЯ ЗАДАЧА ДЛЯ АВИТО ===
import threading
import time

def avito_cleanup_worker():
    """Фоновая задача для очистки просроченных Авито заданий"""
    while True:
        try:
            with app.app_context():
                count = cleanup_expired_avito_tasks(db, AvitoSubmission, Submission, Assignment)
                if count > 0:
                    print(f'[AVITO CLEANUP] Очищено просроченных заданий: {count}')
        except Exception as e:
            print(f'[AVITO CLEANUP] Ошибка: {e}')
        
        # Проверяем каждые 5 минут
        time.sleep(300)

# Запускаем фоновый поток
cleanup_thread = threading.Thread(target=avito_cleanup_worker, daemon=True)
cleanup_thread.start()
print('[AVITO] Запущена фоновая задача очистки просроченных заданий')

@app.route('/static/uploads/<path:filename>')

def serve_uploaded_file(filename):
    try:
        upload_folder = app.config.get('UPLOAD_FOLDER', '/data/uploads')
        filename = filename.lstrip('/')
        primary_path = os.path.join(upload_folder, filename)
        if os.path.exists(primary_path):
            return send_from_directory(upload_folder, filename)
        legacy_folder = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
        legacy_path = os.path.join(legacy_folder, filename)
        if os.path.exists(legacy_path):
            rel = os.path.relpath(legacy_path, legacy_folder)
            return send_from_directory(legacy_folder, rel)
        return '', 404
    except Exception:
        return '', 404

# === ОСНОВНЫЕ РОУТЫ ===


@app.route('/')
@check_user_ban
def user_agreement():
    """Главная страница - пользовательское соглашение"""
    # Получаем user_id из query параметров или сессии
    g.user_id = request.args.get("user_id") or session.get("user_id")
    if g.user_id:
        session["user_id"] = g.user_id
        print(f"[WEBAPP] User ID установлен: {g.user_id}")

    user_id = session.get('user_id')
    return render_template('user_agreement.html', user_id=user_id)

@app.route('/services')
@check_user_ban
def services_menu():
    """Меню выбора услуг"""
    # Устанавливаем user_id
    g.user_id = session.get("user_id")
    user_id = session.get('user_id')
    return render_template('services_menu.html', user_id=user_id)

@app.route('/categories')
@check_user_ban
def categories():
    """Страница выбора категорий заданий"""
    g.user_id = session.get("user_id")
    user_id = session.get('user_id')
    return render_template('categories.html', user_id=user_id)

@app.route('/platform/<platform_key>')
@check_user_ban
def platform_tasks(platform_key):
    platform_key = normalize_platform_key(platform_key)
    # Устанавливаем user_id из сессии
    g.user_id = session.get('user_id')
    print(f'[WEBAPP PLATFORM] User ID:', int(g.user_id) if (g.user_id and int(g.user_id)>0) else 'guest')

    """ИСПРАВЛЕНО: Показать задания для конкретной платформы - только с доступными текстами"""
    # Получаем пол из GET параметра
    from flask import request
    user_gender = request.args.get('gender', None)
    
    # Если пол не указан в URL - перенаправляем на страницу выбора
    if not user_gender or user_gender not in ['male', 'female']:
        return redirect(url_for('select_gender', platform_key=platform_key))
    
    # Сохраняем пол в сессию ВРЕМЕННО, только для текущих операций в этом запросе
    session['user_gender_temp'] = user_gender
    
    user_id = session.get('user_id')
    # Авто-сброс просроченных броней текстов
    release_stale_assigned_texts()
    
    if platform_key not in PLATFORM_MAPPING:
        flash('Неизвестная платформа!', 'danger')
        return redirect(url_for('services_menu', user_id=user_id))
    
    platform_name = PLATFORM_MAPPING[platform_key]
    # Default limits (including guests):
    daily_limit = get_platform_daily_limit(platform_name)
    tasks_left = 1 if daily_limit != 999 else 999999

    
    # Получаем все активные задания для платформы
    tasks_all = Task.query.filter(Task.status=='active').filter(Task.platform.in_(PLATFORMS_ALIASES.get(platform_key, [platform_name]))).all()
    tasks = []
    
    for t in tasks_all:
        try:
            # Проверяем лимит выполнений
            if t.submission_limit and t.current_submissions >= t.submission_limit:
                continue
        except Exception:
            pass
        
        try:
            # Проверяем, не выполнял ли уже этот пользователь задание
            if has_user_submitted(int(user_id) if user_id else None, t.id):
                continue
        except Exception:
            pass
        
        from models import TaskReviewText as _TRT
        # ИСПРАВЛЕНО: Показываем задание если есть ЛЮБЫЕ доступные тексты (free или assigned текущему юзеру)
        has_assigned_to_user = False
        try:
            if user_id and str(user_id).isdigit():
                # Проверяем забронированные тексты С УЧЕТОМ ПОЛА
                if user_gender and user_gender in ['male', 'female']:
                    has_assigned_to_user = _TRT.query.filter(
                        _TRT.task_id == t.id,
                        _TRT.assigned_user_id == int(user_id),
                        _TRT.status.in_(['assigned', 'used']),
                        or_(_TRT.gender == user_gender, _TRT.gender == 'neutral')
                    ).first() is not None
                else:
                    has_assigned_to_user = _TRT.query.filter_by(task_id=t.id, assigned_user_id=int(user_id), status='assigned').first() is not None
        except Exception as ex1:
            print(f'[WEBAPP] Ошибка проверки has_assigned_to_user: {ex1}')
            has_assigned_to_user = False
        
        free_exists = False
        try:
            # Проверяем наличие свободных текстов С УЧЕТОМ ПОЛА
            if user_gender and user_gender in ['male', 'female']:
                free_exists = _TRT.query.filter(
                    _TRT.task_id == t.id,
                    _TRT.status == 'free',
                    or_(_TRT.gender == user_gender, _TRT.gender == 'neutral')
                ).first() is not None
            else:
                free_exists = _TRT.query.filter_by(task_id=t.id, status='free').first() is not None
        except Exception as ex2:
            print(f'[WEBAPP] Ошибка проверки free_exists: {ex2}')
            free_exists = False
        
        # КЛЮЧЕВОЕ: Показываем задание ТОЛЬКО если есть свободные тексты или бронь у пользователя
        # Показываем задание если:
        # 1) Есть бронь у текущего пользователя ИЛИ
        # 2) Есть свободные тексты нужного пола
        if not has_assigned_to_user and not free_exists:
            print(f'[WEBAPP] ❌ Задание {t.id} скрыто - нет доступных текстов для пола {user_gender}')
            continue

        print(f'[WEBAPP] ✅ Задание {t.id} показано (бронь={has_assigned_to_user}, свободных={free_exists})')
        
        # Если есть бронь или свободные - точно показываем
        tasks.append(t)

    # Daily limit and randomization for all limited platforms
    tasks_completed_today = 0
    daily_limit = get_platform_daily_limit(platform_name)
    tasks_left = tasks_left

    try:
        if user_id and str(user_id).isdigit() and get_platform_daily_limit(platform_name) != 999:
            can_take_task, tasks_completed_today, daily_limit = check_user_task_limit(int(user_id), platform_name)
            tasks_left = max(0, daily_limit - tasks_completed_today)
            if tasks_left <= 0:
                # Получаем информацию о лимите и последнем выполнении
                limit_info, hours_limit = get_platform_limit_info(platform_name)
                last_task_time = None
                if hours_limit is not None:
                    last_task_time = UserTaskLimit.get_last_task_time(int(user_id), platform_name)
                
                return render_template('limit_exceeded.html',
                                      platform_name=platform_name,
                                      platform_key=platform_key,
                                      tasks_completed=tasks_completed_today,
                                      daily_limit=daily_limit,
                                      user_id=user_id,
                                      last_task_time=last_task_time,
                                      hours_limit=hours_limit)
    except Exception as _e:
        print('limit calc error:', _e)
    # ИСПРАВЛЕНО: Закрепленное задание ВСЕГДА на первом месте
    pinned_task = None
    try:
        if user_id and str(user_id).isdigit():
            p = get_valid_pinned_task(int(user_id))
            # Ensure pinned belongs to current platform aliases
            if p and p.platform in PLATFORMS_ALIASES.get(platform_key, [platform_name]):
                pinned_task = p
                print(f'[WEBAPP] ✅ Найдено закрепленное задание {p.id} для user {user_id}')
            elif p:
                print(f'[WEBAPP] ⚠️ Закрепленное задание {p.id} не относится к платформе {platform_name}')
    except Exception as _e:
        print(f'[WEBAPP] ❌ Ошибка загрузки закрепленного задания: {_e}')

    # ВАЖНО: Исключаем закрепленное из общего списка
    if pinned_task:
        tasks = [t for t in tasks if t.id != pinned_task.id]
        print(f'[WEBAPP] Исключили закрепленное задание из рандома, осталось {len(tasks)} заданий')

    # Перемешиваем остальные задания
    try:
        random.shuffle(tasks)
    except Exception:
        pass

    # Формируем финальный список
    tasks_final = []
    if daily_limit != 999:
        # how many we can show in addition to pinned
        extra = tasks_left - (1 if pinned_task else 0)
        extra = max(0, extra)  # ИСПРАВЛЕНО: гарантируем неотрицательное значение
        tasks_final = ([pinned_task] if pinned_task else []) + tasks[:extra]
        print(f'[WEBAPP] Финальный список: закреплено={1 if pinned_task else 0}, остальных={len(tasks[:extra])}')
    else:
        tasks_final = ([pinned_task] if pinned_task else []) + tasks
        print(f'[WEBAPP] Финальный список (без лимита): всего {len(tasks_final)} заданий')

    return render_template('platform.html', 
                         platform_key=platform_key,
                         platform_name=platform_name, 
                         tasks=tasks_final,
                         user_id=user_id,
                         tasks_completed_today=tasks_completed_today,
                         daily_limit=daily_limit,
                         tasks_left=tasks_left,
                         user_gender=user_gender)




@app.route('/category/<category_name>')
@check_user_ban
def show_category_tasks(category_name):
    """Показать задания по категории"""
    user_id = session.get('user_id')
    
    # Фильтруем задания по категории
    tasks = Task.query.filter_by(category=category_name, status='active').all()
    
    return render_template('category.html',
                         category_name=category_name,
                         tasks=tasks,
                         user_id=user_id)


@app.route('/select_gender/<platform_key>')
@check_user_ban
def select_gender(platform_key):
    """Страница выбора пола аккаунта для платформы"""
    return render_template('select_gender.html', platform_key=platform_key)

@app.route('/set_gender/<gender>/<platform_key>')
@check_user_ban  
def set_gender(gender, platform_key):
    """Переход к заданиям платформы с выбранным полом"""
    # Проверяем валидность пола
    if gender not in ['male', 'female']:
        flash('Некорректный выбор пола', 'danger')
        return redirect(url_for('select_gender', platform_key=platform_key))
    
    # НЕ сохраняем пол в сессию - передаем через URL
    # Переходим к заданиям платформы с указанием пола
    return redirect(url_for('platform_tasks', platform_key=platform_key, gender=gender))

@app.route('/perform_task/<int:task_id>', methods=['GET','POST'])
@check_user_ban
def perform_task(task_id):
    # guest submit guard
    from flask import request, session, abort
    try:
        # For POST submissions require real Telegram user (positive id)
        if request.method == 'POST':
            uid = session.get('user_id')
            if uid is None or int(uid) <= 0:
                return ('Требуется авторизация через Telegram WebApp', 401)
    except Exception:
        pass
    """Страница выполнения задания (без редиректа на GET, user_id только из session/initData)"""
    task = Task.query.get_or_404(task_id)
    sess_uid = session.get('user_id')
    
    # ИСПРАВЛЕНО: Сначала определяем uid, потом используем
    uid = int(sess_uid) if isinstance(sess_uid, int) or (isinstance(sess_uid, str) and sess_uid.isdigit()) else None

    # fallback from args user_id if session is empty
    try:
        from flask import request as _rq
        if uid is None:
            arg_uid = _rq.args.get('user_id')
            if arg_uid and str(arg_uid).isdigit():
                session['user_id'] = int(arg_uid)
                uid = int(arg_uid)
    except Exception as _e:
        print(f'[WEBAPP] fallback uid from args failed: {_e}')

    # Гарантируем, что пользователь существует до закрепления
    try:
        if uid:
            _user_obj, _created = User.get_or_create_user(uid)
            db.session.flush()
    except Exception as _uerr:
        try:
            db.session.rollback()
        except Exception:
            pass
    # ИСПРАВЛЕНО: Принудительно закрепляем задание при переходе в него (И GET И POST!)
    try:
        if uid:
            result = assign_task_if_none(uid, task_id)
            
            # Инициализация Авито submission если это Авито задание
            if is_avito_task(task):
                submission, error = init_avito_submission(uid, task_id)
                if error:
                    print(f'[AVITO] Ошибка инициализации: {error}')
                else:
                    print(f'[AVITO] ✅ Задание инициализировано для user {uid}')

            print(f'[WEBAPP] 🔒 Закрепление задания {task_id} для user {uid}: {result}')
    except Exception as _e:
        print(f'[WEBAPP] ❌ Ошибка закрепления задания {task_id} для user {uid}: {_e}')

    # TTL cleanup ПОСЛЕ закрепления задания (чтобы не сбросить только что закрепленный текст)
    release_stale_assigned_texts()
    # Получаем пол пользователя из URL параметров
    from flask import request
    user_gender = request.args.get('gender', None)
    # Если пол не указан, пробуем взять из временной сессии
    if not user_gender:
        user_gender = session.get('user_gender_temp', None)
    assigned_review = get_or_assign_review_text(task_id, uid, user_gender) if uid else None

    reverse_map = {v: k for k, v in PLATFORM_MAPPING.items()}
    platform_key = reverse_map.get(task.platform, 'yandex-maps')
    subtasks = Subtask.query.filter_by(task_id=task_id).all()

    if request.method == 'POST':
        if not uid:
            flash('Откройте задание из Telegram-бота, чтобы отправить отчёт.', 'danger')
            return redirect(request.url)
        fio = (request.form.get('fio') or '').strip()
        notes = (request.form.get('notes') or '').strip()
        file = request.files.get('screenshot')
        if not fio or not file:
            flash('Пожалуйста, заполните все обязательные поля', 'danger')
            return redirect(request.url)

        
        # Проверка для Авито - можно ли отправлять отчет
        is_avito = is_avito_task(task)
        existing_submission = None
        
        if is_avito:
            # Проверяем можно ли отправить отчет для Avito
            available, message, time_left = check_avito_report_available(uid, task_id)
            if not available:
                flash(message, 'warning')
                return redirect(request.url)
            
            # Проверка дубликата
            existing_submission = Submission.query.filter_by(user_id=uid, task_id=task.id).first()
            if existing_submission:
                flash('Вы уже отправили отчет по этому заданию.', 'warning')
                return redirect(url_for('task_submitted', task_id=task.id))
        else:
            # Duplicate guard для не-Авито заданий
            try:
                from models import Submission as _SubmissionCheck
                if _SubmissionCheck.query.filter_by(user_id=uid, task_id=task.id).first():
                    flash('Вы уже выполняли это задание. Доступно одно выполнение на пользователя.', 'warning')
                    return redirect(url_for('task_submitted', task_id=task.id))
            except Exception:
                pass

        # Task limit guard
        try:
            if task.submission_limit and task.current_submissions >= task.submission_limit:
                flash('Лимит выполнений для этого задания достигнут. Выберите другое задание.', 'warning')
                return redirect(url_for('platform_tasks', platform_key=platform_key))
        except Exception:
            pass

        # Ensure user exists
        try:
            user_obj, created = User.get_or_create_user(uid, fio)
            if created:
                db.session.commit()
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка создания пользователя: {e}', 'danger')
            return redirect(request.url)

        # Save file
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        filename = secure_filename(f"{uuid.uuid4().hex}_" + (file.filename or 'screenshot.png'))
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        # Создаем новый submission (и для Avito и для остальных)
        # Для Авито:
        #   - screenshot_url = скрин переписки (загружается первым через API)
        #   - review_screenshot_url = скрин отзыва (загружается вторым через форму)
        if is_avito:
            # Получаем скрин переписки из AvitoSubmission
            try:
                from models import AvitoSubmission
                avito_sub = AvitoSubmission.query.filter_by(
                    user_id=uid,
                    task_id=task.id
                ).first()
                
                if not avito_sub or not avito_sub.chat_screenshot_path:
                    flash('Ошибка: скрин переписки не найден', 'danger')
                    return redirect(request.url)
                
                # Создаем submission с ОБОИМИ скринами
                submission = Submission(
                    user_id=uid,
                    user_id_bi=uid,
                    task_id=task.id,
                    fio=fio,
                    full_name=fio,
                    notes=notes,
                    description=(assigned_review.text if assigned_review else (notes or '')),
                    screenshot_url=avito_sub.chat_screenshot_path,  # Скрин 1: переписка
                    review_screenshot_url=filename,  # Скрин 2: отзыв
                    status='pending',
                    submission_time=datetime.utcnow(),
                    submitted_at=datetime.utcnow()
                )
                db.session.add(submission)
                db.session.flush()  # Чтобы получить submission.id
                
                # Связываем с AvitoSubmission
                avito_sub.submission_id = submission.id
                avito_sub.report_submitted = True
                
                print(f'[AVITO] ✅ Submission {submission.id} создан с двумя скринами: chat={avito_sub.chat_screenshot_path}, review={filename}')
                
            except Exception as e:
                db.session.rollback()
                print(f'[AVITO] ❌ Ошибка создания Submission: {e}')
                flash(f'Ошибка создания отчета: {e}', 'danger')
                return redirect(request.url)
        else:
            # Для остальных платформ - обычный submission с одним скрином
            submission = Submission(
                    user_id=uid,
                    user_id_bi=uid,
                    task_id=task.id,
                    fio=fio,
                    full_name=fio,
                    notes=notes,
                    description=(assigned_review.text if assigned_review else (notes or '')),
                    screenshot_url=filename,
                    status='pending',
                    submission_time=datetime.utcnow(),
                    submitted_at=datetime.utcnow()
            )
            db.session.add(submission)

        try:
            db.session.commit()
            
            try:
                UserTaskLimit.increment_user_tasks(uid, task.platform)
            except Exception as e:
                print(f'UserTaskLimit increment error: {e}')
            if assigned_review:
                mark_review_text_as_used(task.id, uid, submission.id)
            # Снимаем закрепление задания после успешной отправки
            try:
                clear_pinned_task(uid, only_if_task_id=task.id)
            except Exception as _clr_err:
                print(f'clear_pinned_task after submit error: {_clr_err}')
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка сохранения заявки: {e}', 'danger')
            return redirect(request.url)

        # Notifications best-effort
        try:
            from integration_api import notify_admin_new_submission, notify_bot_submission_sent
            notify_admin_new_submission({
                'submission_id': submission.id,
                'user_id': submission.user_id,
                'task_id': submission.task_id,
                'task_title': task.title,
                'status': submission.status,
                'time': submission.submission_time.isoformat() if submission.submission_time else None
            })
            if submission.user_id:
                notify_bot_submission_sent(submission.user_id, task.title, submission.id, task.platform)
        except Exception:
            pass

        return redirect(url_for('task_submitted', task_id=task.id))

    # ИСПРАВЛЕНО: Проверяем не только assigned_review, но и уже выполненные задания
    # Если пользователь уже выполнял это задание - показываем его текст
    if uid and not assigned_review:
        # Проверяем есть ли у пользователя уже выполненное задание с текстом
        try:
            from models import TaskReviewText
            existing_submission = Submission.query.filter_by(
                user_id=uid, 
                task_id=task.id
            ).first()
            
            if existing_submission:
                # Находим текст, который использовался в этом submission
                used_text = TaskReviewText.query.filter_by(
                    task_id=task.id,
                    assigned_user_id=uid,
                    status='used'
                ).first()
                
                if used_text:
                    assigned_review = used_text
                else:
                    # Задание выполнено, но без текста отзыва
                    flash('Вы уже выполнили это задание', 'info')
                    return redirect(url_for('task_submitted', task_id=task.id))
            else:
                # Нет свободных текстов и пользователь не выполнял задание
                flash('Для этого задания сейчас нет свободных текстов отзыва. Попробуйте позже.', 'warning')
                return redirect(url_for('platform_tasks', platform_key=platform_key))
        except Exception as e:
            print(f'Error checking existing submission: {e}')
            flash('Для этого задания сейчас нет свободных текстов отзыва. Попробуйте позже.', 'warning')
            return redirect(url_for('platform_tasks', platform_key=platform_key))

    # GET: show page. If uid unknown, submission button still visible per design, but POST will be blocked
    return render_template('perform_task.html', task=task, subtasks=subtasks, user_id=session.get('user_id'), assigned_review=assigned_review, assigned_review_text=(assigned_review.text if assigned_review else None))





@app.route('/api/get_review_text')
def api_get_review_text():
    """API для динамической загрузки текста отзыва.
    - При валидном user_id (>0): атомарно назначает и возвращает закрепленный текст.
    - При отсутствии/некорректном user_id: возвращает ПРЕВЬЮ первого доступного текста без назначения.
    """
    try:
        task_id = request.args.get('task_id', type=int)
        user_id = request.args.get('user_id', type=int)
        gender = request.args.get('gender', None)
        if not task_id:
            from flask import jsonify
            resp = jsonify({'review_text': None})
            resp.headers['Cache-Control'] = 'no-store'
            return resp

        # cleanup старых броней
        try:
            release_stale_assigned_texts()
        except Exception:
            pass

        # Валидный пользователь -> выдаем закрепленный/назначаем
        if user_id and isinstance(user_id, int) and user_id > 0:
            try:
                assign_task_if_none(user_id, task_id)
            except Exception:
                pass
            assigned_review = get_or_assign_review_text(task_id, user_id, gender)
            from flask import jsonify
            resp = jsonify({'review_text': assigned_review.text if assigned_review else None})
            resp.headers['Cache-Control'] = 'no-store'
            return resp

        # Гостевой режим -> превью без назначения
        from models import TaskReviewText
        try:
            q = TaskReviewText.query.filter_by(task_id=task_id, status='free')
            if gender in ('male','female'):
                q = q.filter((TaskReviewText.gender==gender) | (TaskReviewText.gender=='neutral'))
            row = q.order_by(TaskReviewText.id.asc()).first()
            preview_text = row.text if row else None
        except Exception:
            preview_text = None
        from flask import jsonify
        resp = jsonify({'review_text': preview_text, 'preview': True})
        resp.headers['Cache-Control'] = 'no-store'
        return resp
    except Exception as e:
        print(f'[API] Ошибка в api_get_review_text: {e}')
        from flask import jsonify
        resp = jsonify({'review_text': None, 'error': str(e)})
        resp.headers['Cache-Control'] = 'no-store'
        return resp

@app.route('/task/<int:task_id>')
@check_user_ban
def task_detail(task_id):
    """ИСПРАВЛЕНО: Детальная страница задания с резервированием текста и проверкой лимитов"""
    user_id = session.get('user_id')
    task = Task.query.get_or_404(task_id)
    
    # НОВОЕ: Проверяем лимит пользователя перед показом деталей
    if user_id and str(user_id).isdigit():
        user_id_int = int(user_id)
        can_take_task, tasks_today, daily_limit = check_user_task_limit(user_id_int, task.platform)
        
        # Если лимит исчерпан - редирект на страницу лимита
        if not can_take_task:
            reverse_map = {v:k for k,v in PLATFORM_MAPPING.items()}
            platform_key = reverse_map.get(task.platform, 'yandex-maps')
            return render_template('limit_exceeded.html',
                                 platform_name=task.platform,
                                 platform_key=platform_key,
                                 tasks_completed=tasks_today,
                                 daily_limit=daily_limit,
                                 user_id=user_id)
    
    # КЛЮЧЕВОЕ ИЗМЕНЕНИЕ: Резервируем текст отзыва при просмотре деталей
    assigned_review = None
    if user_id and str(user_id).isdigit():
        assigned_review = get_or_assign_review_text(task_id, int(user_id))
    
    # Если нет доступного текста - показываем предупреждение
    if not assigned_review and user_id:
        flash('Извините, для этого задания больше нет доступных текстов отзывов.', 'warning')
    
    # Вычисляем platform_key для обратной ссылки
    reverse_map = {v:k for k,v in PLATFORM_MAPPING.items()}
    platform_key = reverse_map.get(task.platform, 'yandex-maps')
    subtasks = Subtask.query.filter_by(task_id=task_id).all()
    
    # Проверяем дубликаты выполнения
    if user_id and has_user_submitted(int(user_id), task_id):
        flash('Вы уже выполняли это задание. Доступно только одно выполнение на пользователя.', 'warning')
        return redirect(url_for('task_submitted', task_id=task_id, user_id=user_id))
    
    return render_template('task_detail.html',
                         task=task,
                         subtasks=subtasks,
                         platform_key=platform_key,
                         user_id=user_id,
                         assigned_review_text=assigned_review.text if assigned_review else None)



@app.route('/api/avito/get_status/<int:task_id>', methods=['GET'])
def avito_get_status(task_id):
    """
    API для получения статуса Авито задания
    Возвращает информацию о таймерах и возможности отправки отчета
    """
    try:
        from flask import jsonify, session
        from models import AvitoSubmission
        
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'Требуется авторизация'
            }), 401
        
        task = Task.query.get(task_id)
        if not task or not is_avito_task(task):
            return jsonify({
                'success': False,
                'error': 'Это не задание Авито'
            }), 400
        
        avito_sub = AvitoSubmission.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()
        
        if not avito_sub:
            return jsonify({
                'success': False,
                'error': 'Задание не найдено'
            }), 404
        
        now = datetime.utcnow()
        
        # Проверяем 2-часовой таймер для скрина переписки
        chat_time_limit = avito_sub.started_at + timedelta(hours=2)
        chat_time_left = (chat_time_limit - now).total_seconds()
        chat_expired = chat_time_left <= 0

        # AUTO-EXPIRE: если 2 часа истекли и скрин не загружен — помечаем как истёкшее и снимаем Assignment
        if chat_expired and not avito_sub.chat_screenshot_path and not avito_sub.is_expired:
            avito_sub.is_expired = True
            try:
                assignment = Assignment.query.filter_by(user_id=avito_sub.user_id, task_id=avito_sub.task_id).first()
                if assignment:
                    db.session.delete(assignment)
            except Exception:
                pass
            try:
                db.session.commit()
            except Exception:
                db.session.rollback()
    
        
        # Проверяем можно ли отправить отчет
        report_available = False
        report_time_left = 0
        
        if avito_sub.chat_screenshot_path and avito_sub.report_available_at:
            report_time_left = (avito_sub.report_available_at - now).total_seconds()
            report_available = report_time_left <= 0
        
        return jsonify({
            'success': True,
            'data': {
                'started_at': avito_sub.started_at.isoformat(),
                'chat_screenshot_uploaded': bool(avito_sub.chat_screenshot_path),
                'chat_time_left_seconds': max(0, int(chat_time_left)),
                'chat_expired': chat_expired,
                'report_available': report_available,
                'report_available_at': avito_sub.report_available_at.isoformat() if avito_sub.report_available_at else None,
                'report_time_left_seconds': max(0, int(report_time_left)),
                'report_submitted': avito_sub.report_submitted,
                'is_expired': avito_sub.is_expired
            }
        })
        
    except Exception as e:
        print(f'[AVITO] Ошибка get_status: {e}')
        return jsonify({
            'success': False,
            'error': f'Ошибка: {str(e)}'
        }), 500

@app.route('/task_submitted/<int:task_id>')
@check_user_ban
def task_submitted(task_id):
    """Страница подтверждения отправки задания"""
    user_id = session.get('user_id')
    task = Task.query.get_or_404(task_id)
    
    reverse_map = {v:k for k,v in PLATFORM_MAPPING.items()}
    platform_key = reverse_map.get(task.platform, 'yandex-maps')
    
    return render_template('task_submitted.html',
                         task=task,
                         platform_key=platform_key,
                         user_id=user_id)


# Автоматическое создание таблицы лимитов при запуске
try:
    with app.app_context():
        # Проверяем, существует ли таблица user_task_limits
        try:
            db.session.execute(_sqltext('SELECT 1 FROM user_task_limits LIMIT 1'))
            print("✅ Таблица user_task_limits найдена")
        except:
            # Создаем все таблицы (включая новую)
            db.create_all()
            print("✅ Создана таблица user_task_limits")
except Exception as e:
    print(f"Ошибка при создании таблиц: {e}")



@app.route('/banned')
def banned_page():
    """Страница информации о бане"""
    user_id = session.get('user_id')
    
    if not user_id:
        return redirect(url_for('index'))
    
    # Проверяем бан
    is_banned, ban_info = UserBan.is_user_banned(user_id)
    
    if not is_banned:
        # Если не забанен, перенаправляем на главную
        return redirect(url_for('index'))
    
    # Получаем информацию о бане
    ban_data = ban_info.get_ban_info()
    
    # Проверяем тип бана
    if ban_info.banned_by == 'SYSTEM_AUTOBAN':
        return render_template('banned_autoban_yandex.html', **ban_data)
    else:
        return render_template('banned.html', **ban_data)




# ============================================
# РОУТЫ ДЛЯ АВИТО
# ============================================

# ==================== AVITO ROUTES ====================

@app.route('/api/avito/check_status/<int:task_id>')
def avito_check_status(task_id):
    """Проверяет статус Avito задания для текущего пользователя"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Не авторизован'}), 401
        
        from avito_utils import get_avito_submission_status
        status = get_avito_submission_status(db, AvitoSubmission, user_id, task_id)
        
        return jsonify(status)
    
    except Exception as e:
        app.logger.error(f"Error checking avito status: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/avito/upload_chat_screenshot/<int:task_id>', methods=['POST'])
def avito_upload_chat_screenshot(task_id):
    """Загружает скриншот переписки для Avito - ИСПРАВЛЕНО"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Не авторизован'}), 401
        
        if 'screenshot' not in request.files:
            return jsonify({'error': 'Файл не найден'}), 400
        
        file = request.files['screenshot']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        task = Task.query.get(task_id)
        if not task:
            return jsonify({'error': 'Задание не найдено'}), 404
        
        if not is_avito_task(task):
            return jsonify({'error': 'Это не Авито'}), 400
        
        avito_sub = AvitoSubmission.query.filter_by(user_id=user_id, task_id=task_id).first()
        
        if not avito_sub:
            now = datetime.utcnow()
            avito_sub = AvitoSubmission(user_id=user_id, task_id=task_id, started_at=now)
            db.session.add(avito_sub)
            db.session.commit()
            print(f'[AVITO] Создан AvitoSubmission для user {user_id}, task {task_id}')
        
        if avito_sub.is_expired:
            return jsonify({'error': 'Время истекло'}), 400
        
        now = datetime.utcnow()
        deadline = avito_sub.started_at + timedelta(hours=2)
        
        if now > deadline:
            avito_sub.is_expired = True
            db.session.commit()
            return jsonify({'error': 'Время истекло (>2ч)'}), 400
        
        # ИСПРАВЛЕНИЕ: Правильное сохранение файла
        upload_folder = os.path.join(app.config.get('UPLOAD_FOLDER', '/data/uploads'), 'avito_chat')
        os.makedirs(upload_folder, exist_ok=True)
        
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        new_filename = f'avito_chat_{user_id}_{task_id}_{timestamp}_{filename}'
        
        filepath = os.path.join(upload_folder, new_filename)
        file.save(filepath)
        
        # ВАЖНО: сохраняем путь БЕЗ static/
        db_path = f'avito_chat/{new_filename}'
        
        # ИСПРАВЛЕНИЕ: Создаем или обновляем Submission
        submission = Submission.query.filter_by(user_id=user_id, task_id=task_id, status='pending').first()
        
        if not submission:
            submission = Submission(
                user_id=user_id,
                user_id_bi=user_id,
                task_id=task_id,
                screenshot_url=db_path,
                status='pending',
                submission_time=now,
                created_at=now
            )
            db.session.add(submission)
            print(f'[AVITO] Создан Submission с 1-м скрином')
        else:
            submission.screenshot_url = db_path
            print(f'[AVITO] Обновлен Submission #{submission.id}')
        
        avito_sub.chat_screenshot_path = db_path
        avito_sub.chat_screenshot_uploaded_at = now
        avito_sub.report_available_at = now + timedelta(hours=24)
        
        db.session.flush()
        avito_sub.submission_id = submission.id
        db.session.commit()
        
        print(f'[AVITO] Скрин переписки сохранен: {filepath}')
        print(f'[AVITO] DB путь: {db_path}')
        print(f'[AVITO] Submission ID: {submission.id}')
        
        return jsonify({
            'success': True,
            'message': 'Скриншот переписки загружен! Отчет через 24 часа.',
            'report_available_at': avito_sub.report_available_at.isoformat(),
            'path': db_path
        })
    
    except Exception as e:
        db.session.rollback()
        print(f'[AVITO] ОШИБКА: {e}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'{str(e)}'}), 500


@app.route('/api/avito/upload_final_report/<int:task_id>', methods=['POST'])
def avito_upload_final_report(task_id):
    """Загружает финальный отчет для Avito"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Не авторизован'}), 401
        
        if 'screenshot' not in request.files:
            return jsonify({'error': 'Файл не найден'}), 400
        
        file = request.files['screenshot']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        task = Task.query.get(task_id)
        if not task or not is_avito_task(task):
            return jsonify({'error': 'Задание не найдено'}), 404
        
        avito_sub = AvitoSubmission.query.filter_by(user_id=user_id, task_id=task_id).first()
        
        if not avito_sub or not avito_sub.chat_screenshot_path:
            return jsonify({'error': 'Сначала загрузите скрин переписки!'}), 404
        
        now = datetime.utcnow()
        if avito_sub.report_available_at and now < avito_sub.report_available_at:
            time_left = (avito_sub.report_available_at - now).total_seconds()
            hours_left = int(time_left // 3600)
            minutes_left = int((time_left % 3600) // 60)
            return jsonify({'error': f'Через {hours_left}ч {minutes_left}мин'}), 403
        
        upload_folder = os.path.join(app.config.get('UPLOAD_FOLDER', '/data/uploads'), 'avito_reports')
        os.makedirs(upload_folder, exist_ok=True)
        
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        new_filename = f'report_{user_id}_{task_id}_{timestamp}_{filename}'
        filepath = os.path.join(upload_folder, new_filename)
        file.save(filepath)
        
        submission = Submission.query.filter_by(user_id=user_id, task_id=task_id).first()
        
        if not submission:
            submission = Submission(
                user_id=user_id,
                user_id_bi=user_id,
                task_id=task_id,
                screenshot_url=avito_sub.chat_screenshot_path,
                status='pending',
                submission_time=now,
                created_at=now
            )
            db.session.add(submission)
        
        submission.review_screenshot_url = os.path.join('avito_reports', new_filename)
        submission.submitted_at = now
        submission.status = 'pending'
        
        avito_sub.report_submitted = True
        
        if not avito_sub.submission_id:
            db.session.flush()
            avito_sub.submission_id = submission.id
        
        db.session.commit()
        
        print(f'[AVITO] Отчет OK: sub={submission.id}, скрин1={submission.screenshot_url}, скрин2={filepath}')
        
        return jsonify({
            'success': True,
            'message': 'Отчет отправлен!',
            'submission_id': submission.id
        })
    
    except Exception as e:
        db.session.rollback()
        print(f'[AVITO] ОШИБКА отчета: {e}')
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'{str(e)}'}), 500


@app.route('/api/avito/check_report_available/<int:task_id>')
def avito_check_report(task_id):
    """Проверяет, доступна ли отправка отчета"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Не авторизован'}), 401
        
        avito_sub = AvitoSubmission.query.filter_by(
            user_id=user_id,
            task_id=task_id
        ).first()
        
        if not avito_sub:
            return jsonify({'available': False, 'reason': 'Задание не найдено'}), 404
        
        if not avito_sub.chat_screenshot_path:
            return jsonify({
                'available': False,
                'reason': 'Сначала загрузите скриншот переписки'
            })
        
        if not avito_sub.report_available_at:
            return jsonify({
                'available': False,
                'reason': 'Время отправки отчета не установлено'
            })
        
        now = datetime.utcnow()
        if now < avito_sub.report_available_at:
            time_left = avito_sub.report_available_at - now
            hours_left = int(time_left.total_seconds() / 3600)
            minutes_left = int((time_left.total_seconds() % 3600) / 60)
            
            return jsonify({
                'available': False,
                'reason': f'Отчет можно отправить через {hours_left}ч {minutes_left}м',
                'hours_left': hours_left,
                'minutes_left': minutes_left
            })
        
        return jsonify({
            'available': True,
            'message': 'Можете отправить отчет'
        })
    
    except Exception as e:
        app.logger.error(f"Error checking report availability: {e}")
        return jsonify({'error': str(e)}), 500

# ==================== END AVITO ROUTES ====================


@app.route('/auth_init', methods=['POST'])
def auth_init():
    """Устанавливает session['user_id'] из Telegram WebApp initData (безопасно)."""
    try:
        init_data = request.form.get('tgWebAppData') or request.form.get('initData')
        if not init_data:
            return ('Missing initData', 400)
        from telegram_auth import verify_init_data
        uid, _ = verify_init_data(init_data, max_age_seconds=86400)
        session['user_id'] = int(uid)
        return ('', 204)
    except Exception as e:
        return (str(e), 400)



        pass

@app.route('/whoami')
def whoami():
    try:
        uid = session.get('user_id')
        from flask import jsonify
        resp = jsonify({'user_id': int(uid) if uid is not None else None})
        resp.headers['Cache-Control'] = 'no-store'
        return resp
    except Exception:
        from flask import jsonify
        resp = jsonify({'user_id': None})
        resp.headers['Cache-Control'] = 'no-store'
        return resp
