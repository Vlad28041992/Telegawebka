# admin_views.py
from flask_admin.contrib.sqla import ModelView
from flask_admin import BaseView, expose
from flask_login import current_user
from flask import redirect, url_for, request, flash, Markup
from wtforms import fields

# Импортируем все модели
from models import AdminUser, User, Task, Subtask, Submission, Achievement, UserAchievement

class SecuredView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and isinstance(current_user, AdminUser)

    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('login', next=request.url))

class AdminUserView(SecuredView):
    column_list = ['id', 'username']
    column_searchable_list = ['username']
    form_columns = ['username', 'password']

    def on_model_change(self, form, model, is_created):
        if getattr(form, 'password', None) and form.password.data:
            try:
                model.set_password(form.password.data)
            except Exception:
                from werkzeug.security import generate_password_hash
                if hasattr(model, 'password_hash'):
                    model.password_hash = generate_password_hash(form.password.data)
        elif is_created:
            pass

    column_exclude_list = ['password']
    form_extra_fields = {
        'password': fields.PasswordField('Пароль')
    }

class UserView(SecuredView):
    column_list = ['id', 'user_id', 'username', 'balance', 'total_points', 'total_earnings', 'points']
    column_searchable_list = ['username', 'user_id']
    column_filters = ['balance', 'total_points']

class TaskView(SecuredView):
    column_list = ['id', 'title', 'description', 'reward_money', 'reward_points', 'category', 'platform', 'status', 'created_at']
    column_searchable_list = ['title', 'description', 'category', 'platform']
    column_filters = ['category', 'platform', 'status', 'reward_money', 'reward_points']
    column_editable_list = ['status']
    create_modal = True
    edit_modal = True

class SubtaskView(SecuredView):
    column_list = ['id', 'task_id', 'title', 'description', 'points_value', 'is_required', 'is_completed']
    column_searchable_list = ['title', 'description']
    column_filters = ['task_id', 'is_required', 'is_completed']
    form_columns = ['task_id', 'title', 'description', 'points_value', 'is_required']
    column_labels = {
        'task_id': 'ID Задания',
        'title': 'Название шага',
        'description': 'Описание',
        'points_value': 'Очки',
        'is_required': 'Обязательный шаг',
        'is_completed': 'Завершено'
    }
    create_modal = True
    edit_modal = True

class SubmissionView(SecuredView):
    # ИСПРАВЛЕНО: Добавлены оба скриншота для Авито
    column_list = ['id', 'user_id', 'task_id', 'fio', 'screenshot_url', 'review_screenshot_url', 'notes', 'status', 'submitted_at', 'approved_at', 'admin_comment']
    column_searchable_list = ['fio', 'notes', 'status']
    column_filters = ['status', 'submitted_at', 'user_id', 'task_id']
    column_editable_list = ['status', 'admin_comment']
    
    # Добавляем лейблы для лучшего отображения
    column_labels = {
        'user_id': 'ID Пользователя',
        'task_id': 'ID Задания',
        'fio': 'ФИО',
        'screenshot_url': 'Скрин 1 (Переписка)',
        'review_screenshot_url': 'Скрин 2 (Отчет)',
        'notes': 'Заметки',
        'status': 'Статус',
        'submitted_at': 'Дата подачи',
        'approved_at': 'Дата одобрения',
        'admin_comment': 'Комментарий админа'
    }
    
    # ИСПРАВЛЕНИЕ: Правильное отображение ОБОИХ скриншотов
    def _format_screenshot(view, context, model, name):
        """Форматирует отображение скриншота"""
        if name == 'screenshot_url':
            url = model.screenshot_url
            label = 'Скрин 1'
        elif name == 'review_screenshot_url':
            url = model.review_screenshot_url
            label = 'Скрин 2'
        else:
            return 'Нет'
        
        if not url:
            return Markup('<span style="color: gray;">Нет</span>')
        
        # Проверяем является ли это Авито задание
        try:
            task = model.task
            is_avito = task and ('авито' in task.platform.lower() or 'avito' in task.platform.lower())
        except:
            is_avito = False
        
        # Формируем правильный URL
        if url.startswith('http'):
            full_url = url
        elif url.startswith('/static/'):
            full_url = url
        elif url.startswith('static/'):
            full_url = '/' + url
        else:
            full_url = f'/static/uploads/{url}'
        
        return Markup(f'<a href="{full_url}" target="_blank" style="color: #007bff; text-decoration: underline;">{label} 🖼️</a>')
    
    column_formatters = {
        'screenshot_url': _format_screenshot,
        'review_screenshot_url': _format_screenshot
    }
    
    can_edit = True
    can_delete = True
    can_create = False

class AchievementView(SecuredView):
    column_list = ['id', 'name', 'description', 'required_tasks', 'reward_points']
    column_searchable_list = ['name', 'description']
    column_filters = ['required_tasks', 'reward_points']

class UserAchievementView(SecuredView):
    column_list = ['user_id', 'achievement_id', 'awarded_at']
    column_filters = ['user_id', 'achievement_id', 'awarded_at']
    form_columns = ['user_id', 'achievement_id', 'awarded_at']
    column_labels = {
        'user_id': 'ID Пользователя', 
        'achievement_id': 'ID Достижения',
        'awarded_at': 'Дата получения'
    }

def init_admin_views(admin, db):
    from werkzeug.security import generate_password_hash

    admin.add_view(AdminUserView(AdminUser, db.session, name='Админ-пользователи'))
    admin.add_view(UserView(User, db.session, name='Пользователи'))
    admin.add_view(TaskView(Task, db.session, name='Задания'))
    admin.add_view(SubtaskView(Subtask, db.session, name='Подзадания'))
    admin.add_view(SubmissionView(Submission, db.session, name='Отчеты'))
    admin.add_view(AchievementView(Achievement, db.session, name='Достижения'))
    admin.add_view(UserAchievementView(UserAchievement, db.session, name='Достижения пользователей'))
