import os
import json
import hmac
import time
import hashlib
from typing import Tuple

class TelegramAuthError(Exception):
    pass

def _parse_init_data(init_data: str) -> dict:
    from urllib.parse import parse_qsl
    pairs = parse_qsl(init_data, keep_blank_values=True)
    data = {}
    for k, v in pairs:
        # Keep values exactly as strings (do not json.loads here)
        data[k] = v
    return data

def _data_check_string(data: dict) -> str:
    items = []
    for k in sorted(k for k in data.keys() if k != 'hash'):
        # Use the string value exactly as provided (already percent-decoded by parse_qsl)
        items.append(f"{k}={data[k]}")
    return "\n".join(items)  # FIXED: была ошибка с переносом строки

def verify_init_data(init_data: str, max_age_seconds: int = 86400) -> Tuple[int, dict]:
    if not init_data:
        raise TelegramAuthError('Missing initData')
    data = _parse_init_data(init_data)
    provided_hash = data.get('hash')
    if not provided_hash:
        raise TelegramAuthError('Missing hash in initData')

    check_string = _data_check_string(data)

    # Try multiple env vars for the bot token
    for var in ['TELEGRAM_BOT_TOKEN','BOT_TOKEN','TELEGRAM_TOKEN','TG_BOT_TOKEN']:
        token = os.getenv(var)
        if not token:
            continue
        secret_key = hashlib.sha256(token.encode()).digest()
        calc_hash = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
        if calc_hash == provided_hash:
            break
    else:
        raise TelegramAuthError('Invalid hash')

    # Expiration check (optional)
    auth_date = data.get('auth_date')
    if auth_date is not None:
        try:
            ts = int(auth_date)
            if max_age_seconds and time.time() - ts > max_age_seconds:
                raise TelegramAuthError('initData expired')
        except ValueError:
            raise TelegramAuthError('Invalid auth_date')

    # Now safely parse user JSON
    user_str = data.get('user') or ''
    try:
        user = json.loads(user_str) if user_str else {}
    except Exception:
        raise TelegramAuthError('Invalid user JSON in initData')
    user_id = user.get('id')
    if not isinstance(user_id, int) or user_id <= 0:
        raise TelegramAuthError('Invalid user.id')

    return int(user_id), data
