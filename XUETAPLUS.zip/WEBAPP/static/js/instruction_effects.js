
// ДОПОЛНИТЕЛЬНЫЕ ЭФФЕКТЫ ДЛЯ ЯНДЕКС WEBMASTER

// Добавляем специальные эффекты для WebMaster инструкции
document.addEventListener('DOMContentLoaded', function() {
    const webmasterInstruction = document.querySelector('.webmaster-instruction');
    if (webmasterInstruction) {
        
        // Создаем дополнительные плавающие частицы
        function createWebmasterParticles() {
            const particlesContainer = document.createElement('div');
            particlesContainer.className = 'webmaster-particles';
            particlesContainer.style.cssText = `
                position: absolute;
                top: 0; left: 0; right: 0; bottom: 0;
                pointer-events: none;
                overflow: hidden;
                z-index: 0;
            `;
            
            // Создаем розовые и фиолетовые частицы
            const colors = ['#FF1493', '#8A2BE2', '#FF69B4', '#9370DB'];
            
            for (let i = 0; i < 12; i++) {
                const particle = document.createElement('div');
                particle.style.cssText = `
                    position: absolute;
                    width: 3px;
                    height: 3px;
                    background: ${colors[Math.floor(Math.random() * colors.length)]};
                    border-radius: 50%;
                    opacity: 0.7;
                    left: ${Math.random() * 100}%;
                    top: ${Math.random() * 100}%;
                    animation: webmasterFloat ${3 + Math.random() * 4}s ease-in-out infinite;
                    animation-delay: ${Math.random() * 2}s;
                    box-shadow: 0 0 6px currentColor;
                `;
                particlesContainer.appendChild(particle);
            }
            
            webmasterInstruction.appendChild(particlesContainer);
        }
        
        // Добавляем CSS анимацию для частиц
        const webmasterParticleCSS = `
            @keyframes webmasterFloat {
                0%, 100% { transform: translateY(0px) rotate(0deg); opacity: 0.7; }
                25% { transform: translateY(-20px) rotate(90deg); opacity: 0.9; }
                50% { transform: translateY(-40px) rotate(180deg); opacity: 1; }
                75% { transform: translateY(-20px) rotate(270deg); opacity: 0.9; }
            }
        `;
        
        const particleStyle = document.createElement('style');
        particleStyle.textContent = webmasterParticleCSS;
        document.head.appendChild(particleStyle);
        
        createWebmasterParticles();
        
        // Добавляем интерактивность к скриншотам
        const screenshots = document.querySelectorAll('.screenshot-demo');
        screenshots.forEach(screenshot => {
            screenshot.addEventListener('click', function() {
                // Создаем модальное окно для увеличенного просмотра
                const modal = document.createElement('div');
                modal.style.cssText = `
                    position: fixed;
                    top: 0; left: 0; right: 0; bottom: 0;
                    background: rgba(0, 0, 0, 0.9);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 10000;
                    backdrop-filter: blur(10px);
                    animation: fadeIn 0.3s ease;
                `;
                
                const img = document.createElement('img');
                img.src = this.src;
                img.style.cssText = `
                    max-width: 90%;
                    max-height: 90%;
                    border-radius: 12px;
                    box-shadow: 0 20px 60px rgba(255, 20, 147, 0.4);
                `;
                
                modal.appendChild(img);
                document.body.appendChild(modal);
                
                modal.addEventListener('click', () => {
                    modal.style.animation = 'fadeOut 0.3s ease';
                    setTimeout(() => modal.remove(), 300);
                });
                
                // Добавляем CSS для анимаций модалки
                if (!document.getElementById('modalAnimations')) {
                    const modalStyle = document.createElement('style');
                    modalStyle.id = 'modalAnimations';
                    modalStyle.textContent = `
                        @keyframes fadeIn {
                            from { opacity: 0; }
                            to { opacity: 1; }
                        }
                        @keyframes fadeOut {
                            from { opacity: 1; }
                            to { opacity: 0; }
                        }
                    `;
                    document.head.appendChild(modalStyle);
                }
            });
        });
    }
});
