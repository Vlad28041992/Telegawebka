
// Файл намеренно оставлен пустым - звуки и загрузки отключены
// All transitions, sounds and loading screens disabled
