
import os
import json
import hmac
import time
import hashlib
from typing import Tuple

class TelegramAuthError(Exception):
    pass

def _parse_init_data(init_data: str) -> dict:
    from urllib.parse import parse_qsl
    pairs = parse_qsl(init_data, keep_blank_values=True)
    data = {}
    for k, v in pairs:
        if k == 'user':
            try:
                data[k] = json.loads(v)
            except Exception:
                raise TelegramAuthError('Invalid user JSON in initData')
        else:
            data[k] = v
    return data

def _data_check_string(data: dict) -> str:
    items = []
    for k in sorted(k for k in data.keys() if k != 'hash'):
        v = data[k]
        if isinstance(v, (dict, list)):
            v = json.dumps(v, separators=(',', ':'), ensure_ascii=False)
        items.append(f"{k}={v}")
    return '\n'.join(items)

def verify_init_data(init_data: str, max_age_seconds: int = 86400) -> Tuple[int, dict]:
    if not init_data:
        raise TelegramAuthError('Missing initData')
    data = _parse_init_data(init_data)
    provided_hash = data.get('hash')
    if not provided_hash:
        raise TelegramAuthError('Missing hash in initData')
    bot_token = os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('BOT_TOKEN')
    if not bot_token:
        raise TelegramAuthError('BOT_TOKEN env is not set')
    secret_key = hashlib.sha256(bot_token.encode()).digest()
    check_string = _data_check_string(data)
    calc_hash = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    if calc_hash != provided_hash:
        raise TelegramAuthError('Invalid hash')
    auth_date = data.get('auth_date')
    if auth_date is not None:
        try:
            auth_ts = int(auth_date)
            if max_age_seconds and time.time() - auth_ts > max_age_seconds:
                raise TelegramAuthError('initData expired')
        except ValueError:
            raise TelegramAuthError('Invalid auth_date')
    user = data.get('user') or {}
    user_id = user.get('id')
    if not isinstance(user_id, int):
        raise TelegramAuthError('Invalid user.id')
    return user_id, data
