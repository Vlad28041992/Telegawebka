"""
ИСПРАВЛЕННЫЕ МОДЕЛИ для WebApp
Приведено в соответствие с реальной структурой БД
"""
from extensions import db
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy.orm import synonym

class User(db.Model):
    __tablename__ = 'users'
    
    # важное: в реальной БД PK — user_id, а id просто уникальный int
    user_id = db.Column(db.BigInteger, primary_key=True)
    id = db.Column(db.Integer, unique=True, nullable=False)

    username = db.Column(db.Text)
    full_name = db.Column(db.Text)

    # деньги и очки — как в боте/админке
    balance = db.Column(db.Integer, default=0)
    total_earnings = db.Column(db.Integer, default=0)
    earnings_from_tasks = db.Column(db.Integer, default=0)

    # рефералка — две колонки
    referral_earnings_1 = db.Column(db.Numeric(10, 2), default=0)
    referral_earnings_2 = db.Column(db.Numeric(10, 2), default=0)

    # активности/статусы
    is_active = db.Column(db.Boolean, default=True)
    is_banned = db.Column(db.Boolean, default=False)

    # разные служебные поля из бота (могут быть NULL в БД)
    referrer_id = db.Column(db.BigInteger)
    last_activity = db.Column(db.DateTime)
    registration_date = db.Column(db.DateTime)
    last_login_date = db.Column(db.Text)
    login_streak = db.Column(db.Integer, default=0)
    points = db.Column(db.Integer, default=0)
    weekly_points = db.Column(db.Integer, default=0)
    total_points = db.Column(db.Integer, default=0)
    referral_1_level = db.Column(db.Integer, default=0)
    referral_2_level = db.Column(db.Integer, default=0)
    referrals_level_1 = db.Column(db.Integer, default=0)
    referrals_level_2 = db.Column(db.Integer, default=0)
    role = db.Column(db.String(50), default='user')
    created_at = db.Column(db.DateTime)
    email = db.Column(db.String(120), default='')
    assigned_task_id = db.Column(db.Integer)
    assigned_task_time = db.Column(db.BigInteger)
    earnings_from_referrals = db.Column(db.Integer, default=0)

    @property
    def referral_earnings(self):
        try:
            v1 = float(self.referral_earnings_1 or 0)
            v2 = float(self.referral_earnings_2 or 0)
            return v1 + v2
        except Exception:
            return 0.0

    @staticmethod
    def get_or_create_user(telegram_user_id, full_name='', username=''):
        """
        ИСПРАВЛЕННЫЙ МЕТОД: Безопасное создание/получение пользователя
        Обрабатывает конфликт между user_id (BIGINT) и id (INTEGER)
        """
        try:
            # Ищем существующего пользователя
            user = User.query.filter_by(user_id=telegram_user_id).first()
            if user:
                return user, False
            
            # Создаем нового пользователя
            from extensions import db
            max_id = db.session.query(db.func.max(User.id)).scalar() or 0
            
            new_user = User(
                user_id=telegram_user_id,  # BIGINT - Telegram ID  
                id=max_id + 1,            # INTEGER - автоинкремент
                username=username or '',
                full_name=full_name or '',
                email=f"user_{telegram_user_id}@temp.email",  # ИСПРАВЛЕНО: добавлено поле email
                balance=0,
                is_active=True,
                created_at=datetime.utcnow(),
                registration_date=datetime.utcnow(),
                total_earnings=0,
                earnings_from_tasks=0,
                points=0,
                weekly_points=0,
                total_points=0
            )
            
            db.session.add(new_user)
            db.session.flush()  # Получаем ID без коммита
            return new_user, True
            
        except Exception as e:
            db.session.rollback()
            print(f'Error in get_or_create_user: {e}')
            raise e

class AdminUser(UserMixin, db.Model):
    """ПРАВИЛЬНАЯ модель администратора для WebApp"""
    __tablename__ = 'admin_users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='admin')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)

    def set_password(self, password):
        from werkzeug.security import generate_password_hash
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        from werkzeug.security import check_password_hash
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return str(self.id)

class Task(db.Model):
    """Модель задания - ИСПРАВЛЕНА под реальную структуру БД"""
    __tablename__ = 'tasks'
    
    # Основные поля из БД
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    platform = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text, nullable=False)
    city = db.Column(db.Text)
    direction = db.Column(db.Text)
    category = db.Column(db.String(100))
    
    # Награды
    reward_money = db.Column(db.Numeric(10, 2))
    reward_points = db.Column(db.Integer)
    price = db.Column(db.Float)  # double precision в БД
    
    # Ограничения и настройки
    submission_limit = db.Column(db.Integer)
    is_active = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(50), default='active')
    priority = db.Column(db.Integer)
    
    # Ссылки и инструкции
    task_url = db.Column(db.String(255))
    instruction_link = db.Column(db.Text)
    
    # Даты
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    
    @property
    def reward(self):
        """Свойство для обратной совместимости со старым кодом"""
        return self.reward_money or self.price or 0
    
    @property
    def max_submissions(self):
        """Алиас для submission_limit"""
        return self.submission_limit or 1
    
    @property
    def current_submissions(self):
        """Подсчет текущих выполнений через submissions"""
        return Submission.query.filter_by(task_id=self.id).count()

    # Review texts linked to this task
    review_texts = db.relationship("TaskReviewText", backref="task", lazy="dynamic")

class Subtask(db.Model):
    __tablename__ = 'subtasks'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    points_value = db.Column(db.Integer, default=1)  # правильное имя поля из БД
    is_required = db.Column(db.Boolean, default=True)
    is_completed = db.Column(db.Boolean, default=False)

class Submission(db.Model):
    """
    ИСПРАВЛЕННАЯ МОДЕЛЬ submissions
    ВАЖНО: user_id должен быть BIGINT для совместимости с Telegram ID
    """
    __tablename__ = 'submissions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False)  # ИСПРАВЛЕНО: BIGINT вместо Integer
    user_id_bi = db.Column(db.BigInteger, nullable=False)  # ОБЯЗАТЕЛЬНОЕ ПОЛЕ ДЛЯ БД
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    
    fio = db.Column(db.String(255))
    full_name = db.Column(db.String(255))
    screenshot_url = db.Column(db.String(500))
    screenshot_file_id = db.Column(db.String(255))
    
    # Поля для Авито - второй скрин (финальный отзыв)
    review_screenshot_url = db.Column(db.String(500))  # Скрин отзыва (финальный)
    review_screenshot_file_id = db.Column(db.String(255))
    
    notes = db.Column(db.Text)
    description = db.Column(db.Text)
    
    status = db.Column(db.String(50), default='pending')
    
    # Время создания и отправки
    submission_time = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    submitted_at = db.Column(db.DateTime)
    approved_at = db.Column(db.DateTime)
    
    # Проверка
    review_time = db.Column(db.DateTime)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('admin_users.id'))
    rejection_reason = db.Column(db.Text)
    admin_comment = db.Column(db.Text)
    
    # Связи
    task = db.relationship('Task', backref='submissions_rel')
    
    
    # ===== ПОЛЯ ДЛЯ АВИТО =====
    # Статус Авито задания
    avito_status = db.Column(db.String(50))  # 'waiting_chat_screenshot', 'waiting_report', 'ready_to_submit'
    
    # Время взятия задания (для отсчета 2 часов на скрин)
    task_taken_at = db.Column(db.DateTime)
    
    # Скриншот переписки (1-й скрин)
    chat_screenshot_url = db.Column(db.String(500))
    chat_screenshot_file_id = db.Column(db.String(255))
    chat_screenshot_uploaded_at = db.Column(db.DateTime)
    chat_screenshot_verified = db.Column(db.Boolean, default=False)
    
    # Время когда можно отправить отчет (24 часа после взятия)
    report_available_at = db.Column(db.DateTime)
    
    
    reviewer = db.relationship('AdminUser', foreign_keys=[reviewer_id])
class Achievement(db.Model):
    __tablename__ = 'achievements'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    required_tasks = db.Column(db.Integer, nullable=False)
    reward_points = db.Column(db.Integer)
    reward_money = db.Column(db.Numeric(10, 2))
    icon = db.Column(db.String(255))
    points_required = db.Column(db.Integer)
    tasks_required = db.Column(db.Integer)

class UserAchievement(db.Model):
    __tablename__ = 'user_achievements'
    
    user_id = db.Column(db.Integer, primary_key=True)
    achievement_id = db.Column(db.Integer, primary_key=True)
    awarded_at = db.Column(db.BigInteger)

# Дополнительные модели из БД
class Platform(db.Model):
    __tablename__ = 'platforms'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    base_reward = db.Column(db.Float)
    is_active = db.Column(db.Boolean, default=True)

class Payouts(db.Model):
    __tablename__ = 'payouts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default='pending')
    method = db.Column(db.String(100))
    details = db.Column(db.Text)
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime)
    processed_by = db.Column(db.Integer)
    admin_comment = db.Column(db.Text)

class AdminLogs(db.Model):
    __tablename__ = 'admin_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, nullable=False)
    action = db.Column(db.String(200), nullable=False)
    target_type = db.Column(db.String(100))
    target_id = db.Column(db.Integer)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class TaskReviewText(db.Model):
    __tablename__ = "task_review_texts"
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey("tasks.id"), nullable=False)
    text = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default="free")  # free|assigned|used
    assigned_user_id = db.Column(db.BigInteger)
    assigned_at = db.Column(db.DateTime)
    used_submission_id = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    gender = db.Column(db.String(20), default="neutral")  # male|female|neutral

class UserTaskLimit(db.Model):
    """Модель для отслеживания выполненных заданий по дням и платформам"""
    __tablename__ = 'user_task_limits'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False, index=True)
    platform = db.Column(db.String(100), nullable=False, index=True)
    date = db.Column(db.Date, nullable=False, index=True)
    tasks_completed = db.Column(db.Integer, default=0)
    last_task_time = db.Column(db.DateTime)  # НОВОЕ: время последнего выполненного задания
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Уникальный индекс для пользователя, платформы и даты
    __table_args__ = (
        db.UniqueConstraint('user_id', 'platform', 'date', name='unique_user_platform_date'),
    )
    
    @staticmethod
    def get_user_tasks_today(user_id, platform):
        """Получить количество выполненных заданий сегодня для платформы"""
        today = datetime.now().date()
        limit_record = UserTaskLimit.query.filter_by(
            user_id=user_id,
            platform=platform,
            date=today
        ).first()
        return limit_record.tasks_completed if limit_record else 0
    
    @staticmethod
    def get_last_task_time(user_id, platform):
        """Получить время последнего выполненного задания для платформы"""
        # Ищем последнюю запись для пользователя и платформы
        limit_record = UserTaskLimit.query.filter_by(
            user_id=user_id,
            platform=platform
        ).order_by(UserTaskLimit.last_task_time.desc()).first()
        
        return limit_record.last_task_time if limit_record and limit_record.last_task_time else None
    
    @staticmethod
    def increment_user_tasks(user_id, platform):
        """Увеличить счетчик выполненных заданий на 1"""
        today = datetime.now().date()
        current_time = datetime.utcnow()
        
        limit_record = UserTaskLimit.query.filter_by(
            user_id=user_id,
            platform=platform,
            date=today
        ).first()
        
        if limit_record:
            limit_record.tasks_completed += 1
            limit_record.updated_at = current_time
            limit_record.last_task_time = current_time  # НОВОЕ: обновляем время последнего задания
        else:
            limit_record = UserTaskLimit(
                user_id=user_id,
                platform=platform,
                date=today,
                tasks_completed=1,
                last_task_time=current_time  # НОВОЕ: сохраняем время первого задания
            )
            db.session.add(limit_record)
        
        db.session.commit()
        return limit_record.tasks_completed
    
    @staticmethod
    def can_take_task(user_id, platform, daily_limit=5):
        """Проверить, может ли пользователь взять еще задание на платформе"""
        tasks_today = UserTaskLimit.get_user_tasks_today(user_id, platform)
        return tasks_today < daily_limit

class UserBan(db.Model):
    """Модель для управления банами пользователей"""
    __tablename__ = 'user_bans'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False, index=True)
    reason = db.Column(db.Text, nullable=False)  # ИСПРАВЛЕНО: было ban_reason
    duration = db.Column(db.Integer)  # ИСПРАВЛЕНО: было ban_duration - длительность в минутах
    banned_at = db.Column(db.DateTime, default=datetime.utcnow)
    banned_until = db.Column(db.DateTime)  # NULL = перманентный бан
    banned_by = db.Column(db.String(100))  # Кто забанил
    is_active = db.Column(db.Boolean, default=True)
    is_permanent = db.Column(db.Boolean, default=False)
    
    # Типы банов
    is_app_banned = db.Column(db.Boolean, default=True, nullable=False)
    is_bot_banned = db.Column(db.Boolean, default=False, nullable=False)
    
    unbanned_at = db.Column(db.DateTime)
    unbanned_by = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<UserBan user_id={self.user_id} active={self.is_active}>'
    
    @staticmethod
    def is_user_banned(user_id):
        """Проверяет, забанен ли пользователь"""
        from datetime import datetime
        
        # Ищем активный бан
        active_ban = UserBan.query.filter_by(
            user_id=user_id, 
            is_active=True
        ).first()
        
        if not active_ban:
            return False, None
        
        # Проверяем, не истек ли временный бан
        if active_ban.banned_until:
            if datetime.utcnow() > active_ban.banned_until:
                # Бан истек - деактивируем
                active_ban.is_active = False
                
                # Обновляем пользователя
                user = User.query.filter_by(user_id=user_id).first()
                if user:
                    user.is_banned = False
            # user.ban_reason = None # УДАЛЕНО: колонки ban_reason нет в таблице users
                    user.banned_until = None
                
                try:
                    db.session.commit()
                except:
                    db.session.rollback()
                
                return False, None
        
        return True, active_ban
    
    @staticmethod
    def ban_user(user_id, reason, duration_minutes=None, banned_by='admin'):
        """Банит пользователя"""
        from datetime import datetime, timedelta
        
        # Деактивируем все старые баны
        old_bans = UserBan.query.filter_by(user_id=user_id, is_active=True).all()
        for ban in old_bans:
            ban.is_active = False
        
        # Создаем новый бан
        banned_until = None
        if duration_minutes:
            banned_until = datetime.utcnow() + timedelta(minutes=duration_minutes)
        
        new_ban = UserBan(
            user_id=user_id,
            ban_reason=reason,
            ban_duration=duration_minutes,
            banned_until=banned_until,
            banned_by=banned_by,
            is_active=True
        )
        
        db.session.add(new_ban)
        
        # Обновляем таблицу users
        user = User.query.filter_by(user_id=user_id).first()
        if user:
            user.is_banned = True
            # user.ban_reason = reason # УДАЛЕНО: колонки ban_reason нет в таблице users
            user.banned_until = banned_until
        
        try:
            db.session.commit()
            return True, new_ban
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    
    @staticmethod
    def unban_user(user_id, unbanned_by='admin'):
        """Разбанивает пользователя"""
        from datetime import datetime
        
        # Деактивируем все активные баны
        active_bans = UserBan.query.filter_by(user_id=user_id, is_active=True).all()
        
        for ban in active_bans:
            ban.is_active = False
            ban.unbanned_at = datetime.utcnow()
            ban.unbanned_by = unbanned_by
        
        # Обновляем таблицу users
        user = User.query.filter_by(user_id=user_id).first()
        if user:
            user.is_banned = False
            # user.ban_reason = None # УДАЛЕНО: колонки ban_reason нет в таблице users
            user.banned_until = None
        
        try:
            db.session.commit()
            return True, 'User unbanned successfully'
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    
    def get_ban_info(self):
        """Возвращает информацию о бане для отображения"""
        from datetime import datetime
        
        info = {
            'user_id': self.user_id,
            'ban_reason': self.ban_reason,
            'banned_at': self.banned_at.strftime('%d.%m.%Y %H:%M') if self.banned_at else None,
            'is_permanent': self.banned_until is None,
        }
        
        if self.banned_until:
            info['banned_until'] = self.banned_until.strftime('%d.%m.%Y %H:%M')
            
            # Вычисляем оставшееся время
            time_left = self.banned_until - datetime.utcnow()
            if time_left.total_seconds() > 0:
                days = time_left.days
                hours = time_left.seconds // 3600
                minutes = (time_left.seconds % 3600) // 60
                
                duration_parts = []
                if days > 0:
                    duration_parts.append(f'{days} дн.')
                if hours > 0:
                    duration_parts.append(f'{hours} ч.')
                if minutes > 0:
                    duration_parts.append(f'{minutes} мин.')
                
                info['ban_duration'] = ' '.join(duration_parts) if duration_parts else 'менее минуты'
            else:
                info['ban_duration'] = 'Истек'
        else:
            info['banned_until'] = None
            info['ban_duration'] = None
        
        return info


class YandexMapsRejection(db.Model):
    """Модель для отслеживания отклонений заданий Яндекс Карт и автобана"""
    __tablename__ = 'yandex_maps_rejections'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False, index=True)
    submission_id = db.Column(db.Integer, db.ForeignKey('submissions.id'), nullable=False)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'))
    rejected_at = db.Column(db.DateTime, default=datetime.utcnow)
    rejection_reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Связи
    submission = db.relationship('Submission', backref='yandex_rejection')
    
    def __repr__(self):
        return f'<YandexMapsRejection user_id={self.user_id} submission_id={self.submission_id}>'
    
    @staticmethod
    def check_and_autoban(user_id):
        """
        Проверяет количество отклоненных заданий Яндекс Карт для пользователя.
        Если >= 5 отклонений - автоматически банит на 2 недели.
        Возвращает: (is_banned: bool, rejection_count: int, ban_info: UserBan or None)
        """
        from datetime import datetime, timedelta
        
        # Считаем количество отклонений
        rejection_count = YandexMapsRejection.query.filter_by(user_id=user_id).count()
        
        # Если 5 или больше отклонений - выдаем автобан
        if rejection_count >= 5:
            # Проверяем, нет ли уже активного автобана для Яндекс Карт
            existing_ban = UserBan.query.filter_by(
                user_id=user_id,
                is_active=True,
                banned_by='autoban_yandex'
            ).first()
            
            if not existing_ban:
                # Создаем автобан на 2 недели (20160 минут)
                ban_reason = f'Автоматическая блокировка: {rejection_count} отклонений заданий Яндекс Карт'
                duration_minutes = 14 * 24 * 60  # 2 недели в минутах
                
                success, ban_info = UserBan.ban_user(
                    user_id=user_id,
                    reason=ban_reason,
                    duration_minutes=duration_minutes,
                    banned_by='autoban_yandex'
                )
                
                if success:
                    return True, rejection_count, ban_info
                else:
                    return False, rejection_count, None
            else:
                return True, rejection_count, existing_ban
        
        return False, rejection_count, None
    
    @staticmethod
    def add_rejection(user_id, submission_id, task_id=None, rejection_reason=None):
        """
        Добавляет запись об отклонении задания Яндекс Карт.
        Автоматически проверяет и применяет бан если нужно.
        """
        try:
            # Проверяем, нет ли уже записи для этого submission
            existing = YandexMapsRejection.query.filter_by(submission_id=submission_id).first()
            if existing:
                return False, 'Rejection already recorded', None
            
            # Создаем новую запись
            rejection = YandexMapsRejection(
                user_id=user_id,
                submission_id=submission_id,
                task_id=task_id,
                rejection_reason=rejection_reason
            )
            db.session.add(rejection)
            db.session.commit()
            
            # Проверяем и применяем автобан если нужно
            is_banned, count, ban_info = YandexMapsRejection.check_and_autoban(user_id)
            
            return True, f'Rejection recorded (total: {count})', ban_info
            
        except Exception as e:
            db.session.rollback()
            return False, f'Error: {str(e)}', None
    
    @staticmethod
    def get_rejection_count(user_id):
        """Возвращает количество отклонений для пользователя"""
        return YandexMapsRejection.query.filter_by(user_id=user_id).count()
    
    @staticmethod
    def reset_rejections(user_id):
        """Сбрасывает счетчик отклонений (например, при разбане)"""
        try:
            YandexMapsRejection.query.filter_by(user_id=user_id).delete()
            db.session.commit()
            return True, 'Rejections reset'
        except Exception as e:
            db.session.rollback()
            return False, f'Error: {str(e)}'




class Assignment(db.Model):
    """Модель для отслеживания взятых заданий пользователями"""
    __tablename__ = 'assignments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    task = db.relationship('Task', backref='assignments')
    
    def __repr__(self):
        return f'<Assignment user_id={self.user_id} task_id={self.task_id}>'


class AvitoSubmission(db.Model):
    """Модель для отслеживания статуса заданий Avito"""
    __tablename__ = 'avito_submissions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id'), nullable=False)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    submission_id = db.Column(db.Integer, db.ForeignKey('submissions.id'), nullable=True)
    
    # Временные метки
    started_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    chat_screenshot_uploaded_at = db.Column(db.DateTime, nullable=True)
    report_available_at = db.Column(db.DateTime, nullable=True)  # Когда можно отправить отчет (через 24 часа)
    
    # Статусы
    chat_screenshot_path = db.Column(db.String(500), nullable=True)
    is_expired = db.Column(db.Boolean, default=False)  # Истек ли 2-часовой таймер
    report_submitted = db.Column(db.Boolean, default=False)
    
    # Связи
    user = db.relationship('User', backref='avito_submissions')
    task = db.relationship('Task', backref='avito_submissions')
    submission = db.relationship('Submission', backref='avito_submission', uselist=False)
    
    def __repr__(self):
        return f'<AvitoSubmission user_id={self.user_id} task_id={self.task_id}>'
