import os
import uuid
import requests
from flask import send_from_directory, Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_migrate import Migrate, upgrade
from datetime import datetime
from config import Config
from werkzeug.utils import secure_filename
from sqlalchemy.exc import IntegrityError

from flask_admin import Admin
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db
from models import User, Task, Subtask, Submission, Achievement, UserAchievement, AdminUser, Platform, Payouts
from admin_views import init_admin_views


from datetime import timedelta

ASSIGN_TTL_MIN = 120

from sqlalchemy import text as _sqltext

def get_or_assign_review_text(task_id: int, user_id: int):
    """Атомарное резервирование текста отзыва.
    1) Если пользователю уже назначен текст по этой задаче (assigned/used) — вернуть его.
    2) Иначе — попытаться атомарно взять первый свободный (free) текст с блокировкой SKIP LOCKED.
    Возвращает ORM-объект TaskReviewText или None.
    """
    from models import TaskReviewText
    try:
        # 1) Уже назначенный этому пользователю
        exist = TaskReviewText.query \
            .filter_by(task_id=task_id, assigned_user_id=user_id) \
            .filter(TaskReviewText.status.in_(['assigned','used'])) \
            .order_by(TaskReviewText.id.asc()).first()
        if exist:
            return exist

        # 2) Атомарная попытка взять свободную строку
        # Используем один UPDATE ... WHERE id IN (SELECT ... FOR UPDATE SKIP LOCKED LIMIT 1) RETURNING *
        sql = _sqltext("""
            WITH picked AS (
                SELECT t1.id FROM task_review_texts t1
                WHERE t1.task_id = :task_id AND t1.status = 'free'
                  AND NOT EXISTS (
                      SELECT 1 FROM task_review_texts t2
                      WHERE t2.task_id = t1.task_id
                        AND lower(trim(t2.text)) = lower(trim(t1.text))
                        AND t2.status IN ('assigned','used')
                  )
                ORDER BY t1.id ASC
                FOR UPDATE SKIP LOCKED
                LIMIT 1
            )
            UPDATE task_review_texts t
            SET status = 'assigned', assigned_user_id = :user_id, assigned_at = NOW()
            FROM picked
            WHERE t.id = picked.id
            RETURNING t.id, t.task_id, t.text, t.status, t.assigned_user_id, t.assigned_at, t.used_submission_id, t.created_at
        """)
        res = db.session.execute(sql, {'task_id': task_id, 'user_id': user_id})
        row = res.fetchone()
        if not row:
            return None
        # Вернем ORM-объект
        return TaskReviewText.query.get(row.id)
    except Exception as e:
        try:
            db.session.rollback()
        except Exception:
            pass
        print('assign review text error (atomic):', e)
        return None

app = Flask(__name__)
app.url_map.strict_slashes = False
app.config.from_object(Config)

db.init_app(app)
migrate = Migrate(app, db)


with app.app_context():
    try:
        from sqlalchemy import text as _sqltext
        db.session.execute(_sqltext("""
        CREATE TABLE IF NOT EXISTS task_review_texts (
            id SERIAL PRIMARY KEY,
            task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
            text TEXT NOT NULL,
            status VARCHAR(20) DEFAULT 'free',
            assigned_user_id BIGINT,
            assigned_at TIMESTAMP,
            used_submission_id INTEGER,
            created_at TIMESTAMP DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_trt_task_status ON task_review_texts(task_id, status);
        """))
        db.session.commit()
    except Exception as _e:
        print('init task_review_texts error:', _e)



@app.before_request
def load_tg_user_id():
    try:
        # Keep existing session user_id if already set
        if isinstance(session.get('user_id'), int):
            return
        # Accept Telegram WebApp initData from query/header/form
        init_data = request.args.get('tgWebAppData') or request.args.get('initData') or request.headers.get('X-Telegram-Init-Data')
        if not init_data and request.method == 'POST':
            init_data = (request.form.get('tgWebAppData') or request.form.get('initData'))
        if init_data:
            try:
                from telegram_auth import verify_init_data
                uid, _ = verify_init_data(init_data, max_age_seconds=86400)
                if isinstance(uid, int):
                    session['user_id'] = uid
                    return
            except Exception as _e:
                # Invalid/expired initData — ignore, do not set user
                pass
        # Dev fallback: allow insecure query param only if explicitly enabled
        if os.getenv('ALLOW_INSECURE_QUERY_USER_ID', 'false').lower() == 'true':
            uid = (request.args.get('user_id') or request.form.get('user_id') or '').strip()
            if uid.isdigit():
                session['user_id'] = int(uid)
    except Exception:
        pass
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# URLs других приложений
BOT_API_URL = os.getenv("BOT_API_URL", "https://bot-angel2804.amvera.io")
ADMIN_PANEL_URL = os.getenv("ADMIN_PANEL_URL", "https://adminpanelseoserm-angel2804.amvera.io")

# Создаем Flask-Admin объект

# === Utilities ===
def has_user_submitted(user_id: int, task_id: int) -> bool:
    try:
        if not user_id:
            return False
        from models import Submission
        return Submission.query.filter_by(user_id=user_id, task_id=task_id).first() is not None
    except Exception:
        return False
    
admin = Admin(app, name='Admin Panel', template_mode='bootstrap3')

# Настройка LoginManager для админки
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'admin_login'
login_manager.login_message = "Пожалуйста, войдите для доступа к админ панели"

@login_manager.user_loader
def load_user(user_id):
    return AdminUser.query.get(int(user_id))

# Маппинг платформ
PLATFORM_MAPPING = {
    'yandex-maps': 'Яндекс Карты',
    'google-maps': 'Google Карты',
    '2gis': '2ГИС', 
    'avito': 'Авито',
    'yandex-webmaster': 'Яндекс Браузер'
}


# === РОУТ ДЛЯ РАЗДАЧИ ЗАГРУЖЕННЫХ ФАЙЛОВ ===
@app.route('/static/uploads/<filename>')
def serve_uploaded_file(filename):
    """Раздает загруженные пользователями файлы"""
    try:
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    except Exception as e:
        print(f"Error serving uploaded file {filename}: {e}")
        return '', 404


# === ОСНОВНЫЕ РОУТЫ ===

@app.route('/')
def user_agreement():
    """Главная страница - пользовательское соглашение"""
    user_id = session.get('user_id')
    return render_template('user_agreement.html', user_id=user_id)

@app.route('/services')
def services_menu():
    """Меню выбора услуг"""
    user_id = session.get('user_id')
    return render_template('services_menu.html', user_id=user_id)

@app.route('/categories')
def categories():
    """Показать категории заданий (перенаправляет на services)"""
    user_id = session.get('user_id')
    return redirect(url_for('services_menu', user_id=user_id))

# ЗАДАНИЯ ПО ПЛАТФОРМЕ
@app.route('/platform/<platform_key>')
def platform_tasks(platform_key):
    """Показать задания для конкретной платформы - ИСПРАВЛЕНО"""
    user_id = session.get('user_id')
    
    if platform_key not in PLATFORM_MAPPING:
        flash('Неизвестная платформа!', 'danger')
        return redirect(url_for('services_menu', user_id=user_id))
    
    platform_name = PLATFORM_MAPPING[platform_key]
    
    # ИСПРАВЛЕННЫЙ запрос без current_submissions
    tasks_all = Task.query.filter_by(platform=platform_name, status='active').all()
    tasks = []
    for t in tasks_all:
        try:
            if t.submission_limit and t.current_submissions >= t.submission_limit:
                continue
        except Exception:
            pass
        try:
            if has_user_submitted(int(user_id) if user_id else None, t.id):
                continue
        except Exception:
            pass
        tasks.append(t)
    
    return render_template('platform.html', 
                         platform_key=platform_key,
                         platform_name=platform_name, 
                         tasks=tasks,
                         user_id=user_id)

@app.route('/category/<category_name>')
def show_category_tasks(category_name):
    """Показать задания по категории"""
    user_id = session.get('user_id')
    
    # Фильтруем задания по категории
    tasks = Task.query.filter_by(category=category_name, status='active').all()
    
    return render_template('category.html',
                         category_name=category_name,
                         tasks=tasks,
                         user_id=user_id)


@app.route('/perform_task/<int:task_id>', methods=['GET','POST'])
def perform_task(task_id):
    """Страница выполнения задания (без редиректа на GET, user_id только из session/initData)"""
    task = Task.query.get_or_404(task_id)
    sess_uid = session.get('user_id')
    uid = int(sess_uid) if isinstance(sess_uid, int) or (isinstance(sess_uid, str) and sess_uid.isdigit()) else None

    # TTL cleanup and try to reserve review text only when user known
    release_stale_assigned_texts()
    assigned_review = get_or_assign_review_text(task_id, uid) if uid else None

    reverse_map = {v: k for k, v in PLATFORM_MAPPING.items()}
    platform_key = reverse_map.get(task.platform, 'yandex-maps')
    subtasks = Subtask.query.filter_by(task_id=task_id).all()

    if request.method == 'POST':
        if not uid:
            flash('Откройте задание из Telegram-бота, чтобы отправить отчет.', 'danger')
            return redirect(request.url)
        fio = (request.form.get('fio') or '').strip()
        notes = (request.form.get('notes') or '').strip()
        file = request.files.get('screenshot')
        if not fio or not file:
            flash('Пожалуйста, заполните все обязательные поля', 'danger')
            return redirect(request.url)

        # Duplicate guard
        try:
            from models import Submission as _SubmissionCheck
            if _SubmissionCheck.query.filter_by(user_id=uid, task_id=task.id).first():
                flash('Вы уже выполняли это задание. Доступно одно выполнение на пользователя.', 'warning')
                return redirect(url_for('task_submitted', task_id=task.id))
        except Exception:
            pass

        # Task limit guard
        try:
            if task.submission_limit and task.current_submissions >= task.submission_limit:
                flash('Лимит выполнений для этого задания достигнут. Выберите другое задание.', 'warning')
                return redirect(url_for('platform_tasks', platform_key=platform_key))
        except Exception:
            pass

        # Ensure user exists
        try:
            user_obj, created = User.get_or_create_user(uid, fio)
            if created:
                db.session.commit()
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка создания пользователя: {e}', 'danger')
            return redirect(request.url)

        # Save file
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        filename = secure_filename(f"{uuid.uuid4().hex}_" + (file.filename or 'screenshot.png'))
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        submission = Submission(
            user_id=uid,
            task_id=task.id,
            fio=fio,
            full_name=fio,
            notes=notes,
            description=(assigned_review.text if assigned_review else (notes or '')),
            screenshot_url=filename,
            status='pending',
            submission_time=datetime.utcnow(),
            submitted_at=datetime.utcnow()
        )
        try:
            db.session.add(submission)
            db.session.commit()
            if assigned_review:
                mark_review_text_as_used(task.id, uid, submission.id)
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка сохранения заявки: {e}', 'danger')
            return redirect(request.url)

        # Notifications best-effort
        try:
            from integration_api import notify_admin_new_submission, notify_bot_submission_sent
            notify_admin_new_submission({
                'submission_id': submission.id,
                'user_id': submission.user_id,
                'task_id': submission.task_id,
                'task_title': task.title,
                'status': submission.status,
                'time': submission.submission_time.isoformat() if submission.submission_time else None
            })
            if submission.user_id:
                notify_bot_submission_sent(submission.user_id, task.title, submission.id, task.platform)
        except Exception:
            pass

        return redirect(url_for('task_submitted', task_id=task.id))

    # If user known and no free review texts right now — go back to platform list
    if uid and not assigned_review:
        flash('Для этого задания сейчас нет свободных текстов отзыва. Попробуйте позже.', 'warning')
        return redirect(url_for('platform_tasks', platform_key=platform_key))

    # GET: show page. If uid unknown, submission button still visible per design, but POST will be blocked
    return render_template('perform_task.html', task=task, subtasks=subtasks, user_id=session.get('user_id'), assigned_review_text=(assigned_review.text if assigned_review else None))


@app.route('/task/<int:task_id>')
def task_detail(task_id):
    """Детальная страница задания"""
    user_id = session.get('user_id')
    task = Task.query.get_or_404(task_id)
    assigned_review = None
    try:
        _pre_uid = request.args.get("user_id") or session.get("user_id")
        if _pre_uid and str(_pre_uid).isdigit():
            assigned_review = get_or_assign_review_text(task_id, int(_pre_uid))
    except Exception as _e:
        assigned_review = None
    # compute platform_key for back link
    reverse_map = {v:k for k,v in PLATFORM_MAPPING.items()}
    platform_key = reverse_map.get(task.platform, 'yandex-maps')
    subtasks = Subtask.query.filter_by(task_id=task_id).all()
    # Prevent duplicate execution
    if user_id and has_user_submitted(int(user_id), task_id):
        flash('Вы уже выполняли это задание. Доступно только одно выполнение на пользователя.', 'warning')
        return redirect(url_for('task_submitted', task_id=task_id, user_id=user_id))
    
    return render_template('task_detail.html',
                         task=task,
                         subtasks=subtasks,
                         platform_key=platform_key,
                         user_id=user_id)

@app.route('/task_submitted/<int:task_id>')
def task_submitted(task_id):
    """Страница подтверждения отправки задания"""
    user_id = session.get('user_id')
    task = Task.query.get_or_404(task_id)
    assigned_review = None
    try:
        _pre_uid = request.args.get("user_id") or session.get("user_id")
        if _pre_uid and str(_pre_uid).isdigit():
            assigned_review = get_or_assign_review_text(task_id, int(_pre_uid))
    except Exception as _e:
        assigned_review = None
    # compute platform_key for back link
    reverse_map = {v:k for k,v in PLATFORM_MAPPING.items()}
    platform_key = reverse_map.get(task.platform, 'yandex-maps')
    
    return render_template('task_submitted.html', 
                         task=task, 
                         user_id=user_id)

# === API РОУТЫ ===

@app.route('/api/update_submission_status', methods=['POST'])
def update_submission_status_api():
    """API для обновления статуса отзыва"""
    try:
        data = request.json
        submission_id = data.get('submission_id')
        new_status = data.get('status')
        admin_comment = data.get('admin_comment', '')
        
        submission = Submission.query.get(submission_id)
        if not submission:
            return jsonify({'error': 'Отзыв не найден'}), 404
        
        submission.status = new_status
        submission.admin_comment = admin_comment
        submission.review_time = datetime.utcnow()
        
        if new_status == 'approved':
            submission.approved_at = datetime.utcnow()
        
        
        db.session.commit()
        # Mark assigned review text as used (API)
        try:
            from models import TaskReviewText as _TRT
            _uid = data.get('user_id')
            _task_id = data.get('task_id')
            if _uid and _task_id:
                _assigned = _TRT.query                     .filter_by(task_id=_task_id, assigned_user_id=_uid)                     .filter(_TRT.status.in_(['assigned']))                     .order_by(_TRT.id.asc()).first()
                if _assigned:
                    _assigned.status = 'used'
                    _assigned.used_submission_id = submission.id
                    db.session.commit()
        except Exception as _e:
            try:
                db.session.rollback()
            except Exception:
                pass
            print('mark review text used error (api):', _e)
        # Уведомления (best-effort)
        
        try:
            from integration_api import notify_admin_new_submission, notify_bot_submission_sent
            task = Task.query.get(submission.task_id)
            notify_admin_new_submission({
                'submission_id': submission.id,
                'user_id': submission.user_id,
                'task_id': submission.task_id,
                'status': submission.status,
                'time': submission.submission_time.isoformat() if submission.submission_time else None
            })
            if submission.user_id and task:
                notify_bot_submission_sent(submission.user_id, task.title or '', submission.id, task.platform)
        except Exception as _e:
            try:
                print(f'[notify submit] {_e}')
            except Exception:
                pass
        
        return jsonify({'success': True, 'message': 'Статус обновлен'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/<int:user_id>')
def get_user_api(user_id):
    """API получения данных пользователя"""
    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'Пользователь не найден'}), 404
    
    return jsonify({
        'id': user.id,
        'user_id': user.user_id,
        'username': user.username,
        'full_name': user.full_name,
        'balance': float(user.balance) if user.balance else 0,
        'total_earnings': float(user.total_earnings) if user.total_earnings else 0
    })

@app.route('/api/tasks/active')
def get_active_tasks():
    """API получения активных заданий"""
    user_id = session.get('user_id')
    tasks_all = Task.query.filter_by(status='active').all()
    tasks = [t for t in tasks_all if not has_user_submitted(int(user_id) if user_id else None, t.id)]
    
    tasks_data = []
    for task in tasks:
        tasks_data.append({
            'id': task.id,
            'title': task.title,
            'platform': task.platform,
            'description': task.description,
            'reward_money': float(task.reward_money) if task.reward_money else 0,
            'created_at': task.created_at.isoformat() if task.created_at else None
        })
    
    return jsonify({'tasks': tasks_data})

@app.route('/api/submit_task', methods=['POST'])
def submit_task_api():
    """API отправки выполненного задания"""
    try:
        data = request.json

        # Не даем отправить более 1 выполнения на одно задание от одного пользователя
        from models import Submission, Task
        existing = Submission.query.filter_by(user_id=data.get('user_id'), task_id=data.get('task_id')).first()
        if existing:
            return jsonify({'success': False, 'message': 'Вы уже выполняли это задание'}), 409

        # Создаем новый отзыв
        submission = Submission(
            user_id=data.get('user_id'),
            task_id=data.get('task_id'),
            fio=data.get('fio'),
            notes=data.get('notes'),
            description=data.get('description'),
            screenshot_url=data.get('screenshot_url'),
            status='pending',
            submission_time=datetime.utcnow(),
            submitted_at=datetime.utcnow()
        )

        db.session.add(submission)
        
        db.session.commit()
        # Mark assigned review text as used (API)
        try:
            from models import TaskReviewText as _TRT
            _uid = data.get('user_id')
            _task_id = data.get('task_id')
            if _uid and _task_id:
                _assigned = _TRT.query                     .filter_by(task_id=_task_id, assigned_user_id=_uid)                     .filter(_TRT.status.in_(['assigned']))                     .order_by(_TRT.id.asc()).first()
                if _assigned:
                    _assigned.status = 'used'
                    _assigned.used_submission_id = submission.id
                    db.session.commit()
        except Exception as _e:
            try:
                db.session.rollback()
            except Exception:
                pass
            print('mark review text used error (api):', _e)
        # Уведомления (best-effort)
        
        try:
            from integration_api import notify_admin_new_submission, notify_bot_submission_sent
            task = Task.query.get(submission.task_id)
            notify_admin_new_submission({
                'submission_id': submission.id,
                'user_id': submission.user_id,
                'task_id': submission.task_id,
                'status': submission.status,
                'time': submission.submission_time.isoformat() if submission.submission_time else None
            })
            if submission.user_id and task:
                notify_bot_submission_sent(submission.user_id, task.title or '', submission.id, task.platform)
        except Exception as _e:
            try:
                print(f'[notify submit] {_e}')
            except Exception:
                pass

        return jsonify({
            'success': True, 
            'submission_id': submission.id,
            'message': 'Отзыв отправлен на проверку'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/register', methods=['POST'])
def register_user_api():
    """API регистрации пользователя"""
    try:
        data = request.json
        user_id = data.get('user_id')

        # Проверяем существование пользователя
        existing_user = User.query.filter_by(user_id=user_id).first()
        if existing_user:
            return jsonify({'message': 'Пользователь уже существует', 'user': {
                'id': existing_user.id,
                'user_id': existing_user.user_id,
                'username': existing_user.username
            }})

        # Создаем нового пользователя
        user = User(
            user_id=user_id,
            username=data.get('username'),
            full_name=data.get('full_name'),
            referrer_id=data.get('referrer_id')
        )

        db.session.add(user)
        db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Пользователь зарегистрирован',
            'user': {
                'id': user.id,
                'user_id': user.user_id,
                'username': user.username
            }
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# === АДМИНСКИЕ РОУТЫ ===

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Вход в админ панель"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = AdminUser.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            return redirect(url_for('admin.index'))
        else:
            flash('Неверный логин или пароль')
    
    return render_template('admin_login.html')

@app.route('/logout')
def logout():
    """Выход из админ панели"""
    logout_user()
    return redirect(url_for('login'))

# === СЛУЖЕБНЫЕ РОУТЫ ===

@app.route('/add_test_data')
def add_test_data():
    """Добавить тестовые данные"""
    try:
        # Создаем тестовое задание
        test_task = Task(
            title="Тестовое задание - Отзыв на Яндекс Картах",
            platform="Яндекс Карты",
            description="Оставьте положительный отзыв о нашей компании на Яндекс Картах",
            category="Отзывы",
            reward_money=100.00,
            submission_limit=10,
            status='active',
            task_url="https://yandex.ru/maps/org/test"
        )
        
        db.session.add(test_task)
        db.session.commit()
        
        # Добавляем подзадачи
        subtasks_data = [
            {"title": "Найти компанию", "description": "Найдите нашу компанию на Яндекс Картах", "is_required": True},
            {"title": "Оставить отзыв", "description": "Оставьте положительный отзыв с оценкой 5 звезд", "is_required": True},
            {"title": "Сделать скриншот", "description": "Сделайте скриншот оставленного отзыва", "is_required": True}
        ]
        
        for subtask_data in subtasks_data:
            subtask = Subtask(
                task_id=test_task.id,
                title=subtask_data['title'],
                description=subtask_data['description'],
                is_required=subtask_data['is_required'],
                points_value=1
            )
            db.session.add(subtask)
        
        db.session.commit()
        flash('Тестовые данные добавлены!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка при добавлении тестовых данных: {str(e)}', 'danger')
    
    return redirect(request.referrer or url_for('user_agreement'))

@app.route('/run_db_upgrade_on_amvera')
def run_db_upgrade_on_amvera():
    """Запуск миграций базы данных на Amvera"""
    try:
        upgrade()
        return jsonify({"status": "success", "message": "База данных обновлена"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route('/create_admin', methods=['GET', 'POST'])
def create_admin():
    """Создание admin пользователя"""
    if request.method == 'POST':
        username = request.form.get('username', 'admin')
        password = request.form.get('password', 'admin123')
        
        try:
            # Проверяем существование
            existing_admin = AdminUser.query.filter_by(username=username).first()
            if existing_admin:
                flash(f'Админ {username} уже существует!')
                return redirect(url_for('login'))
            
            # Создаем нового админа
            admin_user = AdminUser(username=username, role='admin')
            admin_user.set_password(password)
            
            db.session.add(admin_user)
            db.session.commit()
            
            flash(f'Админ {username} создан успешно!')
            return redirect(url_for('login'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка создания админа: {str(e)}')
    
    return render_template('admin_login.html', create_mode=True)

@app.route('/force_reset_db')
def force_reset_db():
    """ОСТОРОЖНО: Сброс базы данных"""
    if app.config.get('ENV') != 'production':
        try:
            db.drop_all()
            db.create_all()
            return jsonify({"status": "success", "message": "БД сброшена"})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)})
    else:
        return jsonify({"status": "error", "message": "Операция запрещена в продакшене"})

# Инициализация админ панели
with app.app_context():
    try:
        db.create_all()
        init_admin_views(admin, db)
    except Exception as e:
        print(f"Ошибка инициализации админ панели: {e}")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)