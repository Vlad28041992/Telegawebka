
import logging
import asyncio
from aiogram import executor
from config.settings import dp, bot

from handlers import start_handlers, profile_handlers, help_handlers, referral_handlers, admin_handlers, other_handlers, task_handlers

try:
    from http_api_fixed import start_http_api as run_http_api
except Exception:
    from http_api import start_http_api as run_http_api

async def on_startup(_):
    try:
        logging.info('Resetting webhook...')
        try:
            await bot.delete_webhook(drop_pending_updates=True)
        except Exception as e:
            logging.warning(f'Webhook reset warn: {e}')
        try:
            from database.db_operations import init_db_sync, populate_achievements
            init_db_sync()
            populate_achievements()
        except Exception as e:
            logging.warning(f'DB init warn: {e}')
        try:
            asyncio.create_task(run_http_api(host='0.0.0.0', port=int(os.getenv('PORT') or os.getenv('HTTP_API_PORT') or os.getenv('HTTP_PORT', '8000'))))
        except Exception as e:
            logging.error(f'HTTP API error: {e}')
        me = await bot.get_me()
        logging.info(f"Bot @{getattr(me, 'username', '')} is up")
    except Exception as e:
        logging.error(f'on_startup error: {e}')

async def on_shutdown(_):
    try:
        await bot.close()
    except Exception:
        pass

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup, on_shutdown=on_shutdown)
