import logging
import asyncio
from aiogram import executor
import psycopg2
from database.connection import get_connection as _get_conn
from config.settings import dp, bot



async def ensure_single_instance():
    try:
        from utils.contest_tasks import start_contest_background_tasks
        start_contest_background_tasks(asyncio.get_event_loop())
        conn = _get_conn()
        if not conn:
            return True
        cur = conn.cursor()
        cur.execute("SELECT pg_try_advisory_lock(%s)", (91133742,))
        locked = cur.fetchone()[0]
        cur.close(); conn.close()
        return bool(locked)
    except Exception:
        return True

# Импорт всех обработчиков ОБЯЗАТЕЛЕН, иначе кнопки не работают
from handlers import start_handlers
from handlers import profile_handlers
from handlers import help_handlers
from handlers import referral_handlers
from handlers import admin_handlers
from handlers import other_handlers_fixed as other_handlers
from handlers import task_handlers
from handlers import support_handlers
from handlers import command_handlers
from handlers import contest_handlers

from http_api_fixed import start_http_api
import os

async def on_startup(_):
    import asyncio
    asyncio.create_task(start_http_api(host='0.0.0.0', port=int(os.getenv('PORT') or os.getenv('HTTP_API_PORT') or os.getenv('HTTP_PORT', '8000'))))
    try:
        # Сбрасываем webhook, чтобы polling принимал апдейты
        logging.info('Resetting webhook...')
        try:
            await bot.delete_webhook(drop_pending_updates=True)
        except Exception as e:
            logging.warning(f'Webhook reset warn: {e}')

        # Инициализируем базу (синхронные функции импортируются здесь, чтобы не было циклов)
        try:
            from database.db_operations import init_db_sync, populate_achievements
            init_db_sync()
            populate_achievements()
            logging.info('DB initialized')
        except Exception as e:
            logging.warning(f'DB init warn: {e}')

        me = await bot.get_me()
        logging.info(f"Bot @{getattr(me, 'username', '')} is up")

        # Set slash commands for the bot
        try:
            from aiogram.types import BotCommand
            cmds = [
                BotCommand('start', 'Запустить бота'),
                BotCommand('menu', 'Главное меню'),
                BotCommand('profile', 'Мой профиль'),
                BotCommand('history', 'История транзакций'),
                BotCommand('help', 'Помощь'),
                BotCommand('referrals', 'Реферальная система')
            ]
            await bot.set_my_commands(cmds)
        except Exception as e:
            logging.warning(f'Failed to set commands: {e}')

    except Exception as e:
        logging.error(f'on_startup error: {e}')

async def on_shutdown(_):
    try:
        await bot.close()
    except Exception:
        pass

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    # Запускаем polling; handlers уже импортированы выше
    loop = asyncio.get_event_loop()
    ok = loop.run_until_complete(ensure_single_instance())
    if not ok:
        import sys
        sys.exit(1)
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup, on_shutdown=on_shutdown)