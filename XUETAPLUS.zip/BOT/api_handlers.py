# api_handlers.py - API обработчики для интеграции бота
import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from config.settings import dp, bot, WEB_APP_URL
from datetime import datetime
import json


@dp.message_handler(content_types=['text'], state="*", regexp=r'^/api_.*')
async def api_handler_router(message: types.Message, state: FSMContext):
    """Роутер для API команд"""
    command = message.text
    
    if command.startswith('/api_submission_sent'):
        await handle_submission_sent_notification(message, state)
    elif command.startswith('/api_submission_approved'):
        await handle_submission_approved_notification(message, state) 
    elif command.startswith('/api_submission_rejected'):
        await handle_submission_rejected_notification(message, state)
    elif command.startswith('/api_new_task'):
        await handle_new_task_notification(message, state)


async def handle_submission_sent_notification(message: types.Message, state: FSMContext):
    """Обработка уведомления об отправке заявки"""
    try:
        # В реальности данные будут приходить через POST запрос
        # Здесь просто пример обработки
        user_id = message.from_user.id
        
        text = """
📝 Ваша заявка отправлена на проверку!

⏱ Время проверки: обычно зависит от площадки: Яндекс Карты — 3–4 дня, Google Карты — 6–7 дней, Авито — 2–4 дня, Яндекс WebMaster — 2–4 дня
🔔 Мы уведомим вас о результате

Спасибо за выполнение задания!
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton(
                "💰 Выполнить еще", 
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await message.answer(text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка в handle_submission_sent_notification: {e}")


async def handle_submission_approved_notification(message: types.Message, state: FSMContext):
    """Обработка уведомления об одобрении заявки"""
    try:
        user_id = message.from_user.id
        
        text = """
✅ Поздравляем! Ваша заявка одобрена!

💰 Средства зачислены на ваш баланс
💳 Можете вывести деньги или продолжить выполнять задания

Продолжайте зарабатывать!
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=2)
        keyboard.add(
            types.InlineKeyboardButton("👤 Мой профиль", callback_data="profile"),
            types.InlineKeyboardButton(
                "💰 Заработать еще", 
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await message.answer(text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка в handle_submission_approved_notification: {e}")


async def handle_submission_rejected_notification(message: types.Message, state: FSMContext):
    """Обработка уведомления об отклонении заявки"""
    try:
        text = """
❌ К сожалению, ваша заявка отклонена

💡 Внимательно читайте инструкции к заданиям и следуйте им точно.
Вы можете попробовать выполнить другие задания!
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton(
                "💰 Попробовать снова",
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await message.answer(text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка в handle_submission_rejected_notification: {e}")


async def handle_new_task_notification(message: types.Message, state: FSMContext):
    """Обработка уведомления о новом задании"""
    try:
        text = """
🆕 Появилось новое задание!

💰 Новые возможности для заработка ждут вас!
Переходите в веб-приложение и выполняйте задания.
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton(
                "💰 Посмотреть задания", 
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await message.answer(text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка в handle_new_task_notification: {e}")


# Функции для уведомлений (вызываются из других модулей)
async def send_submission_sent_notification(user_id: int, task_title: str, submission_id: int):
    """Отправить уведомление об отправке заявки"""
    try:
        text = f"""
📝 Ваша заявка #{submission_id} отправлена на проверку!

🎯 Задание: {task_title}
⏱ Время проверки: обычно зависит от площадки: Яндекс Карты — 3–4 дня, Google Карты — 6–7 дней, Авито — 2–4 дня, Яндекс WebMaster — 2–4 дня
🔔 Мы уведомим вас о результате

Спасибо за выполнение задания!
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton(
                "💰 Выполнить еще",
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await bot.send_message(user_id, text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка при отправке уведомления: {e}")


async def send_submission_approved_notification(user_id: int, submission_id: int, reward_money: float):
    """Отправить уведомление об одобрении заявки"""
    try:
        text = f"""
✅ Поздравляем! Ваша заявка #{submission_id} одобрена!

💰 Начислено: {reward_money} ₽
💳 Средства зачислены на ваш баланс

Продолжайте выполнять задания и зарабатывать еще больше!
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=2)
        keyboard.add(
            types.InlineKeyboardButton("👤 Мой баланс", callback_data="profile"),
            types.InlineKeyboardButton(
                "💰 Заработать еще", 
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await bot.send_message(user_id, text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка при отправке уведомления об одобрении: {e}")


async def send_submission_rejected_notification(user_id: int, submission_id: int, reason: str):
    """Отправить уведомление об отклонении заявки"""
    try:
        text = f"""
❌ К сожалению, ваша заявка #{submission_id} отклонена

📝 Причина: {reason}

💡 Внимательно читайте инструкции к заданиям и следуйте им точно.
Вы можете попробовать выполнить другие задания!
"""
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton(
                "💰 Попробовать снова",
                web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
            )
        )
        
        await bot.send_message(user_id, text, reply_markup=keyboard)
        
    except Exception as e:
        logging.error(f"Ошибка при отправке уведомления об отклонении: {e}")
