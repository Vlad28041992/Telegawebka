
import logging
from database.db_operations import get_db_connection

def ensure_denorm_columns():
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cur = conn.cursor()
        stmts = [
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_reward_money numeric(10,2)",
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_reward_points integer",
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_platform text",
            "ALTER TABLE submissions ADD COLUMN IF NOT EXISTS approved_task_title text"
        ]
        for s in stmts:
            try:
                cur.execute(s)
                conn.commit()
            except Exception:
                conn.rollback()
        cur.close(); conn.close()
        return True
    except Exception as e:
        logging.error(f"ensure_denorm_columns error: {e}")
        try:
            if conn:
                conn.rollback(); conn.close()
        except Exception:
            pass
        return False
