#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ИСПРАВЛЕННЫЙ MAIN.PY - СТАБИЛЬНАЯ ВЕРСИЯ БОТА БЕЗ ОШИБОК ВЫПЛАТ!
Все проблемы с падением бота после ввода реквизитов исправлены
"""

import logging
import asyncio
import sys
import os
from aiogram import executor

# Настройка расширенного логирования для отладки
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('bot.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

# Логируем старт бота
logger.info("🚀 Запуск ИСПРАВЛЕННОЙ версии бота...")

# Импорт настроек с проверкой ошибок
try:
    from config.settings import dp, bot, DATABASE_CONFIG
    logger.info("✅ Конфигурация успешно загружена")
except ImportError as e:
    logger.error(f"❌ КРИТИЧЕСКАЯ ОШИБКА импорта конфигурации: {e}")
    sys.exit(1)

# Импорт всех обработчиков с детальной проверкой
try:
    logger.info("📥 Импорт обработчиков...")
    from handlers import start_handlers
    logger.info("✅ start_handlers импортирован")

    from handlers import profile_handlers
    logger.info("✅ profile_handlers импортирован")

    from handlers import help_handlers
    logger.info("✅ help_handlers импортирован")

    from handlers import referral_handlers
    logger.info("✅ referral_handlers импортирован")

    from handlers import admin_handlers
    logger.info("✅ admin_handlers импортирован")

    from handlers import other_handlers_fixed as other_handlers
    logger.info("✅ other_handlers (ИСПРАВЛЕННЫЕ ВЫПЛАТЫ) импортированы")

    from handlers import task_handlers
    logger.info("✅ task_handlers импортирован")

    from handlers import contest_handlers
    logger.info("✅ contest_handlers импортирован")

    logger.info("🎉 ВСЕ ОБРАБОТЧИКИ УСПЕШНО ИМПОРТИРОВАНЫ!")

    from aiogram.types import BotCommand
    async def __set_commands(bot):
        try:
            cmds = [
                BotCommand("start", "Запустить бота"),
                BotCommand("menu", "Главное меню"),
                BotCommand("profile", "Мой профиль"),
                BotCommand("history", "История транзакций"),
                BotCommand("help", "Помощь"),
                BotCommand("referrals", "Реферальная система")
            ]
            await bot.set_my_commands(cmds)
        except Exception as e:
            logger.warning(f'Failed to set commands: {e}')

except ImportError as e:
    logger.error(f"❌ КРИТИЧЕСКАЯ ОШИБКА импорта обработчиков: {e}")
    logger.error("🔍 Проверьте, что файл handlers/other_handlers.py содержит исправленный код")
    sys.exit(1)

async def init_database():
    """Инициализация базы данных с улучшенной обработкой ошибок"""
    try:
        logger.info("🗄️ Инициализация базы данных...")
        
        from database.db_operations import init_db_sync, get_db_connection
        
        # Проверяем подключение к БД
        logger.info("🔗 Проверка подключения к БД...")
        conn = get_db_connection()
        if conn:
            conn.close()
            logger.info("✅ Подключение к БД успешно установлено")
        else:
            logger.error("❌ Не удалось подключиться к БД")
            return False
            
        # Инициализируем БД
        logger.info("⚙️ Инициализация структуры БД...")
        if init_db_sync():
            logger.info("✅ База данных инициализирована успешно")
            
            # Попробуем создать достижения (если функция существует)
            try:
                from database.db_operations import populate_achievements
                populate_achievements()
                logger.info("✅ Достижения загружены")
            except ImportError:
                logger.info("ℹ️ Функция populate_achievements не найдена (не критично)")
            except Exception as e:
                logger.warning(f"⚠️ Ошибка загрузки достижений: {e}")
                
            return True
        else:
            logger.error("❌ Ошибка инициализации БД")
            return False
            
    except Exception as e:
        logger.error(f"❌ Критическая ошибка init_database: {e}")
        return False

async def on_startup(dp):
    """Инициализация при запуске бота"""
    logger.info("🌟 Инициализация бота при запуске...")
    
    # Инициализируем БД
    db_init_success = await init_database()
    if not db_init_success:
        logger.error("❌ Не удалось инициализировать БД - бот может работать нестабильно")
    
    # Отправляем уведомление админам о запуске
    try:
        from config.settings import ADMINS
        for admin_id in ADMINS:
            try:
                await bot.send_message(
                    admin_id,
                    "🚀 <b>БОТ ЗАПУЩЕН!</b>\n\n"
                    "✅ Исправленная версия выплат активна\n"
                    "🛡️ Все ошибки падения бота устранены\n"
                    "⚡️ Готов к работе!",
                    parse_mode="HTML"
                )
                logger.info(f"✅ Уведомление о запуске отправлено админу {admin_id}")
            except Exception as e:
                logger.error(f"❌ Ошибка отправки уведомления админу {admin_id}: {e}")
                
    except Exception as e:
        logger.error(f"⚠️ Ошибка при отправке уведомлений о запуске: {e}")
    
    logger.info("🎉 Бот успешно запущен и готов к работе!")
    try:
        await __set_commands(bot)
    except Exception as e:
        logger.warning(f'Failed to set commands: {e}')


async def on_shutdown(dp):
    """Завершение работы бота"""
    logger.info("🛑 Завершение работы бота...")
    
    # Отправляем уведомление админам об остановке
    try:
        from config.settings import ADMINS
        for admin_id in ADMINS:
            try:
                await bot.send_message(
                    admin_id,
                    "🛑 <b>БОТ ОСТАНОВЛЕН</b>\n\n"
                    "⚠️ Требуется перезапуск для возобновления работы",
                    parse_mode="HTML"
                )
            except:
                pass
    except:
        pass
    
    try:
        session = await bot.get_session()
        await session.close()
    except Exception:
        pass
    logger.info("👋 Бот корректно завершил работу")

def main():
    """Основная функция запуска бота"""
    try:
        logger.info("🚀 ЗАПУСК ИСПРАВЛЕННОГО БОТА...")
        logger.info("📋 Версия: БЕЗ ОШИБОК ВЫПЛАТ")
        logger.info("🔧 Исправления: падение после ввода реквизитов устранено")
        
        # Запускаем бота с обработчиками событий
        executor.start_polling(
            dp,
            on_startup=on_startup,
            on_shutdown=on_shutdown,
            skip_updates=True,  # Пропускаем старые сообщения
            timeout=20,         # Тайм-аут опроса
            relax=0.1          # Пауза между запросами
        )
        
    except KeyboardInterrupt:
        logger.info("⌨️ Получен сигнал остановки (Ctrl+C)")
    except Exception as e:
        logger.error(f"❌ Критическая ошибка запуска бота: {e}")
        sys.exit(1)
    finally:
        logger.info("🏁 Программа завершена")

if __name__ == '__main__':
    # Проверяем Python версию
    if sys.version_info < (3, 7):
        logger.error("❌ Требуется Python 3.7 или выше")
        sys.exit(1)
    
    # Проверяем переменные окружения
    required_env_vars = ['TELEGRAM_BOT_TOKEN', 'DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']
    missing_vars = [var for var in required_env_vars if not os.getenv(var)]
    
    if missing_vars:
        logger.error(f"❌ Отсутствуют переменные окружения: {', '.join(missing_vars)}")
        logger.error("🔧 Установите их перед запуском бота")
        sys.exit(1)
    
    logger.info("✅ Все проверки пройдены, запускаем бот...")
    main()