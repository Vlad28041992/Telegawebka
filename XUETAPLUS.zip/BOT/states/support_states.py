
from aiogram.dispatcher.filters.state import State, StatesGroup

class SupportStates(StatesGroup):
    waiting_subject = State()
    waiting_message = State()
    waiting_reply_message = State()
