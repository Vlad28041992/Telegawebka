# states/user_states.py
from aiogram.dispatcher.filters.state import State, StatesGroup

class WithdrawFlow(StatesGroup):
    choosing_method = State()
    entering_amount = State()
    entering_bank = State()  # Новое состояние для выбора банка (только для СБП)
    entering_details = State()