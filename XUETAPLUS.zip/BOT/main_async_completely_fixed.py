import logging
import asyncio
from aiogram import executor
import psycopg2
from database.connection import get_connection as _get_conn
from config.settings import dp, bot

async def ensure_single_instance():
    try:
        conn = _get_conn()
        if not conn:
            return True
        cur = conn.cursor()
        cur.execute("SELECT pg_try_advisory_lock(%s)", (91133742,))
        locked = cur.fetchone()[0]
        cur.close(); conn.close()
        return bool(locked)
    except Exception:
        return True

# Импорт всех обработчиков ОБЯЗАТЕЛЕН, иначе кнопки не работают
from handlers import start_handlers
from handlers import profile_handlers
from handlers import help_handlers
from handlers import referral_handlers
from handlers import admin_handlers
from handlers import other_handlers
from handlers import task_handlers

from http_api_fixed import start_http_api
import os

async def on_startup(_):
    try:
        # Запускаем HTTP API
        port = int(os.getenv('PORT', os.getenv('HTTP_API_PORT', os.getenv('HTTP_PORT', '5000'))))
        logging.info(f'Starting HTTP API on port {port}')
        asyncio.create_task(start_http_api(host='0.0.0.0', port=port))
        
        # Сбрасываем webhook, чтобы polling принимал апдейты
        logging.info('Resetting webhook...')
        try:
            await bot.delete_webhook(drop_pending_updates=True)
            logging.info('Webhook reset successful')
        except Exception as e:
            logging.warning(f'Webhook reset warn: {e}')

        # Инициализируем базу
        try:
            from database.db_operations import init_db_sync, populate_achievements
            init_db_sync()
            populate_achievements()
            logging.info('DB initialized successfully')
        except Exception as e:
            logging.warning(f'DB init warn: {e}')

        me = await bot.get_me()
        logging.info(f"Bot @{getattr(me, 'username', '')} is up and running!")
        logging.info(f"HTTP API should be available on port {port}")
        
    except Exception as e:
        logging.error(f'on_startup error: {e}')

async def on_shutdown(_):
    try:
        await bot.close()
        logging.info("Bot shut down successfully")
    except Exception as e:
        logging.error(f'on_shutdown error: {e}')

if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Запускаем polling
    loop = asyncio.get_event_loop()
    ok = loop.run_until_complete(ensure_single_instance())
    if not ok:
        logging.error("Another instance is already running!")
        import sys
        sys.exit(1)
    
    logging.info("Starting bot...")
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup, on_shutdown=on_shutdown)
