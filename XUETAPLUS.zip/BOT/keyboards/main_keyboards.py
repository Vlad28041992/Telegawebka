# keyboards/main_keyboards.py
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from config.settings import WEB_APP_URL

def main_keyboard(user_id=None):
    """Основное меню бота с WebApp кнопкой для заработка"""
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    # ИСПРАВЛЕНО: убрали ?user_id=... из URL, потому что Telegram автоматически
    # передает все данные пользователя через Telegram.WebApp.initData
    # kb.add(KeyboardButton("🚀 Заработать!", web_app=WebAppInfo(url=WEB_APP_URL)))  # ВРЕМЕННО ОТКЛЮЧЕНО
    kb.add(KeyboardButton("😎 Мой Профиль"))
    try:
        from config.settings import CONTEST_ACTIVE
        if CONTEST_ACTIVE:
            kb.add(KeyboardButton("🏆 Конкурс рефералов"))
    except Exception:
        pass
    kb.add(KeyboardButton("🤝 Пригласи Друзей"), KeyboardButton("❓ Помощь"))
    return kb

def back_to_menu_kb_reply():
    """Кнопка для возврата в главное меню (ReplyKeyboardMarkup)"""
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add(KeyboardButton("🔙 На Главную"))
    return kb

def get_main_keyboard():
    """Алиас для main_keyboard() для совместимости"""
    return main_keyboard()
