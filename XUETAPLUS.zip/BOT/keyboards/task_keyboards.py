# keyboards/task_keyboards.py
from aiogram import types

def get_task_menu_keyboard():
    """Клавиатура меню заданий"""
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    
    keyboard.add(
        types.KeyboardButton("🌐 WebApp заработок"),
        types.KeyboardButton("📝 Задания в боте")
    )
    keyboard.add(types.KeyboardButton("🏠 Главное меню"))
    
    return keyboard

def get_back_to_main_keyboard():
    """Клавиатура возврата в главное меню"""
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    keyboard.add(types.KeyboardButton("🏠 Главное меню"))
    return keyboard

def get_task_action_keyboard(task_id):
    """Inline клавиатура для действий с заданием"""
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    
    keyboard.add(
        types.InlineKeyboardButton("✅ Выполнено", callback_data=f"task_complete:{task_id}"),
        types.InlineKeyboardButton("❌ Отказаться", callback_data=f"task_cancel:{task_id}")
    )
    
    return keyboard

def get_webapp_keyboard(user_id):
    """Клавиатура с кнопкой WebApp"""
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    
    from config.settings import WEB_APP_URL
    webapp_button = types.InlineKeyboardButton(
        text="🚀 Открыть приложение",
        web_app=types.WebAppInfo(web_app=types.WebAppInfo(url=WEB_APP_URL))
    )
    
    keyboard.add(webapp_button)
    return keyboard
