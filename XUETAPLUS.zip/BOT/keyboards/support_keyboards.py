
from aiogram import types

def support_menu_kb():
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton('🆕 Создать тикет', callback_data='support_create'),
        types.InlineKeyboardButton('📂 Мои тикеты', callback_data='support_list')
    )
    return kb

def ticket_actions_kb(ticket_id: int, can_close: bool = True):
    kb = types.InlineKeyboardMarkup(row_width=2)
    # Reply button only when ticket is not closed
    if can_close:
        kb.add(
            types.InlineKeyboardButton('💬 Ответить', callback_data=f'support_reply:{ticket_id}'),
            types.InlineKeyboardButton('🔄 Обновить', callback_data=f'support_open:{ticket_id}')
        )
        kb.add(types.InlineKeyboardButton('✅ Закрыть тикет', callback_data=f'support_close:{ticket_id}'))
    else:
        kb.add(
            types.InlineKeyboardButton('🔄 Обновить', callback_data=f'support_open:{ticket_id}')
        )
    return kb
