# keyboards/profile_keyboards.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

def profile_keyboard():
    """Клавиатура для профиля пользователя"""
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        InlineKeyboardButton("📊 Статистика", callback_data="profile_stats"),
        InlineKeyboardButton("🏆 Топ пользователей", callback_data="profile_top"),
        InlineKeyboardButton("💳 Вывод средств", callback_data="profile_withdraw")
    )
    # Кнопка "🔙 На главную" (Inline) удалена отсюда. Она будет в ReplyKeyboardMarkup ниже.
    return keyboard

def top_keyboard():
    """Клавиатура для выбора типа топа"""
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("💰 Топ по деньгам", callback_data="top_money"),
        InlineKeyboardButton("🏅 Топ по баллам", callback_data="top_points")
    )
    kb.add(InlineKeyboardButton("⬅️ Назад к Профилю", callback_data="back_to_profile_from_top")) # Новая кнопка для возврата из топа в профиль
    return kb

def top_period_keyboard(top_type):
    """Клавиатура для выбора периода топа"""
    kb = InlineKeyboardMarkup(row_width=3)
    kb.add(
        InlineKeyboardButton("Неделя", callback_data=f"{top_type}_week"),
        InlineKeyboardButton("Месяц", callback_data=f"{top_type}_month"),
        InlineKeyboardButton("Все время", callback_data=f"{top_type}_all")
    )
    kb.add(InlineKeyboardButton("⬅️ Назад к выбору типа", callback_data="profile_top")) # Изменен callback для возврата к выбору типа топа
    return kb

def get_withdraw_keyboard():
    """Клавиатура для выбора суммы вывода"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add("300", "500", "1000")
    keyboard.add("🔙 На Главную")
    return keyboard