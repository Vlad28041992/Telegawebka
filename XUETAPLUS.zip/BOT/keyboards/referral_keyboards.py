# keyboards/referral_keyboards.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData

# Создаем CallbackData для реферальной системы
ref_cb = CallbackData("ref", "action")

def ref_keyboard():
    """Клавиатура для реферальной системы"""
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("🔗 Моя Ссылка", callback_data=ref_cb.new(action="get_link")),
        InlineKeyboardButton("📊 Статистика", callback_data=ref_cb.new(action="stats"))
    )
    # Кнопка "⬅️ Назад" (Inline) удалена отсюда. Она будет в ReplyKeyboardMarkup ниже.
    return kb