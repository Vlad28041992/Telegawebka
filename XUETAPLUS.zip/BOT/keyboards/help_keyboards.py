# keyboards/help_keyboards.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def help_keyboard():
    """Клавиатура для раздела помощи"""
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📚 FAQ", callback_data="help_faq"),
        InlineKeyboardButton("👨‍💻 Тех.Поддержка", callback_data="help_support")
    )
    kb.add(
        InlineKeyboardButton("📣 Канал", callback_data="help_channel"),
        InlineKeyboardButton("⭐ Отзывы", callback_data="help_reviews")
    )
    kb.add(
        InlineKeyboardButton("💬 Чат", callback_data="help_chat"),
        InlineKeyboardButton("🔙 Назад в меню", callback_data="help_back")
    )
    return kb
