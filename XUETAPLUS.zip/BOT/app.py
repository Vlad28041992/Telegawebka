import os
import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func, case, desc, and_, or_
from sqlalchemy.exc import IntegrityError
import json
import csv
import io
from datetime import timedelta
import requests

# --- ИНИЦИАЛИЗАЦИЯ ПРИЛОЖЕНИЯ И КОНФИГУРАЦИЯ ---

app = Flask(__name__)

# Строка подключения к БД теперь будет браться из переменных окружения на Amvera
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-super-secret-key-for-dev')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}

# Инициализация расширений
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# --- МОДЕЛИ ДАННЫХ (ИНТЕГРИРОВАННЫЕ С БОТОМ И ВЕБ-АПП) ---

class Admin(UserMixin, db.Model):
    __tablename__ = 'admin'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), default='admin')
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    last_login = db.Column(db.DateTime)
    email = db.Column(db.String(120))
    is_active = db.Column(db.Boolean, default=True)
    password_hash = db.Column(db.String(255))

    def check_password(self, password):
        return check_password_hash(self.password, password)

@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

# Используем унифицированные модели для интеграции
class User(db.Model):
    __tablename__ = 'users'
    
    user_id = db.Column(db.BigInteger, primary_key=True)
    id = db.Column(db.Integer, unique=True, nullable=False)
    username = db.Column(db.Text)
    full_name = db.Column(db.Text)
    balance = db.Column(db.Integer, default=0)
    assigned_task_id = db.Column(db.Integer)
    assigned_task_time = db.Column(db.BigInteger)
    weekly_points = db.Column(db.Integer, default=0)
    total_points = db.Column(db.Integer, default=0)
    total_earnings = db.Column(db.Integer, default=0)
    earnings_from_tasks = db.Column(db.Integer, default=0)
    referral_1_level = db.Column(db.Integer, default=0)
    referral_2_level = db.Column(db.Integer, default=0)
    earnings_from_referrals = db.Column(db.Integer, default=0)
    referrer_id = db.Column(db.BigInteger)
    last_login_date = db.Column(db.Text)
    login_streak = db.Column(db.Integer, default=0)
    points = db.Column(db.Integer, default=0)
    role = db.Column(db.String(50), default='user')
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    email = db.Column(db.String(120), nullable=False, default='')
    registration_date = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    is_banned = db.Column(db.Boolean, default=False)
    ban_reason = db.Column(db.Text)
    referral_earnings_1 = db.Column(db.Numeric(10, 2), default=0)
    referral_earnings_2 = db.Column(db.Numeric(10, 2), default=0)
    is_active = db.Column(db.Boolean, default=True)
    last_activity = db.Column(db.DateTime)
    referrals_level_1 = db.Column(db.Integer, default=0)
    referrals_level_2 = db.Column(db.Integer, default=0)

# Модель для унифицированных задач (интеграция с ботом и веб-апп)
class Task(db.Model):
    __tablename__ = 'unified_tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    platform = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text, nullable=False)
    city = db.Column(db.Text)
    direction = db.Column(db.Text)
    reward_money = db.Column(db.Numeric(10, 2))
    reward_points = db.Column(db.Integer)
    task_url = db.Column(db.String(500))
    instruction_link = db.Column(db.Text)
    submission_limit = db.Column(db.Integer)
    is_active = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(50), default='active')
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    priority = db.Column(db.Integer, default=1)
    source_table = db.Column(db.Text, default='unified')

# Модель для унифицированных подач (интеграция с ботом и веб-апп)
class Submission(db.Model):
    __tablename__ = 'unified_submissions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False)
    task_id = db.Column(db.Integer, nullable=False)
    fio = db.Column(db.String(255))
    full_name = db.Column(db.String(255))
    screenshot_url = db.Column(db.String(500))
    screenshot_file_id = db.Column(db.String(255))
    notes = db.Column(db.Text)
    description = db.Column(db.Text)
    status = db.Column(db.String(50), default='pending')
    submission_time = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    created_at = db.Column(db.DateTime(timezone=True), default=datetime.datetime.utcnow)
    review_time = db.Column(db.DateTime)
    reviewer_id = db.Column(db.Integer)
    rejection_reason = db.Column(db.Text)
    source_table = db.Column(db.Text, default='unified')

class WithdrawRequest(db.Model):
    __tablename__ = 'withdraw_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.BigInteger)
    amount = db.Column(db.Integer)
    method = db.Column(db.Text)
    details = db.Column(db.Text)
    status = db.Column(db.Text, default='pending')
    created_at = db.Column(db.BigInteger)
    processed_at = db.Column(db.DateTime)
    payment_transaction_id = db.Column(db.String(255))
    payment_notes = db.Column(db.Text)
    payment_method = db.Column(db.String(100))
    payment_details = db.Column(db.Text)
    request_time = db.Column(db.DateTime)
    processed_time = db.Column(db.DateTime)
    processor_id = db.Column(db.Integer)
    transaction_id = db.Column(db.String(255))
    notes = db.Column(db.Text)

class SystemLog(db.Model):
    __tablename__ = 'system_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer)
    action = db.Column(db.String(100), nullable=False)
    entity_type = db.Column(db.String(50))
    entity_id = db.Column(db.Integer)
    details = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    ip_address = db.Column(db.String(45))

class SystemSettings(db.Model):
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100))
    value = db.Column(db.Text)
    description = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    updated_by = db.Column(db.Integer)
    setting_key = db.Column(db.String(100), nullable=False)
    setting_value = db.Column(db.Text)

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---

def log_action(action, entity_type=None, entity_id=None, details=None):
    """Логирование действий администратора"""
    try:
        log = SystemLog(
            admin_id=current_user.id if current_user.is_authenticated else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            details=details,
            ip_address=request.remote_addr
        )
        db.session.add(log)
        db.session.commit()
    except:
        db.session.rollback()

# --- АВТОРИЗАЦИЯ ---


# --- CONTEXT PROCESSOR ДЛЯ ПЕРЕДАЧИ ДАННЫХ В ШАБЛОНЫ ---

@app.context_processor
def inject_pending_counts():
    """Внедряет количество ожидающих элементов в шаблоны"""
    try:
        if current_user.is_authenticated:
            pending_submissions = Submission.query.filter_by(status='pending').count()
            pending_payouts = WithdrawRequest.query.filter_by(status='pending').count()
            return {
                'pending_submissions_count': pending_submissions,
                'pending_payouts_count': pending_payouts
            }
        return {
            'pending_submissions_count': 0,
            'pending_payouts_count': 0
        }
    except:
        return {
            'pending_submissions_count': 0,
            'pending_payouts_count': 0
        }

# --- РОУТЫ ---

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and admin.check_password(password):
            login_user(admin)
            admin.last_login = datetime.datetime.utcnow()
            db.session.commit()
            
            log_action('login', details=f'Успешный вход пользователя {username}')
            flash('Добро пожаловать в админ-панель!', 'success')
            return redirect(url_for('dashboard'))
        else:
            log_action('failed_login', details=f'Неудачная попытка входа: {username}')
            flash('Неверные учетные данные', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    log_action('logout', details=f'Выход пользователя {current_user.username}')
    logout_user()
    flash('Вы успешно вышли из системы', 'info')
    return redirect(url_for('login'))

# --- ОСНОВНЫЕ СТРАНИЦЫ ---

@app.route('/')
@app.route('/dashboard')
@login_required
def dashboard():
    try:
        stats = {
            'total_users': User.query.count() if User.query.first() else 0,
            'active_users': User.query.filter(User.last_activity >= datetime.utcnow() - timedelta(days=7)).count() if User.query.first() else 0,
            'active_tasks': Task.query.filter_by(is_active=True).count() if Task.query.first() else 0,
            'total_earnings': db.session.query(func.sum(User.total_earnings)).scalar() or 0,
            'pending_withdrawals': WithdrawRequest.query.filter_by(status='pending').count() if WithdrawRequest.query.first() else 0,
            'total_submissions': Submission.query.count() if Submission.query.first() else 0,
            'pending_submissions': Submission.query.filter_by(status='pending').count() if Submission.query.first() else 0,
            'approved_submissions': Submission.query.filter_by(status='approved').count() if Submission.query.first() else 0,
            'rejected_submissions': Submission.query.filter_by(status='rejected').count() if Submission.query.first() else 0,
        }
        
        recent_submissions = []
        if Submission.query.first():
            recent_submissions = Submission.query.filter_by(status='pending').order_by(desc(Submission.submission_time)).limit(10).all()
        
        platform_stats = []
        if Task.query.first() and Submission.query.first():
            platform_stats = db.session.query(Task.platform, func.count(Submission.id).label('submissions_count')).join(Submission).group_by(Task.platform).all()
        
        return render_template('dashboard.html', stats=stats, recent_submissions=recent_submissions, platform_stats=platform_stats)
    except Exception as e:
        print(f'Dashboard error: {e}')
        stats = {'total_users': 0, 'active_users': 0, 'active_tasks': 0, 'total_earnings': 0, 'pending_withdrawals': 0, 'total_submissions': 0, 'pending_submissions': 0, 'approved_submissions': 0, 'rejected_submissions': 0}
        return render_template('dashboard.html', stats=stats, recent_submissions=[], platform_stats=[])
@app.route('/tasks')
@login_required
def tasks():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        # Фильтры
        platform_filter = request.args.get('platform', '')
        status_filter = request.args.get('status', '')
        
        query = Task.query
        
        if platform_filter:
            query = query.filter(Task.platform.ilike(f'%{platform_filter}%'))
        if status_filter:
            if status_filter == 'active':
                query = query.filter_by(is_active=True)
            elif status_filter == 'inactive':
                query = query.filter_by(is_active=False)
        
        tasks = query.order_by(desc(Task.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('tasks.html', tasks=tasks, 
                             platform_filter=platform_filter, 
                             status_filter=status_filter)
                             
    except Exception as e:
        flash(f'Ошибка загрузки задач: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

@app.route('/tasks/new', methods=['GET', 'POST'])
@login_required
def new_task():
    if request.method == 'POST':
        try:
            task = Task(
                title=request.form['title'],
                platform=request.form['platform'],
                description=request.form['description'],
                city=request.form.get('city', ''),
                direction=request.form.get('direction', ''),
                reward_money=float(request.form.get('reward_money', 0)),
                reward_points=int(request.form.get('reward_points', 0)),
                task_url=request.form.get('task_url', ''),
                instruction_link=request.form.get('instruction_link', ''),
                submission_limit=int(request.form.get('submission_limit', 100)),
                is_active=bool(request.form.get('is_active')),
                priority=int(request.form.get('priority', 1))
            )
            
            db.session.add(task)
            db.session.commit()
            
            log_action('create_task', 'task', task.id, f'Создана задача: {task.title}')
            flash('Задача успешно создана!', 'success')
            return redirect(url_for('tasks'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка создания задачи: {str(e)}', 'error')
    
    return render_template('task_form.html', task=None)

# Поддерживаем старый формат URL для совместимости
@app.route('/tasks/edit/<int:task_id>', methods=['GET', 'POST'])
@app.route('/tasks/<int:task_id>/edit', methods=['GET', 'POST'])
@login_required  
def edit_task(task_id):
    task = Task.query.get_or_404(task_id)
    
    if request.method == 'POST':
        try:
            task.title = request.form['title']
            task.platform = request.form['platform']
            task.description = request.form['description']
            task.city = request.form.get('city', '')
            task.direction = request.form.get('direction', '')
            task.reward_money = float(request.form.get('reward_money', 0))
            task.reward_points = int(request.form.get('reward_points', 0))
            task.task_url = request.form.get('task_url', '')
            task.instruction_link = request.form.get('instruction_link', '')
            task.submission_limit = int(request.form.get('submission_limit', 100))
            task.is_active = bool(request.form.get('is_active'))
            task.priority = int(request.form.get('priority', 1))
            
            db.session.commit()
            
            log_action('edit_task', 'task', task.id, f'Отредактирована задача: {task.title}')
            flash('Задача успешно обновлена!', 'success')
            return redirect(url_for('tasks'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка обновления задачи: {str(e)}', 'error')
    
    return render_template('task_form.html', task=task)

@app.route('/tasks/<int:task_id>/toggle', methods=['POST'])
@login_required
def toggle_task(task_id):
    try:
        task = Task.query.get_or_404(task_id)
        task.is_active = not task.is_active
        db.session.commit()
        
        status = 'активирована' if task.is_active else 'деактивирована'
        log_action('toggle_task', 'task', task.id, f'Задача {status}: {task.title}')
        flash(f'Задача {status}!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка изменения статуса задачи: {str(e)}', 'error')
    
    return redirect(url_for('tasks'))

# Поддерживаем старый формат URL для совместимости
@app.route('/tasks/delete/<int:task_id>', methods=['POST'])
@app.route('/tasks/<int:task_id>/delete', methods=['POST'])
@login_required
def delete_task(task_id):
    try:
        task = Task.query.get_or_404(task_id)
        title = task.title
        db.session.delete(task)
        db.session.commit()
        
        log_action('delete_task', 'task', task_id, f'Удалена задача: {title}')
        flash('Задача успешно удалена!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка удаления задачи: {str(e)}', 'error')
    
    return redirect(url_for('tasks'))

@app.route('/submissions')
@login_required
def submissions():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        # Фильтры
        status_filter = request.args.get('status', '')
        
        query = Submission.query
        
        if status_filter:
            query = query.filter_by(status=status_filter)
        
        submissions = query.order_by(desc(Submission.submission_time)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        # Получаем информацию о пользователях и задачах
        for submission in submissions.items:
            submission.user = User.query.filter_by(user_id=submission.user_id).first()
            submission.task = Task.query.get(submission.task_id)
        
        return render_template('submissions.html', submissions=submissions, status_filter=status_filter)
        
    except Exception as e:
        flash(f'Ошибка загрузки подач: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

# Поддерживаем старый формат обработки подач
@app.route('/submissions/process/<int:submission_id>/<action>', methods=['POST'])
@login_required
def process_submission_old(submission_id, action):
    if action == 'approve':
        return approve_submission(submission_id)
    elif action == 'reject':
        return reject_submission(submission_id)
    else:
        flash('Неизвестное действие', 'error')
        return redirect(url_for('submissions'))

# УДАЛЕНО: дублирующаяся функция одобрения (есть в ADMINPANEL)
@app.route('/submissions/<int:submission_id>/reject', methods=['POST'])
@login_required
def reject_submission(submission_id):
    try:
        submission = Submission.query.get_or_404(submission_id)
        submission.status = 'rejected'
        submission.review_time = datetime.datetime.utcnow()
        submission.reviewer_id = current_user.id
        submission.rejection_reason = request.form.get('reason', 'Не указана')
        
        db.session.commit()
        
        log_action('reject_submission', 'submission', submission_id, 
                  f'Отклонена подача пользователя {submission.user_id}. Причина: {submission.rejection_reason}')
        flash('Подача отклонена!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка отклонения подачи: {str(e)}', 'error')
    
    return redirect(url_for('submissions'))

@app.route('/users')
@login_required
def users():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        # Фильтры
        status_filter = request.args.get('status', '')
        search = request.args.get('search', '')
        
        query = User.query
        
        if status_filter == 'banned':
            query = query.filter_by(is_banned=True)
        elif status_filter == 'active':
            query = query.filter_by(is_banned=False, is_active=True)
        elif status_filter == 'inactive':
            query = query.filter_by(is_active=False)
        
        if search:
            query = query.filter(
                or_(
                    User.username.ilike(f'%{search}%'),
                    User.full_name.ilike(f'%{search}%'),
                    User.user_id == search if search.isdigit() else False
                )
            )
        
        users = query.order_by(desc(User.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('users.html', users=users, 
                             status_filter=status_filter, search=search)
                             
    except Exception as e:
        flash(f'Ошибка загрузки пользователей: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

@app.route('/users/ban/<int:user_id>', methods=['POST'])
@login_required
def ban_user(user_id):
    try:
        user = User.query.filter_by(user_id=user_id).first_or_404()
        user.is_banned = True
        user.ban_reason = request.form.get('reason', 'Нарушение правил')
        
        db.session.commit()
        
        log_action('ban_user', 'user', user_id, f'Заблокирован пользователь {user.username}. Причина: {user.ban_reason}')
        flash(f'Пользователь {user.username} заблокирован!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка блокировки пользователя: {str(e)}', 'error')
    
    return redirect(url_for('users'))

@app.route('/users/unban/<int:user_id>', methods=['POST'])
@login_required
def unban_user(user_id):
    try:
        user = User.query.filter_by(user_id=user_id).first_or_404()
        user.is_banned = False
        user.ban_reason = None
        
        db.session.commit()
        
        log_action('unban_user', 'user', user_id, f'Разблокирован пользователь {user.username}')
        flash(f'Пользователь {user.username} разблокирован!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка разблокировки пользователя: {str(e)}', 'error')
    
    return redirect(url_for('users'))

@app.route('/payouts')
@login_required
def payouts():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        # Фильтры
        status_filter = request.args.get('status', '')
        
        query = WithdrawRequest.query
        
        if status_filter:
            query = query.filter_by(status=status_filter)
        
        payouts = query.order_by(desc(WithdrawRequest.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        # Получаем информацию о пользователях
        for payout in payouts.items:
            payout.user = User.query.filter_by(user_id=payout.user_id).first()
        
        return render_template('payouts.html', payouts=payouts, status_filter=status_filter)
        
    except Exception as e:
        flash(f'Ошибка загрузки выплат: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

@app.route('/payouts/approve/<int:request_id>', methods=['POST'])
@login_required
def approve_payout(request_id):
    try:
        payout = WithdrawRequest.query.get_or_404(request_id)
        payout.status = 'approved'
        payout.processed_at = datetime.datetime.utcnow()
        payout.processor_id = current_user.id
        
        db.session.commit()
        
        log_action('approve_payout', 'payout', request_id, f'Одобрена выплата на сумму {payout.amount}')
        flash('Выплата одобрена!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка одобрения выплаты: {str(e)}', 'error')
    
    return redirect(url_for('payouts'))

@app.route('/payouts/mark_paid/<int:request_id>', methods=['POST'])
@login_required
def mark_paid_payout(request_id):
    try:
        payout = WithdrawRequest.query.get_or_404(request_id)
        payout.status = 'paid'
        payout.processed_time = datetime.datetime.utcnow()
        payout.transaction_id = request.form.get('transaction_id', '')
        payout.notes = request.form.get('notes', '')
        
        db.session.commit()
        
        log_action('mark_paid_payout', 'payout', request_id, f'Отмечена как выплаченная сумма {payout.amount}')
        flash('Выплата отмечена как выплаченная!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка отметки выплаты: {str(e)}', 'error')
    
    return redirect(url_for('payouts'))

@app.route('/payouts/reject/<int:request_id>', methods=['POST'])
@login_required
def reject_payout(request_id):
    try:
        payout = WithdrawRequest.query.get_or_404(request_id)
        payout.status = 'rejected'
        payout.processed_at = datetime.datetime.utcnow()
        payout.processor_id = current_user.id
        payout.notes = request.form.get('reason', 'Не указана причина')
        
        # Возвращаем деньги пользователю
        user = User.query.filter_by(user_id=payout.user_id).first()
        if user:
            user.balance += payout.amount
        
        db.session.commit()
        
        log_action('reject_payout', 'payout', request_id, f'Отклонена выплата на сумму {payout.amount}. Причина: {payout.notes}')
        flash('Выплата отклонена, средства возвращены пользователю!', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка отклонения выплаты: {str(e)}', 'error')
    
    return redirect(url_for('payouts'))

@app.route('/analytics')
@login_required
def analytics():
    try:
        # Общая статистика
        total_users = User.query.count()
        total_tasks = Task.query.count()
        total_submissions = Submission.query.count()
        total_paid_payouts = WithdrawRequest.query.filter_by(status='paid').count()
        
        # Статистика по дням (за последние 30 дней) 
        end_date = datetime.datetime.utcnow()
        start_date = end_date - timedelta(days=30)
        
        # Регистрации по дням
        daily_registrations = db.session.query(
            func.date(User.created_at).label('date'),
            func.count(User.user_id).label('count')
        ).filter(
            User.created_at >= start_date
        ).group_by(func.date(User.created_at)).all()
        
        # Подачи по дням
        daily_submissions = db.session.query(
            func.date(Submission.submission_time).label('date'),
            func.count(Submission.id).label('count')
        ).filter(
            Submission.submission_time >= start_date
        ).group_by(func.date(Submission.submission_time)).all()
        
        return render_template('analytics.html',
                             total_users=total_users,
                             total_tasks=total_tasks,
                             total_submissions=total_submissions,
                             total_payouts=total_paid_payouts,
                             daily_registrations=daily_registrations,
                             daily_submissions=daily_submissions)
                             
    except Exception as e:
        flash(f'Ошибка загрузки аналитики: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

# Поддерживаем оба формата настроек
@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        try:
            # Обновляем настройки
            for key, value in request.form.items():
                if key.startswith('setting_'):
                    setting_key = key.replace('setting_', '')
                    setting = SystemSettings.query.filter_by(setting_key=setting_key).first()
                    
                    if setting:
                        setting.setting_value = value
                        setting.updated_at = datetime.datetime.utcnow()
                        setting.updated_by = current_user.id
                    else:
                        setting = SystemSettings(
                            setting_key=setting_key,
                            setting_value=value,
                            updated_at=datetime.datetime.utcnow(),
                            updated_by=current_user.id
                        )
                        db.session.add(setting)
            
            db.session.commit()
            log_action('update_settings', details='Обновлены системные настройки')
            flash('Настройки успешно обновлены!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка обновления настроек: {str(e)}', 'error')
    
    # Получаем текущие настройки
    settings_list = SystemSettings.query.all()
    settings_dict = {s.setting_key: s.setting_value for s in settings_list}
    
    return render_template('settings.html', settings=settings_dict)

# Поддерживаем старый формат обновления настроек
@app.route('/settings/update', methods=['POST'])
@login_required
def update_settings():
    return settings()

@app.route('/logs')
@login_required
def logs():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 50
        
        logs = SystemLog.query.order_by(desc(SystemLog.timestamp)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('logs.html', logs=logs)
        
    except Exception as e:
        flash(f'Ошибка загрузки логов: {str(e)}', 'error')
        return render_template('error.html', error=str(e))

# --- API ЭНДПОИНТЫ ДЛЯ ГРАФИКОВ ---

@app.route('/api/stats/daily_submissions')
@login_required
def api_daily_submissions():
    try:
        end_date = datetime.datetime.utcnow()
        start_date = end_date - timedelta(days=30)
        
        daily_stats = db.session.query(
            func.date(Submission.submission_time).label('date'),
            func.count(case([(Submission.status == 'pending', 1)])).label('pending'),
            func.count(case([(Submission.status == 'approved', 1)])).label('approved'),
            func.count(case([(Submission.status == 'rejected', 1)])).label('rejected')
        ).filter(
            Submission.submission_time >= start_date
        ).group_by(func.date(Submission.submission_time)).all()
        
        result = []
        for stat in daily_stats:
            result.append({
                'date': stat.date.strftime('%Y-%m-%d'),
                'pending': stat.pending,
                'approved': stat.approved,
                'rejected': stat.rejected
            })
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats/platform_distribution')
@login_required
def api_platform_distribution():
    try:
        platform_stats = db.session.query(
            Task.platform,
            func.count(Task.id).label('count')
        ).group_by(Task.platform).all()
        
        result = []
        for stat in platform_stats:
            result.append({
                'platform': stat.platform,
                'count': stat.count
            })
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats/earnings_timeline')
@login_required
def api_earnings_timeline():
    try:
        end_date = datetime.datetime.utcnow()
        start_date = end_date - timedelta(days=30)
        
        earnings_stats = db.session.query(
            func.date(WithdrawRequest.processed_time).label('date'),
            func.sum(WithdrawRequest.amount).label('total')
        ).filter(
            WithdrawRequest.status == 'paid',
            WithdrawRequest.processed_time >= start_date
        ).group_by(func.date(WithdrawRequest.processed_time)).all()
        
        result = []
        for stat in earnings_stats:
            result.append({
                'date': stat.date.strftime('%Y-%m-%d'),
                'total': float(stat.total) if stat.total else 0
            })
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# --- ЭКСПОРТ ДАННЫХ ---

@app.route('/export/users')
@login_required
def export_users():
    try:
        users = User.query.all()
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # CSV заголовки
        writer.writerow([
            'ID', 'Username', 'Full Name', 'Balance', 'Total Earnings',
            'Created At', 'Is Banned', 'Is Active'
        ])
        
        # Данные пользователей
        for user in users:
            writer.writerow([
                user.user_id,
                user.username or '',
                user.full_name or '',
                user.balance or 0,
                user.total_earnings or 0,
                user.created_at.strftime('%Y-%m-%d %H:%M:%S') if user.created_at else '',
                'Да' if user.is_banned else 'Нет',
                'Да' if user.is_active else 'Нет'
            ])
        
        output.seek(0)
        
        log_action('export_users', details='Экспорт списка пользователей')
        
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=f'users_export_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        )
        
    except Exception as e:
        flash(f'Ошибка экспорта пользователей: {str(e)}', 'error')
        return redirect(url_for('users'))

# --- ОБРАБОТКА ОШИБОК ---


@app.route('/create-first-admin-temp')
def create_first_admin_temp():
    try:
        # Проверяем, есть ли уже админы
        existing_admin = Admin.query.first()
        if existing_admin:
            return "Администратор уже существует!"
        
        # Создаем первого админа
        admin = Admin(
            username='admin',
            password=generate_password_hash('admin123'),
            role='superadmin',
            email='admin@seoserm.com'
        )
        
        db.session.add(admin)
        db.session.commit()
        
        return "Создан первый администратор! Логин: admin, Пароль: admin123"
        
    except Exception as e:
        return f"Ошибка создания администратора: {str(e)}"

if __name__ == '__main__':
    with app.app_context():
        try:
            db.create_all()
            print("База данных инициализирована")
        except Exception as e:
            print(f"Ошибка инициализации БД: {e}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
