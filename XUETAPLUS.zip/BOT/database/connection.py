"""
Модуль для работы с соединениями к базе данных
"""

import psycopg2
import psycopg2.extras
import logging
import os
from config.settings import DATABASE_CONFIG

def get_connection():
    """Получить соединение с базой данных"""
    try:
        connection = psycopg2.connect(
            host=DATABASE_CONFIG['host'],
            database=DATABASE_CONFIG['database'],
            user=DATABASE_CONFIG['user'],
            password=DATABASE_CONFIG['password'],
            port=DATABASE_CONFIG['port']
        ,
            connect_timeout=int(os.getenv('DB_CONNECT_TIMEOUT', '5'))
        )
        return connection
    except Exception as e:
        logging.error(f"Ошибка подключения к БД: {e}")
        return None

def get_db_connection():
    """Альтернативное название для совместимости"""
    return get_connection()
