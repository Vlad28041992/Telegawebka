"""
Модуль для работы с базой данных
"""

import logging
import psycopg2
import psycopg2.extras
import logging
import time
import datetime
from config.settings import DATABASE_CONFIG, MIN_WITHDRAWAL_AMOUNT, REFERRAL_REWARD_LEVEL_1, REFERRAL_REWARD_LEVEL_2

def get_db_connection():
    """Получить соединение с базой данных"""
    try:
        connection = psycopg2.connect(
            host=DATABASE_CONFIG['host'],
            database=DATABASE_CONFIG['database'],
            user=DATABASE_CONFIG['user'],
            password=DATABASE_CONFIG['password'],
            port=DATABASE_CONFIG['port']
        )
        return connection
    except Exception as e:
        logging.error(f"Ошибка подключения к БД: {e}")
        return None

def init_db_sync():
    """Синхронная инициализация БД"""
    try:
        connection = get_db_connection()
        if connection:
            logging.info("Соединение с БД установлено")
            connection.close()
            return True
        return False
    except Exception as e:
        logging.error(f"Ошибка инициализации БД: {e}")
        return False

def get_user(user_id):
    """Получить пользователя по ID"""
    try:
        connection = get_db_connection()
        if not connection:
            return None
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        cursor.execute(
            "SELECT * FROM users WHERE user_id = %s",
            (user_id,)
        )
        
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        return dict(result) if result else None
        
    except Exception as e:
        logging.error(f"Ошибка получения пользователя {user_id}: {e}")
        return None

def add_user(user_id, username=None, full_name=None, referrer_id=None):
    """Добавить нового пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute(
            """INSERT INTO users (user_id, username, full_name, balance, points, 
                                 total_points, total_earnings, earnings_from_tasks, 
                                 earnings_from_referrals, referrer_id, created_at, 
                                 is_active, email) 
               VALUES (%s, %s, %s, 0, 0, 0, 0, 0, 0, %s, %s, true, %s)
               ON CONFLICT (user_id) DO UPDATE SET
                 username = EXCLUDED.username,
                 full_name = EXCLUDED.full_name""",
            (user_id, username, full_name, referrer_id, datetime.datetime.utcnow(), f"user_{user_id}@temp.email")
        )
        
        # Обновляем счетчики рефералов у пригласивших
        try:
            if referrer_id and referrer_id != user_id:
                cursor.execute(
                    "UPDATE users SET referral_1_level = COALESCE(referral_1_level,0)+1, "
                    "referrals_level_1 = COALESCE(referrals_level_1,0)+1 WHERE user_id=%s",
                    (referrer_id,)
                )
                cursor.execute("SELECT referrer_id FROM users WHERE user_id=%s", (referrer_id,))
                row = cursor.fetchone()
                if row and row[0]:
                    cursor.execute(
                        "UPDATE users SET referral_2_level = COALESCE(referral_2_level,0)+1, "
                        "referrals_level_2 = COALESCE(referrals_level_2,0)+1 WHERE user_id=%s",
                        (row[0],)
                    )
        except Exception as _e:
            logging.warning(f'Не удалось обновить счетчики рефералов: {_e}')
        
        
        # Contest: register candidate referral if active
        try:
            from config.settings import CONTEST_ACTIVE, CONTEST_ID
            if referrer_id and referrer_id != user_id and CONTEST_ACTIVE:
                try:
                    cursor.execute("""
                        INSERT INTO referral_contest_referrals (contest_id, referrer_id, referred_user_id, status)
                        VALUES (%s, %s, %s, 'pending')
                        ON CONFLICT (contest_id, referred_user_id) DO NOTHING
                    """, (CONTEST_ID, referrer_id, user_id))
                    cursor.execute("""
                        INSERT INTO referral_contest_stats (contest_id, referrer_id, pending_count)
                        VALUES (%s, %s, 1)
                        ON CONFLICT (contest_id, referrer_id) DO UPDATE SET
                            pending_count = referral_contest_stats.pending_count + 1,
                            updated_at = NOW()
                    """, (CONTEST_ID, referrer_id))
                except Exception as ce:
                    logging.warning(f'contest candidate failed: {ce}')
        except Exception as _e:
            logging.warning(f'contest settings missing: {_e}')
    
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Пользователь {user_id} создан/обновлен")
        return True
    except Exception as e:
        logging.error(f"Ошибка создания пользователя {user_id}: {e}")
        try:
            if 'connection' in locals() and connection:
                connection.rollback()
        except Exception:
            pass
        try:
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'connection' in locals() and connection:
                connection.close()
        except Exception:
            pass
        return False

def release_task(user_id):
    """Освободить задание пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        cursor.execute(
            "UPDATE users SET assigned_task_id = NULL, assigned_task_time = NULL WHERE user_id = %s",
            (user_id,)
        )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Задание пользователя {user_id} освобождено")
        return True
    except Exception as e:
        logging.error(f"Ошибка освобождения задания пользователя {user_id}: {e}")
        return False

def create_user(user_id, username=None, full_name=None, referrer_id=None):
    """Создать нового пользователя (алиас для add_user)"""
    return add_user(user_id, username, full_name, referrer_id)

def get_user_by_id(user_id):
    """Получить пользователя по ID (алиас для get_user)"""
    return get_user(user_id)

def get_user_balance(user_id):
    """Получить баланс пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return 0
            
        cursor = connection.cursor()
        
        cursor.execute("SELECT balance FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        
        cursor.close()
        connection.close()
        
        return result[0] if result else 0
    except Exception as e:
        logging.error(f"Ошибка получения баланса пользователя {user_id}: {e}")
        return 0

def update_user_balance(user_id, new_balance):
    """Обновить баланс пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        cursor.execute(
            "UPDATE users SET balance = %s WHERE user_id = %s",
            (new_balance, user_id)
        )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        return True
    except Exception as e:
        logging.error(f"Ошибка обновления баланса пользователя {user_id}: {e}")
        return False

def add_balance_transaction(user_id, amount, operation_type, related_id=None):
    """Добавить транзакцию баланса"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        cursor.execute(
            """INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at) 
               VALUES (%s, %s, %s, %s, %s)""",
            (user_id, amount, operation_type, related_id, int(time.time()))
        )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        return True
    except Exception as e:
        logging.error(f"Ошибка добавления транзакции для пользователя {user_id}: {e}")
        return False

def get_user_stats(user_id):
    """Получить статистику пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return default_user_stats()
            
        cursor = connection.cursor()
        
        cursor.execute(
            """SELECT balance, total_points, total_earnings, earnings_from_tasks, 
                      earnings_from_referrals, referrals_level_1, referrals_level_2
               FROM users WHERE user_id = %s""",
            (user_id,)
        )
        
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        if result:
            return {
                'balance': result[0] or 0,
                'total_points': result[1] or 0,
                'total_earnings': result[2] or 0,
                'earnings_from_tasks': result[3] or 0,
                'earnings_from_referrals': result[4] or 0,
                'referrals_level_1': result[5] or 0,
                'referrals_level_2': result[6] or 0
            }
        return default_user_stats()
        
    except Exception as e:
        logging.error(f"Ошибка получения статистики пользователя {user_id}: {e}")
        return default_user_stats()

def default_user_stats():
    """Статистика по умолчанию"""
    return {
        'balance': 0, 'total_points': 0, 'total_earnings': 0,
        'earnings_from_tasks': 0, 'earnings_from_referrals': 0,
        'referrals_level_1': 0, 'referrals_level_2': 0
    }

def update_user_activity(user_id):
    """Обновить активность пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        cursor.execute(
            "UPDATE users SET last_activity = %s WHERE user_id = %s",
            (datetime.datetime.utcnow(), user_id)
        )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        return True
    except Exception as e:
        logging.error(f"Ошибка обновления активности пользователя {user_id}: {e}")
        return False

def get_user_tasks(user_id):
    """Получить задания пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return []
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        cursor.execute(
            """SELECT t.*, 
                      CASE 
                          WHEN s.status IS NOT NULL THEN s.status 
                          ELSE 'not_submitted' 
                      END as submission_status
               FROM tasks t
               LEFT JOIN submissions s ON t.id = s.task_id AND s.user_id = %s
               WHERE t.is_active = true
               ORDER BY t.created_at DESC""",
            (user_id,)
        )
        
        results = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return [dict(row) for row in results] if results else []
        
    except Exception as e:
        logging.error(f"Ошибка получения заданий для пользователя {user_id}: {e}")
        return []

def submit_task(user_id, task_id, fio, screenshot_url, notes=None):
    """Отправить задание на проверку"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        # 1. Создаем submission
        cursor.execute(
            """INSERT INTO submissions (user_id, task_id, fio, screenshot_url, notes, status, submitted_at, created_at)
               VALUES (%s, %s, %s, %s, %s, 'pending', %s, %s)
               RETURNING id""",
            (user_id, task_id, fio, screenshot_url, notes, datetime.datetime.utcnow(), datetime.datetime.utcnow())
        )
        
        submission_id = cursor.fetchone()[0]
        
        # 2. ЛОГИКА КОНКУРСА - переводим pending -> hold
        from config.settings import CONTEST_ACTIVE, CONTEST_ID
        
        if CONTEST_ACTIVE:
            # Проверяем, есть ли этот пользователь среди рефералов в статусе pending
            cursor.execute(
                """UPDATE referral_contest_referrals 
                SET status = 'hold',
                    first_submission_id = %s,
                    first_submission_at = NOW(),
                    updated_at = NOW()
                WHERE contest_id = %s 
                    AND referred_user_id = %s 
                    AND status = 'pending'
                RETURNING referrer_id""",
                (submission_id, CONTEST_ID, user_id)
            )
            
            result = cursor.fetchone()
            if result:
                referrer_id = result[0]
                logging.info(f"Конкурс: реферал {user_id} переведен в hold, реферер {referrer_id}")
                
                # Обновляем статистику: pending_count - 1, hold_count + 1
                cursor.execute(
                    """UPDATE referral_contest_stats 
                    SET pending_count = GREATEST(0, pending_count - 1),
                        hold_count = hold_count + 1,
                        updated_at = NOW()
                    WHERE contest_id = %s AND referrer_id = %s""",
                    (CONTEST_ID, referrer_id)
                )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        return True
    except Exception as e:
        logging.error(f"Ошибка отправки задания {task_id} пользователем {user_id}: {e}")
        if connection:
            connection.rollback()
            connection.close()
        return False


def get_user_submissions(user_id):
    """Получить заявки пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return []
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        cursor.execute(
            """SELECT s.*, t.title, t.platform, t.reward_money
               FROM submissions s
               JOIN tasks t ON s.task_id = t.id
               WHERE s.user_id = %s
               ORDER BY s.submitted_at DESC""",
            (user_id,)
        )
        
        results = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return [dict(row) for row in results] if results else []
        
    except Exception as e:
        logging.error(f"Ошибка получения заявок пользователя {user_id}: {e}")
        return []

def create_withdrawal_request(user_id, amount, method, details):
    """Создать запрос на вывод средств в withdraw_requests с заморозкой средств"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = connection.cursor()
        cursor.execute("SELECT balance FROM users WHERE user_id = %s FOR UPDATE", (user_id,))
        row = cursor.fetchone()
        if not row or (row[0] or 0) < amount:
            cursor.close(); connection.close(); return False
        cursor.execute(
            """
            INSERT INTO withdraw_requests (user_id, amount, method, details, status, request_time, created_at)
            VALUES (%s, %s, %s, %s, 'pending', NOW(), EXTRACT(EPOCH FROM NOW())::bigint ::bigint)
            RETURNING id
            """,
            (user_id, amount, method, details)
        )
        wid = cursor.fetchone()[0]
        cursor.execute("UPDATE users SET balance = balance - %s WHERE user_id = %s", (amount, user_id))
        try:
            log_balance_transaction(user_id, -amount, 'withdraw_request', wid)
        except Exception:
            pass
        connection.commit(); cursor.close(); connection.close(); return True
    except Exception as e:
        logging.error(f"Ошибка создания запроса на вывод для пользователя {user_id}: {e}")
        try:
            connection.rollback(); connection.close()
        except Exception:
            pass
        return False

def get_user_referrals(user_id):
    """Получить рефералов пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return {'level_1': [], 'level_2': []}
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        # Рефералы 1 уровня
        cursor.execute(
            """SELECT user_id, username, full_name, total_earnings, created_at
               FROM users WHERE referrer_id = %s
               ORDER BY created_at DESC""",
            (user_id,)
        )
        level_1 = [dict(row) for row in cursor.fetchall()]
        
        # Рефералы 2 уровня
        level_1_ids = [ref['user_id'] for ref in level_1]
        level_2 = []
        
        if level_1_ids:
            cursor.execute(
                """SELECT user_id, username, full_name, total_earnings, created_at
                   FROM users WHERE referrer_id = ANY(%s)
                   ORDER BY created_at DESC""",
                (level_1_ids,)
            )
            level_2 = [dict(row) for row in cursor.fetchall()]
        
        cursor.close()
        connection.close()
        
        return {'level_1': level_1, 'level_2': level_2}
        
    except Exception as e:
        logging.error(f"Ошибка получения рефералов пользователя {user_id}: {e}")
        return {'level_1': [], 'level_2': []}

def populate_achievements():
    """Заполнить таблицу достижений - БЕЗ ОШИБОК ДУБЛИРОВАНИЯ"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        # Проверяем, есть ли уже записи в таблице
        cursor.execute("SELECT COUNT(*) FROM achievements")
        count = cursor.fetchone()[0]
        
        if count > 0:
            logging.info("Достижения уже существуют в БД, пропускаем добавление")
            cursor.close()
            connection.close()
            return True
        
        # Используем уникальные значения для required_tasks
        achievements = [
            ("Первые шаги", "Зарегистрируйтесь в боте", 1, 10, "🎯", 0, 0, 50),
            ("Активист", "Выполните 5 заданий", 5, 50, "⚡", 0, 5, 0),
            ("Профессионал", "Выполните 20 заданий", 20, 200, "🏆", 0, 20, 0),
            ("Мастер", "Выполните 50 заданий", 50, 500, "👑", 0, 50, 0),
            ("Богач", "Заработайте 1000 рублей", 100, 100, "💰", 1000, 0, 0),  # Changed required_tasks to 100
            ("Миллионер", "Заработайте 10000 рублей", 1000, 1000, "💎", 10000, 0, 0),  # Changed required_tasks to 1000
        ]
        
        for achievement in achievements:
            try:
                cursor.execute(
                    """INSERT INTO achievements (name, description, required_tasks, reward_points, 
                                              icon, points_required, tasks_required, reward_money)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                    achievement
                )
            except Exception as e:
                logging.warning(f"Пропускаем достижение {achievement[0]}: {e}")
                continue
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info("Достижения успешно добавлены в БД")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка добавления достижений: {e}")
        if 'connection' in locals():
            connection.rollback()
            connection.close()
        return False

def check_user_achievements(user_id):
    """Проверить достижения пользователя"""
    try:
        user_stats = get_user_stats(user_id)
        if not user_stats:
            return []
        
        connection = get_db_connection()
        if not connection:
            return []
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        # Получаем все достижения
        cursor.execute("SELECT * FROM achievements")
        achievements = cursor.fetchall()
        
        # Получаем уже полученные достижения пользователя
        cursor.execute(
            """SELECT achievement_id FROM user_achievements ua
               JOIN users u ON ua.user_id = u.id
               WHERE u.user_id = %s""",
            (user_id,)
        )
        completed_achievements = [row[0] for row in cursor.fetchall()]
        
        new_achievements = []
        
        for achievement in achievements:
            if achievement['id'] in completed_achievements:
                continue
                
            # Проверяем условия достижения
            earned = False
            
            if achievement['tasks_required'] and achievement['tasks_required'] > 0:
                # Считаем выполненные задания
                cursor.execute(
                    """SELECT COUNT(*) FROM submissions s
                       WHERE s.user_id = %s AND s.status = 'approved'""",
                    (user_id,)
                )
                completed_tasks = cursor.fetchone()[0]
                
                if completed_tasks >= achievement['tasks_required']:
                    earned = True
                    
            elif achievement['points_required'] and achievement['points_required'] > 0:
                if user_stats['total_earnings'] >= achievement['points_required']:
                    earned = True
            
            if earned:
                new_achievements.append(dict(achievement))
        
        cursor.close()
        connection.close()
        
        return new_achievements
        
    except Exception as e:
        logging.error(f"Ошибка проверки достижений пользователя {user_id}: {e}")
        return []


def is_admin(user_id):
    """Проверить, является ли пользователь администратором"""
    try:
        from config.settings import ADMINS
        return user_id in ADMINS
    except Exception as e:
        logging.error(f"Ошибка проверки админа {user_id}: {e}")
        return False

def log_balance_transaction(user_id, amount, transaction_type, description=None):
    """Логировать транзакцию баланса"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        cursor.execute(
            """INSERT INTO balance_transactions 
               (user_id, amount, operation_type, created_at) 
               VALUES (%s, %s, %s, %s)""",
            (user_id, amount, transaction_type, int(time.time()))
        )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Транзакция логирована: пользователь {user_id}, сумма {amount}, тип {transaction_type}")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка логирования транзакции: {e}")
        if connection:
            connection.rollback()
            connection.close()
        return False

def approve_submission(submission_id, admin_id):
    """Одобрить заявку на выполнение задания с реферальными начислениями"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        # Получаем информацию о заявке
        cursor.execute(
            """SELECT user_id, task_id FROM submissions WHERE id = %s""",
            (submission_id,)
        )
        submission_data = cursor.fetchone()
        
        if not submission_data:
            logging.error(f"Заявка {submission_id} не найдена")
            return False
            
        user_id, task_id = submission_data
        
        # Получаем информацию о задании для определения награды
        cursor.execute(
            """SELECT reward_money, reward_points FROM unified_tasks WHERE id = %s
               UNION
               SELECT reward_money, reward_points FROM tasks WHERE id = %s""",
            (task_id, task_id)
        )
        task_data = cursor.fetchone()
        
        if not task_data:
            logging.error(f"Задание {task_id} не найдено")
            return False
            
        reward_money, reward_points = task_data
        
        # IDEMPOTENCY_GUARD: skip if already processed in balance_transactions
        cursor.execute("SELECT 1 FROM balance_transactions WHERE operation_type='task_reward' AND related_id=%s LIMIT 1", (submission_id,))
        if cursor.fetchone():
            logging.info(f'Task reward already processed for submission {submission_id}, skipping')
            connection.commit()
            cursor.close()
            connection.close()
            return True

# Обновляем статус заявки
        cursor.execute(
            """UPDATE submissions 
               SET status = 'approved', approved_at = NOW(), reviewer_id = %s 
               WHERE id = %s""",
            (admin_id, submission_id)
        )
        
        # Обновляем баланс пользователя
        if reward_money:
            cursor.execute(
                """UPDATE users 
                   SET balance = balance + %s, total_earnings = total_earnings + %s,
                       earnings_from_tasks = earnings_from_tasks + %s
                   WHERE user_id = %s""",
                (reward_money, reward_money, reward_money, user_id)
            )
            
            # Логируем транзакцию основной выплаты
            cursor.execute(
                """INSERT INTO balance_transactions 
                   (user_id, amount, operation_type, related_id, created_at) 
                   VALUES (%s, %s, 'task_reward', %s, %s)""",
                (user_id, reward_money, submission_id, int(time.time()))
            )
            
            # Реферальные начисления обрабатываются в HTTP API
        # Обновляем очки пользователя
        if reward_points:
            cursor.execute(
                """UPDATE users 
                   SET points = points + %s, total_points = total_points + %s
                   WHERE user_id = %s""",
                (reward_points, reward_points, user_id)
            )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Заявка {submission_id} одобрена админом {admin_id} с реферальными начислениями")
        # Автоматически проверяем и завершаем задания с достигнутым лимитом
        try:
            auto_complete_tasks_at_limit()
        except Exception as e:
            logging.error(f"Ошибка автопроверки заданий: {e}")
        
        return True
        
    except Exception as e:
        logging.error(f"Ошибка одобрения заявки {submission_id}: {e}")
        if connection:
            connection.rollback()
            connection.close()
        return False

def reject_submission(submission_id, admin_id, reason=None):
    """Отклонить заявку на выполнение задания"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        # IDEMPOTENCY_GUARD: skip if already processed in balance_transactions
        cursor.execute("SELECT 1 FROM balance_transactions WHERE operation_type='task_reward' AND related_id=%s LIMIT 1", (submission_id,))
        if cursor.fetchone():
            logging.info(f'Task reward already processed for submission {submission_id}, skipping')
            connection.commit()
            cursor.close()
            connection.close()
            return True

# Обновляем статус заявки
        cursor.execute(
            """UPDATE submissions 
               SET status = 'rejected', review_time = NOW(), reviewer_id = %s, rejection_reason = %s
               WHERE id = %s""",
            (admin_id, reason, submission_id)
        )
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Заявка {submission_id} отклонена админом {admin_id}")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка отклонения заявки {submission_id}: {e}")
        if connection:
            connection.rollback()
            connection.close()
        return False

def add_task_submission(user_id, task_id, fio, screenshot_url=None, notes=None):
    """Добавить заявку на выполнение задания"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        cursor.execute(
            """INSERT INTO submissions (user_id, task_id, fio, screenshot_url, notes, status, submitted_at, created_at) VALUES (%s, %s, %s, %s, %s, 'pending', NOW(), NOW()) RETURNING id""",
            (user_id, task_id, fio, screenshot_url, notes)
        )
        
        connection.commit()
        submission_id = cursor.fetchone()[0]
        cursor.close()
        connection.close()
        
        logging.info(f"Заявка {submission_id} создана для пользователя {user_id}")
        return submission_id
        
    except Exception as e:
        logging.error(f"Ошибка создания заявки: {e}")
        if connection:
            connection.rollback()
            connection.close()
        return False

def get_withdraw_request_by_id(request_id):
    """Получить заявку на вывод по ID"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT w.id, w.user_id, w.amount, w.method, w.details, w.status, 
                   w.request_time, w.processed_at, w.processor_id,
                   u.full_name, u.username, u.balance
            FROM withdraw_requests w
            LEFT JOIN users u ON w.user_id = u.user_id
            WHERE w.id = %s
        """, (request_id,))
        
        result = cursor.fetchone()
        return result
        
    except Exception as e:
        logging.error(f"Ошибка get_withdraw_request_by_id({request_id}): {e}")
        return None
    finally:
        if conn:
            conn.close()

def get_pending_withdrawals(limit=50):
    """Получить все ожидающие заявки на вывод"""
    try:
        conn = get_db_connection()  
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT w.id, w.user_id, w.amount, w.method, w.details, w.request_time,
                   u.full_name, u.username, u.balance
            FROM withdraw_requests w
            LEFT JOIN users u ON w.user_id = u.user_id
            WHERE w.status = 'pending'
            ORDER BY w.request_time ASC
            LIMIT %s
        """, (limit,))
        
        return cursor.fetchall()
        
    except Exception as e:
        logging.error(f"Ошибка get_pending_withdrawals: {e}")
        return []
    finally:
        if conn:
            conn.close()

def process_withdrawal(request_id, action, admin_id, reason=None):
    """
    Обработать заявку на вывод
    action: 'approve' или 'reject'
    """
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("BEGIN")
        
        # Получаем данные заявки с блокировкой
        cursor.execute("""
            SELECT user_id, amount, status FROM withdraw_requests 
            WHERE id = %s FOR UPDATE
        """, (request_id,))
        
        result = cursor.fetchone()
        if not result:
            conn.rollback()
            return False, "Заявка не найдена"
            
        user_id, amount, current_status = result
        
        if current_status != 'pending':
            conn.rollback() 
            return False, f"Заявка уже обработана (статус: {current_status})"
        
        if action == 'approve':
            # Одобряем заявку
            cursor.execute("""
                UPDATE withdraw_requests 
                SET status = 'approved', processed_at = NOW(), processor_id = %s,
                    notes = %s
                WHERE id = %s
            """, (admin_id, reason, request_id))
            
            conn.commit()
            return True, f"Заявка одобрена"
            
        elif action == 'reject':
            # Отклоняем и возвращаем средства
            cursor.execute("""
                UPDATE withdraw_requests 
                SET status = 'rejected', processed_at = NOW(), processor_id = %s,
                    notes = %s
                WHERE id = %s
            """, (admin_id, reason, request_id))
            
            cursor.execute("UPDATE users SET balance = balance + %s WHERE user_id = %s", (amount, user_id))
            log_balance_transaction(user_id, amount, 'withdraw_reject', request_id)
            
            conn.commit()
            return True, f"Заявка отклонена, {amount}₽ возвращены пользователю"
            
        else:
            conn.rollback()
            return False, f"Неизвестное действие: {action}"
            
    except Exception as e:
        logging.error(f"Ошибка process_withdrawal({request_id}, {action}): {e}")
        if conn:
            conn.rollback()
        return False, f"Ошибка БД: {str(e)}"
    finally:
        if conn:
            conn.close()

def get_withdrawal_statistics():
    """Получить статистику по выводам"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Общая статистика
        cursor.execute("""
            SELECT 
                status,
                COUNT(*) as count,
                COALESCE(SUM(amount), 0) as total_amount
            FROM withdraw_requests 
            GROUP BY status
        """)
        status_stats = cursor.fetchall()
        
        # За последние 30 дней
        cursor.execute("""
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(amount), 0) as amount
            FROM withdraw_requests 
            WHERE request_time >= NOW() - INTERVAL '30 days'
        """)
        monthly_stats = cursor.fetchone()
        
        # За последние 7 дней
        cursor.execute("""
            SELECT 
                COUNT(*) as count,
                COALESCE(SUM(amount), 0) as amount
            FROM withdraw_requests 
            WHERE request_time >= NOW() - INTERVAL '7 days'
        """)
        weekly_stats = cursor.fetchone()
        
        return {
            'status_stats': status_stats,
            'monthly': monthly_stats,
            'weekly': weekly_stats
        }
        
    except Exception as e:
        logging.error(f"Ошибка get_withdrawal_statistics: {e}")
        return None
    finally:
        if conn:
            conn.close()

def validate_withdrawal_amount(user_id, amount):
    """Валидация суммы вывода"""
    try:
        from config.settings import MIN_WITHDRAWAL_AMOUNT
        
        if amount < MIN_WITHDRAWAL_AMOUNT:
            return False, f"Минимальная сумма вывода: {MIN_WITHDRAWAL_AMOUNT}₽"
            
        if amount > 50000:
            return False, "Максимальная сумма вывода: 50000₽"
            
        user_balance = get_user_balance(user_id)
        if amount > user_balance:
            return False, f"Недостаточно средств. Баланс: {user_balance}₽"
            
        return True, "OK"
        
    except Exception as e:
        logging.error(f"Ошибка validate_withdrawal_amount: {e}")
        return False, "Ошибка валидации"

def create_withdrawal_request_safe(user_id, amount, method, details, bank_name=None):
    """Безопасное создание заявки на вывод с полной валидацией"""
    conn = None
    try:
        # Валидируем данные
        valid, message = validate_withdrawal_amount(user_id, amount)
        if not valid:
            return False, message, None
            
        if not details or len(details.strip()) < 5:
            return False, "Реквизиты должны содержать минимум 5 символов", None
            
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("BEGIN")
        
        # Блокируем строку пользователя
        cursor.execute("SELECT balance FROM users WHERE user_id = %s FOR UPDATE", (user_id,))
        balance_row = cursor.fetchone()
        
        if not balance_row:
            conn.rollback()
            return False, "Пользователь не найден в системе", None
            
        current_balance = balance_row[0]
        
        if current_balance < amount:
            conn.rollback()
            return False, f"Недостаточно средств. Баланс: {current_balance}₽", None
            
        # Списываем средства
        cursor.execute("UPDATE users SET balance = balance - %s WHERE user_id = %s", (amount, user_id))
        
        # Создаём заявку
        cursor.execute("""
            INSERT INTO withdraw_requests (user_id, amount, method, details, bank_name, status, request_time, created_at)
            VALUES (%s, %s, %s, %s, %s, 'pending', NOW(), EXTRACT(EPOCH FROM NOW())::bigint )
            RETURNING id
        """, (user_id, amount, method, details.strip(), bank_name))
        
        request_id = cursor.fetchone()[0]
        
        # Записываем транзакцию
        log_balance_transaction(user_id, -amount, 'withdraw_request', request_id)
        
        conn.commit()
        
        logging.info(f"Создана заявка на вывод #{request_id} для пользователя {user_id} на {amount}₽")
        
        return True, "Заявка успешно создана", request_id
        
    except Exception as e:
        logging.error(f"Ошибка create_withdrawal_request_safe: {e}")
        if conn:
            conn.rollback()
        return False, f"Техническая ошибка: {str(e)}", None
    finally:
        if conn:
            conn.close()

# Добавляем функцию для очистки старых данных
def cleanup_old_transactions():
    """Очистка старых транзакций (старше 1 года)"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            DELETE FROM balance_transactions 
            WHERE created_at < extract(epoch from (NOW() - INTERVAL '1 year'))
        """)
        
        deleted_count = cursor.rowcount
        conn.commit()
        
        logging.info(f"Очищено {deleted_count} старых транзакций")
        return deleted_count
        
    except Exception as e:
        logging.error(f"Ошибка cleanup_old_transactions: {e}")
        return 0
    finally:
        if conn:
            conn.close()



# ========== ИСПРАВЛЕНИЕ ЗАВИСАНИЯ ВЫПЛАТ ==========
def create_withdrawal_request_safe_fixed(user_id, amount, method, details, bank_name=None):
    """ИСПРАВЛЕННАЯ функция создания заявки БЕЗ ЗАВИСАНИЙ"""
    conn = None
    try:
        # Валидация
        if not all([user_id, amount, method, details]):
            return False, "Некорректные данные", None
        amount = int(amount)
        if not (MIN_WITHDRAWAL_AMOUNT <= amount <= 50000):
            return False, "Сумма должна быть от {MIN_WITHDRAWAL_AMOUNT}₽ до 50000₽", None
        details = str(details).strip()
        if len(details) < 5:
            return False, "Реквизиты слишком короткие", None
        
        # Быстрое подключение с таймаутами
        conn = psycopg2.connect(host=DATABASE_CONFIG["host"], database=DATABASE_CONFIG["database"], user=DATABASE_CONFIG["user"], password=DATABASE_CONFIG["password"], port=DATABASE_CONFIG["port"], connect_timeout=3)
        conn.autocommit = False
        
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:
            cursor.execute("SET statement_timeout = '5s'")
            cursor.execute("SET lock_timeout = '2s'")
            cursor.execute("BEGIN")
            
            # Проверка баланса БЕЗ блокировки
            cursor.execute("SELECT balance FROM users WHERE user_id = %s", (user_id,))
            user_row = cursor.fetchone()
            if not user_row or user_row['balance'] < amount:
                conn.rollback()
                balance = user_row['balance'] if user_row else 0
                return False, f"Недостаточно средств. Баланс: {balance}₽", None
            
            # Проверка дубликатов
            cursor.execute("SELECT COUNT(*) as count FROM withdraw_requests WHERE user_id = %s AND status = 'pending'", (user_id,))
            if cursor.fetchone()['count'] > 0:
                conn.rollback()
                return False, "У вас уже есть ожидающая заявка", None
            
            # Атомарное обновление
            cursor.execute("UPDATE users SET balance = balance - %s WHERE user_id = %s AND balance >= %s", (amount, user_id, amount))
            if cursor.rowcount == 0:
                conn.rollback()
                return False, "Недостаточно средств", None
            
            # Создание заявки
            cursor.execute("""INSERT INTO withdraw_requests (user_id, amount, method, details, bank_name, status, request_time, created_at)
                VALUES (%s, %s, %s, %s, %s, 'pending', NOW(), EXTRACT(EPOCH FROM NOW())::bigint) RETURNING id""", 
                (user_id, amount, method, details, bank_name))
            request_id = cursor.fetchone()['id']
            conn.commit()
            
            logging.info(f"✅ Заявка #{request_id} создана для пользователя {user_id}")
            return True, "Заявка создана", request_id
    
    except psycopg2.errors.QueryCanceled:
        if conn: conn.rollback()
        return False, "Превышено время ожидания", None
    except psycopg2.errors.LockNotAvailable:
        if conn: conn.rollback()
        return False, "Система занята, попробуйте через 10 сек", None
    except Exception as e:
        if conn: conn.rollback()
        logging.error(f"Ошибка создания заявки: {e}")
        return False, "Техническая ошибка", None
    finally:
        if conn: conn.close()

# Заменяем функцию
create_withdrawal_request_safe = create_withdrawal_request_safe_fixed



# === Support ticket helpers ===

def create_support_ticket(user_id, username, full_name, subject, message, status='open'):
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO support_tickets (user_id, username, full_name, subject, message, status, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
            RETURNING id
            """,
            (user_id, username, full_name, subject, message, status)
        )
        ticket_id = cursor.fetchone()[0]
        cursor.execute(
            """
            INSERT INTO support_messages (ticket_id, sender, admin_id, message, created_at)
            VALUES (%s, %s, NULL, %s, NOW())
            """,
            (ticket_id, 'user', message)
        )
        connection.commit()
        cursor.close(); connection.close()
        return ticket_id
    except Exception as e:
        logging.error(f'create_support_ticket error: {e}')
        try:
            connection.rollback()
        except Exception:
            pass
        try:
            cursor.close(); connection.close()
        except Exception:
            pass
        return None

def add_support_message(ticket_id: int, sender: str, message: str, admin_id: int = None):
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO support_messages (ticket_id, sender, admin_id, message, created_at)
            VALUES (%s, %s, %s, %s, NOW()) RETURNING id
            """,
            (ticket_id, sender, admin_id, message)
        )
        msg_id = cursor.fetchone()[0]
        cursor.execute("UPDATE support_tickets SET updated_at = NOW() WHERE id=%s", (ticket_id,))
        connection.commit()
        cursor.close(); connection.close()
        return msg_id
    except Exception as e:
        logging.error(f'add_support_message error: {e}')
        try:
            connection.rollback()
        except Exception:
            pass
        try:
            cursor.close(); connection.close()
        except Exception:
            pass
        return None


def get_user_tickets(user_id: int, limit: int = 20):
    try:
        connection = get_db_connection()
        if not connection:
            return []
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(
            """
            SELECT id, subject, status, created_at, updated_at
            FROM support_tickets
            WHERE user_id=%s
            ORDER BY updated_at DESC
            LIMIT %s
            """,
            (user_id, limit)
        )
        rows = cursor.fetchall()
        cursor.close(); connection.close()
        return rows
    except Exception as e:
        logging.error(f'get_user_tickets error: {e}')
        return []


def get_ticket_by_id(ticket_id: int):
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("SELECT * FROM support_tickets WHERE id=%s", (ticket_id,))
        row = cursor.fetchone()
        cursor.close(); connection.close()
        return row
    except Exception as e:
        logging.error(f'get_ticket_by_id error: {e}')
        return None


def get_ticket_messages(ticket_id: int, limit: int = 50):
    try:
        connection = get_db_connection()
        if not connection:
            return []
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(
            """
            SELECT id, sender, admin_id, message, created_at
            FROM support_messages
            WHERE ticket_id=%s
            ORDER BY created_at ASC
            LIMIT %s
            """,
            (ticket_id, limit)
        )
        rows = cursor.fetchall()
        cursor.close(); connection.close()
        return rows
    except Exception as e:
        logging.error(f'get_ticket_messages error: {e}')
        return []


def update_ticket_status(ticket_id: int, status: str):
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = connection.cursor()
        cursor.execute("UPDATE support_tickets SET status=%s, updated_at=NOW() WHERE id=%s", (status, ticket_id))
        connection.commit()
        cursor.close(); connection.close()
        return True
    except Exception as e:
        logging.error(f'update_ticket_status error: {e}')
        try:
            connection.rollback()
        except Exception:
            pass
        try:
            cursor.close(); connection.close()
        except Exception:
            pass
        return False


def auto_complete_tasks_at_limit():
    """
    Автоматически деактивирует задания когда лимит выполнений достигнут,
    но только если нет заданий в статусе pending (ожидающих проверки)
    """
    try:
        connection = get_db_connection()
        if not connection:
            return 0
            
        cursor = connection.cursor()
        
        # Находим задания где количество submissions >= submission_limit
        # И нет pending submissions
        cursor.execute("""
            SELECT t.id, t.title, t.submission_limit,
                   COUNT(s.id) as total_submissions,
                   COUNT(CASE WHEN s.status = 'pending' THEN 1 END) as pending_submissions
            FROM tasks t
            LEFT JOIN submissions s ON s.task_id = t.id
            WHERE t.is_active = true 
              AND t.submission_limit IS NOT NULL 
              AND t.submission_limit > 0
            GROUP BY t.id, t.title, t.submission_limit
            HAVING COUNT(s.id) >= t.submission_limit
               AND COUNT(CASE WHEN s.status = 'pending' THEN 1 END) = 0
        """)
        
        tasks_to_complete = cursor.fetchall()
        completed_count = 0
        
        for task_data in tasks_to_complete:
            task_id, title, limit, total_subs, pending_subs = task_data
            
            # Деактивируем задание (НЕ удаляем, чтобы сохранить связанные submissions)
            cursor.execute("""
                UPDATE tasks 
                SET is_active = false, status = 'completed' 
                WHERE id = %s
            """, (task_id,))
            
            completed_count += 1
            logging.info(f"Задание {task_id} ('{title}') автоматически завершено: {total_subs}/{limit} выполнений")
        
        connection.commit()
        cursor.close()
        connection.close()
        
        return completed_count
        
    except Exception as e:
        logging.error(f"Ошибка автоматического завершения заданий: {e}")
        if connection:
            connection.rollback()
            connection.close()
        return 0



# === Contest/Rewards helper ===

def update_user_balance_and_points(user_id: int, reward_money: float = 0.0, reward_points: int = 0, related_id=None, operation_type: str = 'task_reward'):
    """Начисляет деньги/поинты пользователю с идемпотентностью по (operation_type, related_id)."""
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cur = conn.cursor()
        # Idempotency guard
        if related_id is not None and operation_type:
            try:
                cur.execute("SELECT 1 FROM balance_transactions WHERE operation_type=%s AND related_id=%s LIMIT 1", (operation_type, related_id))
                if cur.fetchone():
                    conn.commit(); cur.close(); conn.close(); return True
            except Exception:
                pass
        # Money
        if reward_money and float(reward_money) != 0.0:
            amt = float(reward_money)
            if operation_type == 'task_reward':
                cur.execute("""UPDATE users SET balance = COALESCE(balance,0)+%s, total_earnings = COALESCE(total_earnings,0)+%s, earnings_from_tasks = COALESCE(earnings_from_tasks,0)+%s WHERE user_id=%s""", (amt, amt, amt, user_id))
            elif operation_type == 'referral_reward':
                cur.execute("""UPDATE users SET balance = COALESCE(balance,0)+%s, total_earnings = COALESCE(total_earnings,0)+%s, earnings_from_referrals = COALESCE(earnings_from_referrals,0)+%s WHERE user_id=%s""", (amt, amt, amt, user_id))
            else:
                cur.execute("""UPDATE users SET balance = COALESCE(balance,0)+%s, total_earnings = COALESCE(total_earnings,0)+%s WHERE user_id=%s""", (amt, amt, user_id))
            try:
                cur.execute("""INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at) VALUES (%s, %s, %s, %s, %s)""", (user_id, amt, operation_type or 'task_reward', related_id, int(time.time())))
            except Exception:
                pass
        # Points
        if reward_points and int(reward_points) != 0:
            pts = int(reward_points)
            cur.execute("""UPDATE users SET points = COALESCE(points,0)+%s, total_points = COALESCE(total_points,0)+%s WHERE user_id=%s""", (pts, pts, user_id))
        conn.commit(); cur.close(); conn.close(); return True
    except Exception as e:
        logging.error(f"update_user_balance_and_points error: {e}")
        try:
            if conn: conn.rollback(); conn.close()
        except Exception:
            pass
        return False


# ============= СИСТЕМА БАНОВ =============

def ban_user(user_id, admin_id, reason="Нарушение правил"):
    """Забанить пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        # Проверяем, не забанен ли уже пользователь
        cursor.execute("SELECT is_banned FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        
        if result and result[0]:
            cursor.close()
            connection.close()
            return "already_banned"
        
        # Баним пользователя
        cursor.execute("""
            UPDATE users 
            SET is_banned = TRUE, 
                banned_at = NOW(), 
                banned_by = %s, 
                ban_reason = %s,
                is_active = FALSE
            WHERE user_id = %s
        """, (admin_id, reason, user_id))
        
        # Добавляем запись в историю банов
        cursor.execute("""
            INSERT INTO ban_history (user_id, banned_by, ban_reason, is_active)
            VALUES (%s, %s, %s, TRUE)
        """, (user_id, admin_id, reason))
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Пользователь {user_id} забанен админом {admin_id}. Причина: {reason}")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка при бане пользователя {user_id}: {e}")
        return False

def unban_user(user_id, admin_id):
    """Разбанить пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        
        # Проверяем, забанен ли пользователь
        cursor.execute("SELECT is_banned FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        
        if not result or not result[0]:
            cursor.close()
            connection.close()
            return "not_banned"
        
        # Разбаниваем пользователя
        cursor.execute("""
            UPDATE users 
            SET is_banned = FALSE, 
                banned_at = NULL, 
                banned_by = NULL, 
                ban_reason = NULL,
                is_active = TRUE
            WHERE user_id = %s
        """, (user_id,))
        
        # Обновляем историю банов
        cursor.execute("""
            UPDATE ban_history 
            SET is_active = FALSE, 
                unbanned_at = NOW(), 
                unbanned_by = %s
            WHERE user_id = %s AND is_active = TRUE
        """, (admin_id, user_id))
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Пользователь {user_id} разбанен админом {admin_id}")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка при разбане пользователя {user_id}: {e}")
        return False

def is_user_banned(user_id):
    """Проверить, забанен ли пользователь"""
    try:
        connection = get_db_connection()
        if not connection:
            return False
            
        cursor = connection.cursor()
        cursor.execute("SELECT is_banned FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        return result[0] if result else False
        
    except Exception as e:
        logging.error(f"Ошибка проверки бана пользователя {user_id}: {e}")
        return False

def get_ban_info(user_id):
    """Получить информацию о бане пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return None
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT is_banned, banned_at, banned_by, ban_reason
            FROM users 
            WHERE user_id = %s
        """, (user_id,))
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        return dict(result) if result else None
        
    except Exception as e:
        logging.error(f"Ошибка получения информации о бане {user_id}: {e}")
        return None

def get_banned_users_list():
    """Получить список всех забаненных пользователей"""
    try:
        connection = get_db_connection()
        if not connection:
            return []
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT user_id, username, full_name, banned_at, banned_by, ban_reason
            FROM users 
            WHERE is_banned = TRUE
            ORDER BY banned_at DESC
        """)
        results = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return [dict(row) for row in results]
        
    except Exception as e:
        logging.error(f"Ошибка получения списка забаненных: {e}")
        return []

def get_ban_history(user_id):
    """Получить историю банов пользователя"""
    try:
        connection = get_db_connection()
        if not connection:
            return []
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT * FROM ban_history 
            WHERE user_id = %s
            ORDER BY banned_at DESC
        """, (user_id,))
        results = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return [dict(row) for row in results]
        
    except Exception as e:
        logging.error(f"Ошибка получения истории банов {user_id}: {e}")
        return []


# ============= ДОПОЛНИТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ УПРАВЛЕНИЯ БАНАМИ В БОТЕ =============

def ban_user_db(user_id, reason, duration_minutes=None, banned_by="admin"):
    """Банит пользователя В БОТЕ (is_bot_banned = True)"""
    try:
        connection = get_db_connection()
        if not connection:
            return False, "Ошибка подключения к БД"
            
        cursor = connection.cursor()
        
        # Проверяем существующий бан
        cursor.execute("""
            SELECT id, is_bot_banned FROM user_bans 
            WHERE user_id = %s AND is_active = TRUE 
            ORDER BY banned_at DESC LIMIT 1
        """, (user_id,))
        existing_ban = cursor.fetchone()
        
        if existing_ban and existing_ban[1]:
            cursor.close()
            connection.close()
            return False, "Пользователь уже забанен в боте"
        
        from datetime import datetime, timedelta
        banned_until = None
        is_permanent = True
        
        if duration_minutes:
            banned_until = datetime.utcnow() + timedelta(minutes=duration_minutes)
            is_permanent = False
        
        cursor.execute("""
            INSERT INTO user_bans (
                user_id, reason, duration, banned_at, banned_until, 
                banned_by, is_active, is_permanent, is_bot_banned, is_app_banned
            )
            VALUES (%s, %s, %s, NOW(), %s, %s, TRUE, %s, TRUE, FALSE)
            RETURNING id
        """, (user_id, reason, duration_minutes, banned_until, banned_by, is_permanent))
        
        ban_id = cursor.fetchone()[0]
        
        cursor.execute("""
            UPDATE users 
            SET is_banned = TRUE, banned_at = NOW(), banned_by = %s, banned_until = %s
            WHERE user_id = %s
        """, (ban_id, banned_until, user_id))
        
        connection.commit()
        cursor.close()
        connection.close()
        
        duration_text = f"на {duration_minutes} минут" if duration_minutes else "перманентно"
        logging.info(f"Пользователь {user_id} забанен в боте {duration_text}. Причина: {reason}")
        
        return True, f"Пользователь забанен в боте {duration_text}"
        
    except Exception as e:
        logging.error(f"Ошибка при бане пользователя {user_id}: {e}")
        if 'connection' in locals() and connection:
            connection.rollback()
            connection.close()
        return False, f"Ошибка: {str(e)}"


def unban_user_db(user_id, unbanned_by="admin"):
    """Разбанивает пользователя В БОТЕ"""
    try:
        connection = get_db_connection()
        if not connection:
            return False, "Ошибка подключения к БД"
            
        cursor = connection.cursor()
        
        cursor.execute("""
            SELECT id FROM user_bans 
            WHERE user_id = %s AND is_active = TRUE AND is_bot_banned = TRUE
            ORDER BY banned_at DESC LIMIT 1
        """, (user_id,))
        ban = cursor.fetchone()
        
        if not ban:
            cursor.close()
            connection.close()
            return False, "Пользователь не забанен в боте"
        
        ban_id = ban[0]
        
        cursor.execute("""
            UPDATE user_bans 
            SET is_active = FALSE, unbanned_at = NOW(), unbanned_by = %s
            WHERE id = %s
        """, (unbanned_by, ban_id))
        
        cursor.execute("""
            UPDATE users 
            SET is_banned = FALSE, banned_at = NULL, banned_by = NULL, banned_until = NULL
            WHERE user_id = %s
        """, (user_id,))
        
        connection.commit()
        cursor.close()
        connection.close()
        
        logging.info(f"Пользователь {user_id} разбанен в боте")
        return True, "Пользователь разбанен в боте"
        
    except Exception as e:
        logging.error(f"Ошибка при разбане пользователя {user_id}: {e}")
        if 'connection' in locals() and connection:
            connection.rollback()
            connection.close()
        return False, f"Ошибка: {str(e)}"


def check_user_ban(user_id):
    """Проверяет статус бана пользователя В БОТЕ"""
    try:
        connection = get_db_connection()
        if not connection:
            return False, None
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        cursor.execute("""
            SELECT 
                ub.id, ub.user_id, ub.reason, ub.banned_at, ub.banned_until, 
                ub.banned_by, ub.is_permanent, ub.is_bot_banned,
                u.username, u.full_name
            FROM user_bans ub
            LEFT JOIN users u ON ub.user_id = u.user_id
            WHERE ub.user_id = %s AND ub.is_active = TRUE AND ub.is_bot_banned = TRUE
            ORDER BY ub.banned_at DESC
            LIMIT 1
        """, (user_id,))
        
        ban = cursor.fetchone()
        cursor.close()
        connection.close()
        
        if not ban:
            return False, None
        
        if ban['banned_until']:
            from datetime import datetime
            if datetime.utcnow() > ban['banned_until']:
                unban_user_db(user_id, "SYSTEM_AUTO")
                return False, None
        
        ban_info = dict(ban)
        return True, ban_info
        
    except Exception as e:
        logging.error(f"Ошибка проверки бана пользователя {user_id}: {e}")
        return False, None


def get_active_bans():
    """Получает список всех активных банов В БОТЕ"""
    try:
        connection = get_db_connection()
        if not connection:
            return []
            
        cursor = connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        cursor.execute("""
            SELECT 
                ub.id, ub.user_id, ub.reason, ub.banned_at, ub.banned_until, 
                ub.banned_by, ub.is_permanent, ub.is_bot_banned,
                u.username, u.full_name
            FROM user_bans ub
            LEFT JOIN users u ON ub.user_id = u.user_id
            WHERE ub.is_active = TRUE AND ub.is_bot_banned = TRUE
            ORDER BY ub.banned_at DESC
        """)
        
        bans = cursor.fetchall()
        cursor.close()
        connection.close()
        
        from datetime import datetime
        active_bans = []
        
        for ban in bans:
            ban_dict = dict(ban)
            
            if ban_dict['banned_until']:
                if datetime.utcnow() > ban_dict['banned_until']:
                    try:
                        unban_user_db(ban_dict['user_id'], "SYSTEM_AUTO")
                    except Exception:
                        pass
                    continue
            
            active_bans.append(ban_dict)
        
        return active_bans
        
    except Exception as e:
        logging.error(f"Ошибка получения списка активных банов: {e}")
        return []


def is_user_banned_bot(user_id):
    """Быстрая проверка, забанен ли пользователь в боте"""
    is_banned, _ = check_user_ban(user_id)
    return is_banned
