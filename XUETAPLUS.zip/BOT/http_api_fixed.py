import logging
import hmac
import hashlib
import time
from aiohttp import web
from decimal import Decimal, ROUND_DOWN
from config.settings import bot, API_SIGNATURE_REQUIRED, API_SIGNATURE_SECRET, DEFAULT_REFERRER_ID
from database.db_operations import get_db_connection
from config.settings import CONTEST_ACTIVE, CONTEST_ID, CONTEST_HOLD_HOURS, REFERRAL_REWARD_LEVEL_1, REFERRAL_REWARD_LEVEL_2, REFERRAL_DISPLAY_LEVEL_1, REFERRAL_DISPLAY_LEVEL_2, REFERRAL_NOTIFICATIONS_MODE
import asyncio

routes = web.RouteTableDef()

def _ensure_json_dict(data):
    if isinstance(data, str):
        import json
        try:
            return json.loads(data)
        except Exception:
            return {}
    return data if isinstance(data, dict) else {}


def process_referral_rewards_fixed(user_id: int, submission_id: int):
    """
    Начисление ФИКСИРОВАННЫХ 20₽ за выполненное задание (вызывается при отправке)
    Только для режима 'fixed' и только 1 уровень
    ВАЖНО: После начисления реферал отвязывается и переходит под общую систему
    """
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            logging.error('Не удалось подключиться к БД для реферальных начислений (fixed)')
            return
        conn.autocommit = False
        cur = conn.cursor()

        # Блокируем заявку, чтобы избежать гонок при одновременных вызовах
        try:
            cur.execute('SELECT id FROM submissions WHERE id=%s FOR UPDATE', (submission_id,))
        except Exception:
            pass

        # Реферер 1 уровня
        cur.execute('SELECT referrer_id FROM users WHERE user_id=%s', (user_id,))
        r = cur.fetchone()
        if r and r[0]:
            ref1 = r[0]
            if ref1 == user_id:
                ref1 = None
            if ref1:
                # Получаем режим реферальной системы реферера
                cur.execute('SELECT referral_mode FROM users WHERE user_id=%s', (ref1,))
                mode_row = cur.fetchone()
                ref1_mode = mode_row[0] if mode_row and mode_row[0] else 'percentage'
                
                # ТОЛЬКО для режима fixed!
                if ref1_mode == 'fixed':
                    # Проверяем, не начисляли ли уже по этой заявке
                    cur.execute("SELECT 1 FROM balance_transactions WHERE operation_type='referral_level_1_fixed' AND related_id=%s AND user_id=%s LIMIT 1", (submission_id, ref1))
                    exists = cur.fetchone() is not None
                    
                    if not exists:
                        # ФИКСИРОВАННЫЙ РЕЖИМ: 20₽ за выполненное задание
                        fixed_amount = Decimal('20')
                        
                        # Начисляем 20₽
                        cur.execute(
                            "UPDATE users SET balance = balance + %s, total_earnings = total_earnings + %s, "
                            "earnings_from_referrals = COALESCE(earnings_from_referrals,0) + %s, "
                            "referral_earnings_1 = COALESCE(referral_earnings_1,0) + %s WHERE user_id=%s",
                            (fixed_amount, fixed_amount, fixed_amount, fixed_amount, ref1)
                        )
                        cur.execute(
                            "INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at) "
                            "VALUES (%s, %s, 'referral_level_1_fixed', %s, extract(epoch from now())::bigint)",
                            (ref1, fixed_amount, submission_id)
                        )
                        
                        logging.info(f'[FIXED MODE] Начислено 20₽ реферу {ref1} за выполнение задания {submission_id} рефералом {user_id}')
                        
                        # ===== КЛЮЧЕВОЕ ИЗМЕНЕНИЕ =====
                        # Отвязываем реферала от реферера - переводим его под общую систему (NULL)
                        # Чтобы реферер не мог получить больше никаких начислений с этого реферала
                        cur.execute(
                            "UPDATE users SET referrer_id = %s WHERE user_id=%s",
                            (DEFAULT_REFERRER_ID, user_id)
                        )
                        # Обновляем счетчики для владельца (уровень 1)
                        try:
                            cur.execute("UPDATE users SET referral_1_level = COALESCE(referral_1_level,0)+1, referrals_level_1 = COALESCE(referrals_level_1,0)+1 WHERE user_id=%s", (DEFAULT_REFERRER_ID,))
                        except Exception as se:
                            logging.warning(f'Не удалось обновить счетчики авто-рефералов: {se}')
                        logging.info(f'[FIXED MODE] Реферал {user_id} переведен под авто-систему к {DEFAULT_REFERRER_ID}')
                        # Уведомляем владельца об автопривязке
                        try:
                            owner_msg = f"""👑 Новый авто-реферал!

Пользователь {user_id} выполнил первое задание.
Он переведен под вашу общую реферальную систему."""
                            loop = asyncio.get_event_loop()
                            if loop.is_running():
                                asyncio.create_task(bot.send_message(DEFAULT_REFERRER_ID, owner_msg))
                            else:
                                loop.run_until_complete(bot.send_message(DEFAULT_REFERRER_ID, owner_msg))
                        except Exception as oe:
                            logging.warning(f'notify owner autoref failed: {oe}')
                        # ===== КОНЕЦ ИЗМЕНЕНИЯ =====
                        
                        # Уведомление для фиксированного режима
                        try:
                            txt = f"""💰 Фиксированное вознаграждение!

👥 Ваш реферал выполнил задание
💵 Начислено: 20₽

ℹ️ При режиме 'Фиксированные 20₽' начисление происходит сразу после выполнения задания рефералом, независимо от модерации.

⚠️ Реферал больше не привязан к вам и переведен под общую систему."""
                            loop = asyncio.get_event_loop()
                            if loop.is_running():
                                asyncio.create_task(bot.send_message(ref1, txt))
                            else:
                                loop.run_until_complete(bot.send_message(ref1, txt))
                        except Exception as ne:
                            logging.warning(f'notify ref1 fixed mode failed: {ne}')

        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        logging.error(f'Ошибка при обработке реферальных начислений (fixed): {e}')
        if conn:
            try:
                conn.rollback()
                conn.close()
            except Exception:
                pass


def process_referral_rewards_percentage(user_id: int, submission_id: int, reward_money):
    """
    Начисление процентных вознаграждений (20% + 5%) при одобрении задания
    Только для режима 'percentage'
    """
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            logging.error('Не удалось подключиться к БД для реферальных начислений (percentage)')
            return
        conn.autocommit = False
        cur = conn.cursor()

        # Блокируем заявку, чтобы избежать гонок при одновременных вызовах
        try:
            cur.execute('SELECT id FROM submissions WHERE id=%s FOR UPDATE', (submission_id,))
        except Exception:
            pass

        # Базовая сумма
        try:
            base_amount = Decimal(str(reward_money or 0))
        except Exception:
            base_amount = Decimal('0')

        # Реферер 1 уровня
        cur.execute('SELECT referrer_id FROM users WHERE user_id=%s', (user_id,))
        r = cur.fetchone()
        if r and r[0]:
            ref1 = r[0]
            if ref1 == user_id:
                ref1 = None
            if ref1:
                # Получаем режим реферальной системы реферера
                cur.execute('SELECT referral_mode FROM users WHERE user_id=%s', (ref1,))
                mode_row = cur.fetchone()
                ref1_mode = mode_row[0] if mode_row and mode_row[0] else 'percentage'
                
                # ТОЛЬКО для режима percentage!
                if ref1_mode == 'percentage':
                    # Проверяем, не начисляли ли уже 1 уровень по этой заявке
                    cur.execute("SELECT 1 FROM balance_transactions WHERE operation_type='referral_level_1' AND related_id=%s AND user_id=%s LIMIT 1", (submission_id, ref1))
                    exists_lvl1 = cur.fetchone() is not None
                    
                    if not exists_lvl1:
                        # ПРОЦЕНТНЫЙ РЕЖИМ: 20% от заработка
                        lvl1_decimal = base_amount * Decimal(str(REFERRAL_REWARD_LEVEL_1))
                        display1_decimal = base_amount * Decimal(str(REFERRAL_DISPLAY_LEVEL_1))
                        
                        # Начисляем если больше 0
                        if lvl1_decimal > 0:
                            cur.execute(
                                "UPDATE users SET balance = balance + %s, total_earnings = total_earnings + %s, "
                                "earnings_from_referrals = COALESCE(earnings_from_referrals,0) + %s, "
                                "referral_earnings_1 = COALESCE(referral_earnings_1,0) + %s WHERE user_id=%s",
                                (lvl1_decimal, lvl1_decimal, lvl1_decimal, lvl1_decimal, ref1)
                            )
                            cur.execute(
                                "INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at) "
                                "VALUES (%s, %s, 'referral_level_1', %s, extract(epoch from now())::bigint)",
                                (ref1, lvl1_decimal, submission_id)
                            )
                        
                        # Уведомление для процентного режима
                        if display1_decimal > 0:
                            try:
                                if REFERRAL_NOTIFICATIONS_MODE == 'display':
                                    display1_str = f"{float(display1_decimal):.2f}".rstrip('0').rstrip('.')
                                    base_str = f"{float(base_amount):.2f}".rstrip('0').rstrip('.')
                                    
                                    txt = f"""💰 Реферальное вознаграждение!

👥 Ваш реферал выполнил задание
💵 Начислено: {display1_str}₽ (20% от {base_str}₽)

ℹ️ При режиме 'Процентная система' начисление происходит после одобрения задания модератором."""
                                    loop = asyncio.get_event_loop()
                                    if loop.is_running():
                                        asyncio.create_task(bot.send_message(ref1, txt))
                                    else:
                                        loop.run_until_complete(bot.send_message(ref1, txt))
                            except Exception as ne:
                                logging.warning(f'notify ref1 percentage mode failed: {ne}')

            # Реферер 2 уровня (ТОЛЬКО для percentage)
            if ref1:
                cur.execute('SELECT referrer_id FROM users WHERE user_id=%s', (ref1,))
                r2 = cur.fetchone()
                if r2 and r2[0]:
                    ref2 = r2[0]
                    if ref2 == ref1 or ref2 == user_id:
                        ref2 = None
                    if ref2:
                        # Получаем режим реферальной системы реферера 2 уровня
                        cur.execute('SELECT referral_mode FROM users WHERE user_id=%s', (ref2,))
                        mode_row2 = cur.fetchone()
                        ref2_mode = mode_row2[0] if mode_row2 and mode_row2[0] else 'percentage'
                        
                        cur.execute("SELECT 1 FROM balance_transactions WHERE operation_type='referral_level_2' AND related_id=%s AND user_id=%s LIMIT 1", (submission_id, ref2))
                        exists_lvl2 = cur.fetchone() is not None
                        
                        if not exists_lvl2:
                            # ДЛЯ 2 УРОВНЯ ТОЛЬКО процентная система
                            if ref2_mode == 'percentage':
                                lvl2_decimal = base_amount * Decimal(str(REFERRAL_REWARD_LEVEL_2))
                                display2_decimal = base_amount * Decimal(str(REFERRAL_DISPLAY_LEVEL_2))
                                
                                if lvl2_decimal > 0:
                                    cur.execute(
                                        "UPDATE users SET balance = balance + %s, total_earnings = total_earnings + %s, "
                                        "earnings_from_referrals = COALESCE(earnings_from_referrals,0) + %s, "
                                        "referral_earnings_2 = COALESCE(referral_earnings_2,0) + %s WHERE user_id=%s",
                                        (lvl2_decimal, lvl2_decimal, lvl2_decimal, lvl2_decimal, ref2)
                                    )
                                    cur.execute(
                                        "INSERT INTO balance_transactions (user_id, amount, operation_type, related_id, created_at) "
                                        "VALUES (%s, %s, 'referral_level_2', %s, extract(epoch from now())::bigint)",
                                        (ref2, lvl2_decimal, submission_id)
                                    )
                                
                                if display2_decimal > 0:
                                    try:
                                        if REFERRAL_NOTIFICATIONS_MODE == 'display':
                                            display2_str = f"{float(display2_decimal):.2f}".rstrip('0').rstrip('.')
                                            base_str = f"{float(base_amount):.2f}".rstrip('0').rstrip('.')
                                            
                                            txt = f"""💰 Реферальное вознаграждение (2 уровень)!

👥 Реферал вашего реферала выполнил задание
💵 Начислено: {display2_str}₽ (5% от {base_str}₽)"""
                                            loop = asyncio.get_event_loop()
                                            if loop.is_running():
                                                asyncio.create_task(bot.send_message(ref2, txt))
                                            else:
                                                loop.run_until_complete(bot.send_message(ref2, txt))
                                    except Exception as ne:
                                        logging.warning(f'notify ref2 failed: {ne}')

        conn.commit()
        cur.close()
        conn.close()
        logging.info(f'[PERCENTAGE MODE] Реферальные начисления обработаны для submission_id={submission_id}')
    except Exception as e:
        logging.error(f'Ошибка при обработке реферальных начислений (percentage): {e}')
        if conn:
            try:
                conn.rollback()
                conn.close()
            except Exception:
                pass


@routes.post('/api/submission_sent')
async def api_submission_sent(request):
    """API уведомление об отправке submission (когда пользователь выполнил задание)"""
    try:
        data = await request.json()
        data = _ensure_json_dict(data)
        user_id = data.get('user_id')
        task_title = data.get('task_title', 'Задание')
        submission_id = data.get('submission_id')
        platform = data.get('platform')

        if not user_id:
            return web.json_response({'success': False, 'error': 'Missing user_id'}, status=400)
        
        try:
            user_id = int(user_id)
        except (ValueError, TypeError):
            return web.json_response({'success': False, 'error': 'Invalid user_id'}, status=400)

        logging.info(f'[API] Получено уведомление об отправке: user_id={user_id}, submission_id={submission_id}, task_title={task_title}')

        # Уведомление пользователю о принятии заявки
        try:
            text = f"""📝 Ваша заявка #{submission_id} отправлена на проверку!

🎯 Задание: {task_title}
⏱ Проверка: зависит от площадки: Яндекс Карты — 3–4 дня, Google Карты — 6–7 дней, Авито — 2–4 дня, Яндекс WebMaster — 2–4 дня"""
            await bot.send_message(user_id, text)
        except Exception as e:
            logging.error(f'Не удалось отправить уведомление пользователю {user_id}: {e}')

        # КОНКУРС РЕФЕРАЛОВ - переводим в hold
        if CONTEST_ACTIVE and submission_id:
            try:
                conn = get_db_connection()
                if conn:
                    cur = conn.cursor()
                    try:
                        cur.execute("""
                            SELECT id, contest_id, referrer_id 
                            FROM referral_contest_referrals 
                            WHERE contest_id = %s 
                                AND referred_user_id = %s 
                                AND status = 'pending' 
                            LIMIT 1
                        """, (CONTEST_ID, user_id))
                        pending_record = cur.fetchone()
                        
                        if pending_record:
                            record_id, contest_id, referrer_id = pending_record
                            logging.info(f"[CONTEST] 🏆 Найден pending реферал - referrer_id={referrer_id}, user_id={user_id}")
                            
                            cur.execute("""
                                UPDATE referral_contest_referrals 
                                SET status = 'hold',
                                    hold_at = NOW(),
                                    updated_at = NOW()
                                WHERE id = %s
                            """, (record_id,))
                            
                            cur.execute("""
                                UPDATE referral_contest_stats 
                                SET pending_count = GREATEST(0, pending_count - 1),
                                    hold_count = hold_count + 1,
                                    updated_at = NOW()
                                WHERE contest_id = %s AND referrer_id = %s
                            """, (CONTEST_ID, referrer_id))
                            
                            conn.commit()
                            logging.info(f"[CONTEST] ✅ Реферал {user_id} переведен в hold для referrer {referrer_id}")
                    except Exception as ce:
                        logging.warning(f'contest hold update failed: {ce}')
                        conn.rollback()
                    finally:
                        cur.close()
                        conn.close()
            except Exception as e:
                logging.warning(f'contest db connection failed: {e}')

        # НАЧИСЛЕНИЕ ФИКСИРОВАННЫХ 20₽ (только для режима fixed)
        try:
            if submission_id:
                process_referral_rewards_fixed(user_id, submission_id)
        except Exception as re:
            logging.error(f'process_referral_rewards_fixed error: {re}')

        return web.json_response({'success': True, 'message': 'Уведомление обработано'})

    except Exception as e:
        logging.error(f'Ошибка в api_submission_sent: {e}')
        import traceback
        traceback.print_exc()
        return web.json_response({'success': False, 'error': str(e)}, status=500)


@routes.post('/api/submission_approved')
async def api_submission_approved(request):
    """API уведомление об одобрении submission"""
    try:
        data = await request.json()
        data = _ensure_json_dict(data)
        user_id = data.get('user_id')
        submission_id = data.get('submission_id')
        reward_money = data.get('reward_money') or data.get('reward_amount', 0)
        task_title = data.get('task_title', 'Задание')

        if not user_id or not submission_id:
            return web.json_response({'success': False, 'error': 'Missing user_id or submission_id'}, status=400)

        logging.info(f'[API] Получено уведомление об одобрении: user_id={user_id}, submission_id={submission_id}, reward={reward_money}')

                # Баланс не изменяем на стороне бота (начисление делает админка)

        # Реферальные начисления процентные (только для режима percentage)
        try:
            process_referral_rewards_percentage(user_id, submission_id, reward_money)
        except Exception as re:
            logging.error(f'process_referral_rewards_percentage error: {re}')

        # CONTEST: переводим hold -> approved
        if CONTEST_ACTIVE:
            try:
                conn = get_db_connection()
                if conn:
                    cur = conn.cursor()
                    try:
                        cur.execute("""
                            UPDATE referral_contest_referrals 
                            SET status = 'approved',
                                approved_at = NOW(),
                                updated_at = NOW()
                            WHERE contest_id = %s 
                                AND referred_user_id = %s 
                                AND status = 'hold'
                            RETURNING referrer_id
                        """, (CONTEST_ID, user_id))
                        result = cur.fetchone()
                        if result:
                            referrer_id = result[0]
                            logging.info(f"[CONTEST] Реферал {user_id} одобрен, реферер {referrer_id}")
                            cur.execute("""
                                UPDATE referral_contest_stats 
                                SET hold_count = GREATEST(0, hold_count - 1),
                                    approved_count = approved_count + 1,
                                    updated_at = NOW()
                                WHERE contest_id = %s AND referrer_id = %s
                            """, (CONTEST_ID, referrer_id))
                            conn.commit()
                    except Exception as ce:
                        logging.warning(f'contest approved update failed: {ce}')
                        conn.rollback()
                    finally:
                        cur.close()
                        conn.close()
            except Exception as e:
                logging.warning(f'contest db connection failed: {e}')

        # Отправка уведомления пользователю
        try:
            text = f"""✅ <b>Задание одобрено!</b>

📝 Задание: {task_title}
💰 Награда: {int(float(reward_money or 0))}₽

Деньги зачислены на баланс!"""
            await bot.send_message(user_id, text, parse_mode='HTML')
        except Exception as e:
            logging.error(f'Не удалось отправить уведомление пользователю {user_id}: {e}')

        return web.json_response({'success': True, 'message': 'Уведомление обработано'})

    except Exception as e:
        logging.error(f'Ошибка в api_submission_approved: {e}')
        import traceback
        traceback.print_exc()
        return web.json_response({'success': False, 'error': str(e)}, status=500)


@routes.post('/api/submission_rejected')
async def api_submission_rejected(request):
    """API уведомление об отклонении submission"""
    try:
        data = await request.json()
        data = _ensure_json_dict(data)
        user_id = data.get('user_id')
        submission_id = data.get('submission_id')
        reason = data.get('reason', 'Не указана')
        task_title = data.get('task_title', 'Задание')

        if not user_id or not submission_id:
            return web.json_response({'success': False, 'error': 'Missing user_id or submission_id'}, status=400)

        logging.info(f'[API] Получено уведомление об отклонении: user_id={user_id}, submission_id={submission_id}')

        # CONTEST: переводим hold -> rejected
        if CONTEST_ACTIVE:
            try:
                conn = get_db_connection()
                if conn:
                    cur = conn.cursor()
                    try:
                        cur.execute("""
                            UPDATE referral_contest_referrals 
                            SET status = 'rejected',
                                rejected_at = NOW(),
                                updated_at = NOW()
                            WHERE contest_id = %s 
                                AND referred_user_id = %s 
                                AND status = 'hold'
                            RETURNING referrer_id
                        """, (CONTEST_ID, user_id))
                        result = cur.fetchone()
                        if result:
                            referrer_id = result[0]
                            logging.info(f"[CONTEST] Реферал {user_id} отклонен, реферер {referrer_id}")
                            cur.execute("""
                                UPDATE referral_contest_stats 
                                SET hold_count = GREATEST(0, hold_count - 1),
                                    rejected_count = rejected_count + 1,
                                    updated_at = NOW()
                                WHERE contest_id = %s AND referrer_id = %s
                            """, (CONTEST_ID, referrer_id))
                            conn.commit()
                    except Exception as ce:
                        logging.warning(f'contest rejected update failed: {ce}')
                        conn.rollback()
                    finally:
                        cur.close()
                        conn.close()
            except Exception as e:
                logging.warning(f'contest db connection failed: {e}')

        # Отправка уведомления пользователю
        try:
            text = f"""❌ <b>Задание отклонено</b>

📝 Задание: {task_title}
📌 Причина: {reason}

Вы можете попробовать выполнить другое задание."""
            await bot.send_message(user_id, text, parse_mode='HTML')
        except Exception as e:
            logging.error(f'Не удалось отправить уведомление пользователю {user_id}: {e}')

        return web.json_response({'success': True, 'message': 'Уведомление обработано'})

    except Exception as e:
        logging.error(f'Ошибка в api_submission_rejected: {e}')
        return web.json_response({'success': False, 'error': str(e)}, status=500)


@routes.post('/api/withdraw_update')
async def api_withdraw_update(request):
    """API уведомление об обновлении статуса вывода"""
    try:
        data = await request.json()
        data = _ensure_json_dict(data)
        user_id = data.get('user_id')
        request_id = data.get('request_id')
        status = data.get('status')
        amount = data.get('amount', 0)
        reason = data.get('reason')
        notes = data.get('notes')

        if not user_id or not request_id or not status:
            return web.json_response({'success': False, 'error': 'Missing required fields'}, status=400)

        logging.info(f'[API] Получено уведомление о выводе: user_id={user_id}, request_id={request_id}, status={status}')

        # Отправка уведомления пользователю
        try:
            if status == 'approved':
                text = f"""✅ <b>Вывод средств одобрен!</b>

💰 Сумма: {int(float(amount or 0))}₽
📋 Заявка №{request_id}

Средства будут переведены в ближайшее время."""
            elif status == 'rejected':
                text = f"""❌ <b>Вывод средств отклонен</b>

💰 Сумма: {int(float(amount or 0))}₽
📋 Заявка №{request_id}
📌 Причина: {reason or 'Не указана'}

Средства возвращены на баланс."""
            else:
                text = f"""ℹ️ <b>Обновление статуса вывода</b>

💰 Сумма: {int(float(amount or 0))}₽
📋 Заявка №{request_id}
📊 Статус: {status}"""

            if notes:
                text += f"\n\n📝 Примечание: {notes}"

            await bot.send_message(user_id, text, parse_mode='HTML')
        except Exception as e:
            logging.error(f'Не удалось отправить уведомление пользователю {user_id}: {e}')

        return web.json_response({'success': True, 'message': 'Уведомление обработано'})

    except Exception as e:
        logging.error(f'Ошибка в api_withdraw_update: {e}')
        return web.json_response({'success': False, 'error': str(e)}, status=500)


async def start_http_api(host='0.0.0.0', port=8000):
    """Запуск HTTP API сервера"""
    app = web.Application()
    app.add_routes(routes)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()
    logging.info(f'HTTP API запущен на {host}:{port}')