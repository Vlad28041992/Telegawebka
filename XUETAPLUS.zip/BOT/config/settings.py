"""
Настройки бота
"""

import os
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage

# 🔥 ИСПРАВЛЕНИЕ: Ищем правильную переменную TELEGRAM_BOT_TOKEN
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('BOT_TOKEN')


# HTTP timeout for Telegram API
BOT_HTTP_TIMEOUT = int(os.getenv('BOT_HTTP_TIMEOUT', '30'))
ADMINS = [858177728, 6942727636]

# Настройки базы данных
DATABASE_CONFIG = {
    'host': os.getenv('DB_HOST', 'amvera-angel2804-cnpg-seoserm-rw'),
    'database': os.getenv('DB_NAME', 'botinok'),
    'user': os.getenv('DB_USER', 'SeoSerm'),
    'password': os.getenv('DB_PASSWORD', 'Mama77660'),
    'port': os.getenv('DB_PORT', 5432)
}

# URLs других сервисов
ADMIN_PANEL_URL = os.getenv('ADMIN_PANEL_URL', 'https://adminpanelseoserm-angel2804.amvera.io')
WEB_APP_URL = os.getenv('WEB_APP_URL', 'https://seowebapp-angel2804.amvera.io')

# Настройки реферальной системы - ИСПРАВЛЕНО НА ТОЧНЫЕ ЗНАЧЕНИЯ
REFERRAL_REWARD_LEVEL_1 = float(os.getenv('REFERRAL_REWARD_LEVEL_1', '0.13'))  # ИСПРАВЛЕНО: 0.13% чтобы получалось ровно 20% (1-й уровень)
REFERRAL_REWARD_LEVEL_2 = float(os.getenv('REFERRAL_REWARD_LEVEL_2', '0.0'))   # 0%


# Отображаемые проценты в уведомлениях (для текста), фактические выплаты выше не меняем
REFERRAL_DISPLAY_LEVEL_1 = float(os.getenv('REFERRAL_DISPLAY_LEVEL_1', '0.20'))
REFERRAL_DISPLAY_LEVEL_2 = float(os.getenv('REFERRAL_DISPLAY_LEVEL_2', '0.05'))

# Режим оповещений рефералам: 'display' — показывать 20%/5%, 'off' — не отправлять вовсе
REFERRAL_NOTIFICATIONS_MODE = os.getenv('REFERRAL_NOTIFICATIONS_MODE', 'display')


# Минимальная сумма для вывода
MIN_WITHDRAWAL_AMOUNT = 200

# Проверяем токен перед инициализацией бота
if not BOT_TOKEN or BOT_TOKEN == 'YOUR_BOT_TOKEN_HERE':
    print("❌ ОШИБКА: Токен бота не найден!")
    print("Проверьте переменную окружения TELEGRAM_BOT_TOKEN или BOT_TOKEN")
    exit(1)

# Инициализация бота
bot = Bot(token=BOT_TOKEN, parse_mode='HTML', timeout=BOT_HTTP_TIMEOUT)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

# 🔥 ИСПРАВЛЕНИЕ: Подключаем middleware для проверки бана
from middlewares.ban_check import BanCheckMiddleware
dp.middleware.setup(BanCheckMiddleware())
print('✅ Ban check middleware activated')

# ID администраторов
ADMIN_IDS = [
    int(admin_id) for admin_id in os.getenv('ADMIN_IDS', '').split(',') 
    if admin_id.strip().isdigit()
]

# Канал для логов (опционально)
LOG_CHANNEL_ID = os.getenv('LOG_CHANNEL_ID')

# Максимальное количество заданий в день для пользователя
MAX_TASKS_PER_DAY = 10

# Время жизни сессии в секундах
SESSION_LIFETIME = 3600  # 1 час

# Логируем успешную инициализацию и реферальные настройки
print('✅ Bot initialized')
print(f'📊 Реферальная система: 1 уровень = {REFERRAL_REWARD_LEVEL_1*100}%, 2 уровень = {REFERRAL_REWARD_LEVEL_2*100}%')



# Auto-referrer (owner) id for attaching referrals after fixed payout
try:
    DEFAULT_REFERRER_ID = int(os.getenv('DEFAULT_REFERRER_ID', '858177728'))
except Exception:
    DEFAULT_REFERRER_ID = 858177728
AUTO_REFERRER_ID = DEFAULT_REFERRER_ID
print(f'👑 Auto-referrer set to {DEFAULT_REFERRER_ID}')

# Aliases for compatibility
try:
    admins = ADMINS
except Exception:
    admins = []
try:
    min_withdrawal_amount = MIN_WITHDRAWAL_AMOUNT
except Exception:
    min_withdrawal_amount = 200


# ========================================
# НАСТРОЙКИ КОНКУРСА РЕФЕРАЛОВ
# ========================================
CONTEST_ACTIVE = int(os.getenv('CONTEST_ACTIVE', '1'))  # 0 - выключить, 1 - включить
CONTEST_ID = 1  # ID активного конкурса
CONTEST_HOLD_HOURS = 1  # Холд перед зачетом реферала
CONTEST_MIN_TASKS = 1  # Минимум заданий для зачета
CONTEST_START = '2025-10-18 14:00:00'
CONTEST_END = '2025-10-31 23:59:59'

# Защита от накруток
API_SIGNATURE_SECRET = os.getenv('API_SIGNATURE_SECRET', 'your-secret-key-change-me')


# Настройки безопасности API
API_SIGNATURE_REQUIRED = int(os.getenv('API_SIGNATURE_REQUIRED', '0'))  # 0 - выключено, 1 - включено
API_SIGNATURE_SECRET = os.getenv('API_SIGNATURE_SECRET', 'your-secret-key-here-change-in-production')
API_MAX_REQUEST_AGE = 300  # Максимальный возраст запроса в секундах (5 минут)
