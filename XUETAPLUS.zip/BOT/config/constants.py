# config/constants.py
# Стикеры для разных ситуаций
STICKER_WELCOME = [
    "CAACAgIAAxkBAAEL3hxmCbJc3gAB8Xz5AAH3Y6GtQn0YgQACJgADwDZPE_lqX5qCaIp6NAQ",
    "CAACAgIAAxkBAAEL3h5mCbJh8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE",
    "CAACAgIAAxkBAAEL3iBmCbJk8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE"
]

STICKER_APPROVED = [
    "CAACAgIAAxkBAAEL3iJmCbJo8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE",
    "CAACAgIAAxkBAAEL3iRmCbJs8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE"
]

STICKER_REJECTED = [
    "CAACAgIAAxkBAAEL3iZmCbJw8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE",
    "CAACAgIAAxkBAAEL3ihmCbJ08t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE"
]

STICKER_NO_TASKS = [
    "CAACAgIAAxkBAAEL3ipmCbJ48t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE",
    "CAACAgIAAxkBAAEL3ixmCbJ88t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE"
]

STICKER_ERROR = [
    "CAACAgIAAxkBAAEL3i5mCbKA8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE",
    "CAACAgIAAxkBAAEL3jBmCbKE8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE"
]

# Баллы для каждой платформы
PLATFORM_POINTS = {
    "Яндекс Карты": 5,
    "Google Карты": 3,
    "Авито": 7,
    "2ГИС": 2,
    "Zoon": 2,
    "Яндекс браузер": 3,
    "Другая платформа": 1
}

# Эмодзи для платформ
EMOJI_MAP = {
    "Яндекс Карты": "🗺️",
    "Google Карты": "🌍",
    "2ГИС": "📌",
    "Zoon": "🏪",
    "Яндекс браузер": "🧭",
    "Другая платформа": "⭐"
}
