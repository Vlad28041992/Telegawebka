# utils/ban_middleware.py
"""
Middleware для проверки бана пользователя перед обработкой любого действия
"""

import logging
from aiogram import types
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from database.db_operations import is_user_banned, get_ban_info

class BanCheckMiddleware(BaseMiddleware):
    """Middleware для проверки статуса бана пользователя"""
    
    async def on_pre_process_message(self, message: types.Message, data: dict):
        """Проверка перед обработкой сообщения"""
        user_id = message.from_user.id
        
        # Пропускаем проверку для команды /start чтобы показать сообщение о бане
        if message.text and message.text.startswith('/start'):
            return
        
        if is_user_banned(user_id):
            ban_info = get_ban_info(user_id)
            reason = ban_info.get('ban_reason', 'Не указана') if ban_info else 'Не указана'
            
            await message.answer(
                f"🚫 <b>Ваш аккаунт заблокирован!</b>\n\n"
                f"📝 Причина: {reason}\n\n"
                f"ℹ️ Вы не можете использовать бота. "
                f"Если считаете, что это ошибка, обратитесь в поддержку.",
                parse_mode="HTML"
            )
            
            logging.info(f"Заблокирована попытка использования бота забаненным пользователем {user_id}")
            raise CancelHandler()
    
    async def on_pre_process_callback_query(self, callback_query: types.CallbackQuery, data: dict):
        """Проверка перед обработкой callback"""
        user_id = callback_query.from_user.id
        
        if is_user_banned(user_id):
            ban_info = get_ban_info(user_id)
            reason = ban_info.get('ban_reason', 'Не указана') if ban_info else 'Не указана'
            
            await callback_query.answer(
                f"🚫 Ваш аккаунт заблокирован! Причина: {reason}",
                show_alert=True
            )
            
            logging.info(f"Заблокирована попытка callback от забаненного пользователя {user_id}")
            raise CancelHandler()
