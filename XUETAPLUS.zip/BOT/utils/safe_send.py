
import asyncio
from aiohttp import ClientError

DEFAULT_RETRIES = 3

async def safe_send_message(bot, chat_id, text, parse_mode=None, reply_markup=None,
                            disable_web_page_preview=None, retries=DEFAULT_RETRIES):
    delay = 0.7
    for attempt in range(1, retries+1):
        try:
            return await bot.send_message(
                chat_id,
                text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview
            )
        except (asyncio.TimeoutError, ClientError):
            if attempt == retries:
                raise
            await asyncio.sleep(delay)
            delay *= 2

async def safe_answer(message, text, parse_mode=None, reply_markup=None,
                      disable_web_page_preview=None, retries=DEFAULT_RETRIES):
    delay = 0.7
    for attempt in range(1, retries+1):
        try:
            return await message.answer(
                text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview
            )
        except (asyncio.TimeoutError, ClientError):
            if attempt == retries:
                raise
            await asyncio.sleep(delay)
            delay *= 2
