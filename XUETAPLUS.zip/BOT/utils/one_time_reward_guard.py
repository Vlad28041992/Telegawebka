
# -*- coding: utf-8 -*-
"""Utilities to ensure one-time 20 RUB reward and auto-rebind to owner."""
from typing import Callable

class RewardAlreadyGranted(Exception):
    pass


def process_one_time_reward(db, referrer_id: int, referred_id: int, amount: int, owner_id: int,
                            credit_func: Callable[[int, int, str], None], notifier: Callable[[str], None] = None):
    """
    Process the one-time reward logic in an idempotent way.
    - db must provide: has_one_time_paid(referred_id), set_one_time_paid(referred_id)
                       get_user_mode(referrer_id), set_parent(referred_id, owner_id)
    - credit_func(referrer_id, amount, reason)
    Steps:
    1) If already paid for referred_id => no action
    2) Otherwise credit amount to referrer
    3) Mark one-time paid for referred_id
    4) Rebind referred to owner
    5) Notify owner if notifier provided
    """
    # 1
    if hasattr(db, 'has_one_time_paid') and db.has_one_time_paid(referred_id):
        raise RewardAlreadyGranted('already_paid')

    # 2
    reason = f'One-time reward for {referred_id}'
    credit_func(referrer_id, amount, reason)

    # 3
    if hasattr(db, 'set_one_time_paid'):
        db.set_one_time_paid(referred_id)

    # 4
    if hasattr(db, 'set_parent'):
        db.set_parent(referred_id, owner_id)

    # 5
    if notifier:
        try:
            notifier(f'👑 Новый авто-реферал! Пользователь {referred_id} закреплён за владельцем.')
        except Exception:
            pass
