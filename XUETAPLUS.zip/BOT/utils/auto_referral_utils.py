
# -*- coding: utf-8 -*-
from typing import Optional, Tuple

class AutoReferralError(Exception):
    pass

def rebind_to_owner(db, user_id: int, owner_id: int, notifier=None) -> Tuple[bool, str]:
    """
    Rebind user's parent to owner in an idempotent way.
    - db: database/session object with methods get_user, set_parent, mark_one_time_paid
    - user_id: referred user's ID
    - owner_id: owner's ID
    - notifier: callable(message: str) to notify owner (optional)

    Returns (changed, info)
    """
    u = db.get_user(user_id)
    if not u:
        return False, 'user_not_found'

    # If already attached to owner, no-op
    if getattr(u, 'parent_id', None) == owner_id:
        return False, 'already_owner_child'

    # Ensure one-time paid flag is set to lock 20rub path
    if hasattr(db, 'mark_one_time_paid'):
        try:
            db.mark_one_time_paid(user_id)
        except Exception:
            pass

    # Rebind
    try:
        db.set_parent(user_id, owner_id)
    except Exception as e:
        raise AutoReferralError(f'failed_set_parent: {e}')

    if notifier:
        try:
            notifier('👑 Новый авто-реферал: пользователь {} теперь закреплён за владельцем.'.format(user_id))
        except Exception:
            pass

    return True, 'rebound_to_owner'
