# utils/contest_tasks.py
"""
Фоновые задачи для конкурса рефералов
ОБНОВЛЕНО: добавлена автоостановка при достижении 100 рефералов
"""
import logging
import asyncio
from database.db_operations import get_db_connection
from config.settings import CONTEST_ID, CONTEST_HOLD_HOURS, bot

async def process_contest_holds():
    """
    Переводит рефералов из статуса 'hold' в 'qualified' 
    после истечения времени холда
    + АВТООСТАНОВКА КОНКУРСА при достижении 100 рефералов
    """
    while True:
        try:
            conn = get_db_connection()
            if conn:
                cur = conn.cursor()
                
                # Проверяем, активен ли конкурс
                cur.execute("SELECT is_active FROM referral_contests WHERE id = %s", (CONTEST_ID,))
                contest_status = cur.fetchone()
                
                if not contest_status or not contest_status[0]:
                    logging.info("Конкурс неактивен, пропускаем обработку")
                    cur.close()
                    conn.close()
                    await asyncio.sleep(600)
                    continue
                
                # Находим записи в холде, у которых прошло достаточно времени
                cur.execute(
                    """UPDATE referral_contest_referrals 
                    SET status = 'qualified', updated_at = NOW()
                    WHERE contest_id = %s 
                        AND status = 'hold' 
                        AND first_submission_at <= NOW() - make_interval(hours => %s)
                    RETURNING id, referrer_id, referred_user_id""",
                    (CONTEST_ID, CONTEST_HOLD_HOURS)
                )
                
                qualified_refs = cur.fetchall()
                
                if qualified_refs:
                    logging.info(f"Конкурс: переведено в qualified {len(qualified_refs)} рефералов")
                    
                    # Обновляем статистику для всех затронутых рефереров
                    for _id, referrer_id, referred_user_id in qualified_refs:
                        cur.execute(
                            """INSERT INTO referral_contest_stats 
                            (contest_id, referrer_id, qualified_count, hold_count)
                            VALUES (%s, %s, 1, 0)
                            ON CONFLICT (contest_id, referrer_id) DO UPDATE SET
                                qualified_count = referral_contest_stats.qualified_count + 1,
                                hold_count = GREATEST(0, referral_contest_stats.hold_count - 1),
                                updated_at = NOW()""",
                            (CONTEST_ID, referrer_id)
                        )
                        
                        # Получаем текущее количество засчитанных рефералов
                        cur.execute(
                            """SELECT qualified_count FROM referral_contest_stats 
                            WHERE contest_id = %s AND referrer_id = %s""",
                            (CONTEST_ID, referrer_id)
                        )
                        result = cur.fetchone()
                        if result:
                            qualified_count = result[0]
                            
                            # 🏆 АВТООСТАНОВКА: если кто-то набрал 100 рефералов
                            if qualified_count >= 100:
                                logging.info(f"🎉 ПОБЕДИТЕЛЬ КОНКУРСА! Пользователь {referrer_id} набрал {qualified_count} рефералов!")
                                
                                # Останавливаем конкурс
                                cur.execute(
                                    "UPDATE referral_contests SET is_active = false WHERE id = %s",
                                    (CONTEST_ID,)
                                )
                                
                                conn.commit()
                                
                                # Получаем информацию о победителе
                                cur.execute(
                                    "SELECT username, full_name FROM users WHERE user_id = %s",
                                    (referrer_id,)
                                )
                                winner_info = cur.fetchone()
                                winner_name = winner_info[1] if winner_info else str(referrer_id)
                                
                                # Отправляем уведомление победителю
                                try:
                                    await bot.send_message(
                                        referrer_id,
                                        f"🏆🎉 <b>ПОЗДРАВЛЯЕМ!</b> 🎉🏆\n\n"
                                        f"Ты ПОБЕДИТЕЛЬ конкурса рефералов!\n\n"
                                        f"Ты первым набрал {qualified_count} засчитанных рефералов!\n"
                                        f"Твой приз: <b>2000 рублей</b>\n\n"
                                        f"Администратор свяжется с тобой для передачи приза.\n"
                                        f"Спасибо за участие! 🚀",
                                        parse_mode='HTML'
                                    )
                                except Exception as e:
                                    logging.error(f"Не удалось отправить уведомление победителю {referrer_id}: {e}")
                                
                                logging.info(f"Конкурс остановлен. Победитель: {referrer_id} ({winner_name})")
                                
                                cur.close()
                                conn.close()
                                return  # Останавливаем задачу после завершения конкурса
                
                conn.commit()
                cur.close()
                conn.close()
                
        except Exception as e:
            logging.error(f"Ошибка в process_contest_holds: {e}")
        
        # Проверяем каждые 10 минут
        await asyncio.sleep(600)

def start_contest_background_tasks(loop):
    """Запускает фоновые задачи конкурса"""
    logging.info("Запуск фоновых задач конкурса...")
    loop.create_task(process_contest_holds())
