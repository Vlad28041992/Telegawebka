# utils/notifications.py
import random
import logging
from aiogram import types
from config.settings import bot
from config.constants import STICKER_WELCOME, STICKER_APPROVED, STICKER_REJECTED, STICKER_ERROR

async def send_welcome_sticker(message: types.Message):
    """Отправляет приветственный стикер"""
    try:
        await message.answer_sticker(random.choice(STICKER_WELCOME))
    except Exception as e:
        logging.error(f"Ошибка при отправке стикера: {e}")
        await message.answer("👋")

async def notify_user_submission_status(user_id: int, approved: bool):
    """Уведомляет пользователя о статусе его отправки"""
    if approved:
        text = random.choice([
            "✅ Вау! Твое задание одобрено! ✨ Заработанные баллы уже у тебя на балансе! 🎉",
            "🚀 Поздравляем! Модератор одобрил твою заявку. Баланс пополнен! 💰",
            "🥳 Отлично! Задание принято, и средства зачислены! Продолжай в том же духе! 🌟"
        ])
        sticker_id = random.choice(STICKER_APPROVED)
    else:
        text = random.choice([
            "❌ Упс! Твое задание не прошло проверку. 😟 Не расстраивайся! Попробуй снова или напиши в поддержку: @support_username",
            "💔 К сожалению, заявка отклонена. Возможно, что-то пошло не так. Обратись к нам: @support_username",
            "⛔️ Задание отклонено. Если считаешь, что это ошибка, свяжись с техподдержкой: @support_username"
        ])
        sticker_id = random.choice(STICKER_REJECTED)
    try:
        await bot.send_sticker(user_id, sticker_id)
        await bot.send_message(user_id, text, parse_mode="HTML")
    except Exception as e:
        try:
            await bot.send_message(user_id, text, parse_mode="HTML")
        except Exception as e:
            logging.error(f"Не удалось отправить уведомление пользователю {user_id}: {e}")

async def notify_user_achievement(user_id: int, achievement: dict):
    """Уведомляет пользователя о полученном достижении"""
    name = achievement.get("name")
    reward = achievement.get("reward")
    text = (
        f"🏆✨ <b>НОВОЕ ДОСТИЖЕНИЕ!</b> ✨🏆\n\n"
        f"Поздравляем! Ты открыл ачивку «<b>{name}</b>»!\n\n"
        f"В награду на твой баланс зачислено <b>{reward} бонусных баллов</b>! 💰\n\n"
        f"Так держать! Впереди еще много вершин! 🚀"
    )
    sticker_id = "CAACAgIAAxkBAAEL3jJmCbKI8t5f8wABJv7L3JgABQABzQ4AAiYAA8A2TxP5al-agmiKejQE"
    try:
        await bot.send_sticker(user_id, sticker_id)
        await bot.send_message(user_id, text, parse_mode="HTML")
    except Exception:
        try:
            await bot.send_message(user_id, text, parse_mode="HTML")
        except Exception as e:
            logging.error(f"Не удалось отправить уведомление о достижении пользователю {user_id}: {e}")
