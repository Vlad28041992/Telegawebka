import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from config.settings import dp
from database.db_operations import get_db_connection
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

@dp.message_handler(lambda m: m.text == '🏆 Конкурс рефералов', state='*')
async def open_contest_menu(message: types.Message, state: FSMContext):
    await state.finish()
    try:
        text, kb = await build_contest_view(message.from_user.id)
        await message.answer(text, parse_mode='HTML', reply_markup=kb)
    except Exception as e:
        logging.error(f'contest open error: {e}', exc_info=True)
        await message.answer('❌ Не удалось открыть раздел конкурса. Попробуйте позже.')

@dp.message_handler(commands=['contest'], state='*')
async def cmd_contest(message: types.Message, state: FSMContext):
    await state.finish()
    await open_contest_menu(message, state)

async def build_contest_view(user_id: int):
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    from config.settings import CONTEST_ID
    conn = get_db_connection()
    if not conn:
        raise RuntimeError('db_connection_failed')
    cur = conn.cursor()

    # Проверяем, активен ли конкурс
    cur.execute('SELECT is_active FROM referral_contests WHERE id=%s', (CONTEST_ID,))
    contest_active_row = cur.fetchone()
    is_contest_active = contest_active_row[0] if contest_active_row else True

    # User stats
    cur.execute(
        """SELECT qualified_count, hold_count, pending_count, rejected_count
           FROM referral_contest_stats WHERE contest_id=%s AND referrer_id=%s""",
        (CONTEST_ID, user_id)
    )
    row = cur.fetchone()
    if row:
        qualified, hold, pending, rejected = row
    else:
        qualified, hold, pending, rejected = 0, 0, 0, 0

    # Place (approx rank)
    place = None
    if qualified > 0:
        cur.execute(
            """SELECT COUNT(*) + 1 FROM referral_contest_stats
                   WHERE contest_id=%s AND qualified_count > %s""",
            (CONTEST_ID, qualified)
        )
        place = cur.fetchone()[0]

    # Leaderboard top 10
    cur.execute(
        """SELECT s.referrer_id, s.qualified_count, s.hold_count, s.pending_count, u.username, u.full_name
             FROM referral_contest_stats s LEFT JOIN users u ON u.user_id=s.referrer_id
             WHERE s.contest_id=%s AND s.qualified_count > 0
             ORDER BY s.qualified_count DESC, s.updated_at ASC LIMIT 10""",
        (CONTEST_ID,)
    )
    rows = cur.fetchall()

    cur.execute('SELECT name, start_at, end_at, hold_hours, rules_text FROM referral_contests WHERE id=%s', (CONTEST_ID,))
    contest_info = cur.fetchone()
    cur.close(); conn.close()

    lb_lines = []
    for idx, r in enumerate(rows, 1):
        rid, q, h, p, uname, fname = r
        disp = (('@' + uname) if uname else (fname or str(rid)))
        
        # Добавляем эмодзи короны для лидера
        if idx == 1:
            medal = '👑'
        elif idx == 2:
            medal = '🥈'
        elif idx == 3:
            medal = '🥉'
        else:
            medal = f'{idx}.'
        
        # Если конкурс завершен и у кого-то >= 100 рефералов
        if not is_contest_active and q >= 100:
            lb_lines.append(f'{medal} {disp}: <b>{q}</b> ✅ ПОБЕДИТЕЛЬ! 🏆')
        else:
            lb_lines.append(f'{medal} {disp}: <b>{q}</b> засчитано (+{h} холд, +{p} ожидание)')
    
    leaderboard_text = '\n'.join(lb_lines) if lb_lines else 'Еще никто не засчитан. Будь первым!'

    name = (contest_info[0] if contest_info else 'Конкурс рефералов')
    hold_h = (contest_info[3] if contest_info else 24)

    parts = []
    parts.append(f'🏆 <b>{name}</b>')
    parts.append('')
    
    # Если конкурс завершен
    if not is_contest_active:
        parts.append('🔴 <b>КОНКУРС ЗАВЕРШЕН!</b>')
        if rows and rows[0][1] >= 100:
            winner_name = (('@' + rows[0][4]) if rows[0][4] else (rows[0][5] or str(rows[0][0])))
            parts.append(f'🎉 Победитель: <b>{winner_name}</b>')
        parts.append('')
    
    parts.append('Твоя статистика:')
    parts.append(f'• Засчитано: <b>{qualified}</b> / 100')
    parts.append(f'• На холде: <b>{hold}</b>')
    parts.append(f'• В ожидании: <b>{pending}</b>')
    parts.append(f'• Отклонено: <b>{rejected}</b>')
    if place:
        parts.append(f'• Твое место в топе: <b>{place}</b>')
    parts.append('')
    
    if is_contest_active:
        parts.append(f'Холд для зачета реферала: <b>{hold_h} ч.</b>')
        parts.append(f'🎯 <b>До победы осталось: {max(0, 100 - qualified)} рефералов</b>')
        parts.append('')
    
    parts.append('<b>Топ-10:</b>')
    parts.append(leaderboard_text)

    text = '\n'.join(parts)

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton('🔄 Обновить', callback_data='contest_refresh'),
        InlineKeyboardButton('📜 Правила', callback_data='contest_rules')
    )
    return text, kb

@dp.callback_query_handler(lambda c: c.data and c.data == 'contest_refresh', state='*')
async def contest_refresh(call: types.CallbackQuery, state: FSMContext):
    try:
        new_text, kb = await build_contest_view(call.from_user.id)
        
        try:
            await call.message.edit_text(new_text, parse_mode='HTML', reply_markup=kb)
            await call.answer('Обновлено ✅')
        except Exception as edit_error:
            error_msg = str(edit_error)
            if 'message is not modified' in error_msg.lower():
                await call.answer('Актуально ✅')
            else:
                raise
    except Exception as e:
        logging.error(f'contest refresh error: {e}', exc_info=True)
        try:
            await call.answer('Ошибка при обновлении', show_alert=True)
        except Exception:
            pass

@dp.callback_query_handler(lambda c: c.data and c.data == 'contest_rules', state='*')
async def contest_rules(call: types.CallbackQuery, state: FSMContext):
    from config.settings import CONTEST_ID
    conn = get_db_connection()
    rules = 'Правила будут объявлены позже.'
    try:
        cur = conn.cursor()
        cur.execute('SELECT rules_text FROM referral_contests WHERE id=%s', (CONTEST_ID,))
        r = cur.fetchone()
        if r and r[0]:
            rules = r[0]
        cur.close(); conn.close()
    except Exception as e:
        logging.error(f'contest rules error: {e}', exc_info=True)
        try:
            conn.close()
        except Exception:
            pass
    rules = rules if len(rules) <= 3500 else rules[:3500] + '…'
    new_text = f"📜 <b>Правила конкурса</b>\n\n{rules}"
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton('◀️ Назад', callback_data='contest_back'))
    try:
        try:
            await call.message.edit_text(new_text, parse_mode='HTML', reply_markup=kb)
            await call.answer()
        except Exception as edit_error:
            error_msg = str(edit_error)
            if 'message is not modified' in error_msg.lower():
                await call.answer('Актуально ✅')
            else:
                raise
    except Exception as e:
        logging.error(f'contest rules edit error: {e}', exc_info=True)
        try:
            await call.answer('Ошибка', show_alert=True)
        except Exception:
            pass

@dp.callback_query_handler(lambda c: c.data and c.data == 'contest_back', state='*')
async def contest_back(call: types.CallbackQuery, state: FSMContext):
    try:
        new_text, kb = await build_contest_view(call.from_user.id)
        try:
            await call.message.edit_text(new_text, parse_mode='HTML', reply_markup=kb)
            await call.answer()
        except Exception as edit_error:
            error_msg = str(edit_error)
            if 'message is not modified' in error_msg.lower():
                await call.answer('Актуально ✅')
            else:
                raise
    except Exception as e:
        logging.error(f'contest back error: {e}', exc_info=True)
        try:
            await call.answer('Ошибка', show_alert=True)
        except Exception:
            pass
