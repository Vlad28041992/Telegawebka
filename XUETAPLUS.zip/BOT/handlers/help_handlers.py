# handlers/help_handlers.py
import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from config.settings import dp
from keyboards.main_keyboards import main_keyboard
from keyboards.help_keyboards import help_keyboard

@dp.message_handler(lambda m: m.text == "❓ Помощь", state="*")
async def help_command(message: types.Message, state: FSMContext):
    """Обработчик команды Помощь"""
    logging.info(f"Обработчик help_command вызван пользователем {message.from_user.id}")
    await state.finish()
    
    temp_msg = await message.answer("🔄 Открываю центр поддержки...", reply_markup=types.ReplyKeyboardRemove())
    await temp_msg.delete()

    help_text = """🆘 <b>ЦЕНТР ПОДДЕРЖКИ И ПОМОЩИ</b> 🆘

🎯 <b>НАВИГАЦИЯ ПО БОТУ:</b>
━━━━━━━━━━━━━━━━━━━━━
🚀 <b>Заработать!</b> — главная кнопка для поиска заданий
💰 Цены: от 40₽ до 150₽ за задание
⚡️ Выплаты: от 200₽ мгновенно на карту

😎 <b>Мой Профиль</b> — твой личный кабинет
💳 Баланс, история, вывод средств
📊 Статистика заработка и уровень

🤝 <b>Пригласи Друзей</b> — реферальная программа  
🔥 20% с заработка друзей (1-й уровень)
💎 5% с заработка друзей друзей (2-й уровень)

━━━━━━━━━━━━━━━━━━━━━

❓ <i>Остались вопросы? Выбери нужный раздел ниже!</i>

💪 <b>Мы всегда поможем разобраться!</b>"""

    await message.answer(
        help_text,
        parse_mode="HTML",
        reply_markup=help_keyboard()
    )

@dp.callback_query_handler(lambda c: c.data == 'help_faq')
async def help_faq(callback_query: types.CallbackQuery):
    await callback_query.answer()
    faq_text = """📚 <b>ОТВЕТЫ НА ЧАСТО ЗАДАВАЕМЫЕ ВОПРОСЫ</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❓ <b>1. Что делать, если отзывы не проходят?</b>

🚫 Если отзывы перестали проходить с вашего аккаунта:
• ⏱ <b>Сделайте перерыв минимум на 1 месяц</b>
• 🔴 Аккаунт "заспамился" — проходить больше не будет
• ⛔️ Не пытайтесь писать с него снова раньше времени
• 💡 Используйте другой аккаунт (см. пункт 2)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❓ <b>2. Хочу работать, но отзывы не проходят</b>

✅ <b>Решение проблемы:</b>

🔄 <b>Способ 1 - Очистка устройства:</b>
• 🗑 Очистите кэш браузера/приложения
• 📝 Удалите историю
• 🧹 Удалите все данные, связанные с отзывами
• 🌐 Смените IP-адрес (включите/выключите Wi-Fi или перезагрузите роутер)
• ⚡️ Попробуйте написать отзыв снова

👥 <b>Способ 2 - Другой аккаунт:</b>
• 🤝 Попросите аккаунт у знакомых или родственников
• 📱 Используйте аккаунт с другого устройства

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❓ <b>3. Как быстро выводятся средства?</b>

💰 <b>Сроки вывода:</b>
⏰ От <b>1 до 3 рабочих дней</b>

🚀 Деньги придут на ваш счёт максимально быстро!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❓ <b>4. Сделал всё по инструкции, но отзывы отклоняют</b>

📋 <b>Важная информация:</b>

⚠️ Наша инструкция — это <b>рекомендации</b>, а не 100% гарантия
• 📊 Мы не можем гарантировать прохождение каждого отзыва
• 🎯 Следуйте советам для максимального результата
• 🔄 Если отзывы не проходят → смотрите <b>пункт 2</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ <b>5. КРИТИЧЕСКИ ВАЖНО!</b> ⚠️

🔴 <b>ЗАПРЕЩЕНО УДАЛЯТЬ ОТЗЫВЫ!</b>

❌ <b>Если вы удалите оплаченный отзыв:</b>
• 🔨 Вы будете <b>ЗАБАНЕНЫ НАВСЕГДА</b>
• ⛔️ Доступ к проекту будет заблокирован навечно
• 💀 Без права восстановления аккаунта

💡 <b>Отзывы должны оставаться на месте после оплаты!</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💼 <b>С уважением, команда SeoSerm</b> 💼
🤝 <i>Мы всегда готовы помочь вам заработать!</i>"""
    
    await callback_query.message.edit_text(faq_text, parse_mode="HTML", reply_markup=help_keyboard())


@dp.callback_query_handler(lambda c: c.data == 'help_support')
async def help_support(callback_query: types.CallbackQuery):
    """Открываем бота поддержки"""
    await callback_query.answer()
    text = """🆘 <b>ТЕХНИЧЕСКАЯ ПОДДЕРЖКА</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Для получения персональной помощи перейдите в нашего бота технической поддержки:

🤖 <b>@SeoSerm_SupportBot</b>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<b>В боте поддержки вы сможете:</b>

💰 Узнать про вывод средств
❌ Решить проблемы с отзывами
✅ Узнать про модерацию
📨 Написать напрямую в поддержку

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡️ <b>Мы отвечаем в течение 1-3 часов!</b>

👇 <b>Нажмите кнопку ниже, чтобы открыть бота поддержки</b>"""
    
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton("🆘 Открыть бота поддержки", url="https://t.me/SeoSerm_SupportBot"),
        types.InlineKeyboardButton("🔙 Назад", callback_data="help_back")
    )
    await callback_query.message.edit_text(text, parse_mode="HTML", reply_markup=kb)

@dp.callback_query_handler(lambda c: c.data == 'help_channel')
async def help_channel(callback_query: types.CallbackQuery):
    await callback_query.answer()
    channel_text = """📣 <b>НАШ ОФИЦИАЛЬНЫЙ КАНАЛ</b>

🔥 <b>Подпишись и будь в курсе всего!</b>

🎯 <b>ЧТО ТЕБЯ ЖДЕТ:</b>
━━━━━━━━━━━━━━━━━━
🆕 Новые типы заданий
💰 Эксклюзивные высокооплачиваемые задачи
🎁 Промокоды и бонусы только для подписчиков
📊 Топ заработчиков недели
🏆 Конкурсы с денежными призами
💎 Секретные фишки для увеличения заработка

⚡️ <b>ЭКСКЛЮЗИВ ДЛЯ ПОДПИСЧИКОВ:</b>
• Задания до 300₽ за штуку
• Приоритетная поддержка
• Первые узнают о новых функциях

🔗 <b>ПОДПИСАТЬСЯ:</b> <a href='https://t.me/SeoSermNews'>💎 Перейти в канал</a>

🚀 <b>Присоединяйся к команде профессионалов!</b>"""
    
    await callback_query.message.edit_text(channel_text, parse_mode="HTML", reply_markup=help_keyboard(), disable_web_page_preview=True)

@dp.callback_query_handler(lambda c: c.data == 'help_reviews')
async def help_reviews(callback_query: types.CallbackQuery):
    await callback_query.answer()
    reviews_text = """⭐ <b>ОТЗЫВЫ И РЕПУТАЦИЯ</b>

🏆 <b>Мы гордимся нашей репутацией!</b>

📊 <b>НАША СТАТИСТИКА:</b>
━━━━━━━━━━━━━━━━━━
👥 Статистика Пользователей только формируется.
💰 Выплаты за месяц в разработке.
⭐ 4.9/5 средняя оценка
🎯 Отзывы будут появляться со временем. 

🤝 <b>ОСТАВИТЬ ОТЗЫВ:</b>
Поделись своим опытом и получи +20₽ на баланс!

✨ <b>Твое мнение важно для нас!</b>"""
    
    await callback_query.message.edit_text(reviews_text, parse_mode="HTML", reply_markup=help_keyboard(), disable_web_page_preview=True)

@dp.callback_query_handler(lambda c: c.data == 'help_chat')
async def help_chat(callback_query: types.CallbackQuery):
    await callback_query.answer()
    chat_text = """💬 <b>СООБЩЕСТВО ПРОФЕССИОНАЛОВ</b>

🔥 <b>Присоединяйся к крупнейшему чату заработчиков!</b>

🎯 <b>ЧТО ТЕБЯ ЖДЕТ В ЧАТЕ:</b>
━━━━━━━━━━━━━━━━━━━━
💡 Секреты быстрого заработка
🚀 Лайфхаки от топовых пользователей
🤝 Взаимопомощь и поддержка
🎁 Ежедневные розыгрыши призов
📈 Обсуждение новых заданий
💰 Истории успеха участников

👥 <b>АКТИВНЫЕ УЧАСТНИКИ</b>
• Дружелюбная атмосфера
• Без спама и рекламы
• Модерация 24/7
• Полезный контент каждый день

🏆 <b>ЭКСКЛЮЗИВЫ ДЛЯ УЧАСТНИКОВ ЧАТА:</b>
🎁 Бонусы за активность
💎 Доступ к VIP заданиям
🔥 Первыми узнают о новых акциях

🔗 <b>ПРИСОЕДИНИТЬСЯ:</b>
<a href='https://t.me/+rZHK4bnKGFk5MTVi'>🚀 Войти в чат</a>

💪 <b>Вместе мы зарабатываем больше!</b>

⚠️ <i>Соблюдай правила чата и уважай других участников</i>"""
    
    await callback_query.message.edit_text(chat_text, parse_mode="HTML", reply_markup=help_keyboard(), disable_web_page_preview=True)


@dp.callback_query_handler(lambda c: c.data == 'help_back')
async def help_back(callback_query: types.CallbackQuery):
    await callback_query.answer()
    await callback_query.message.delete()
    await dp.bot.send_message(
        callback_query.from_user.id, 
        "🏠 <b>Добро пожаловать в главное меню!</b>\n\n💪 <i>Готов продолжить зарабатывать?</i>", 
        parse_mode="HTML",
        reply_markup=main_keyboard(callback_query.from_user.id)
    )
