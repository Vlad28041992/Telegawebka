# handlers/task_handlers.py
import logging
import requests
import asyncio
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup

from config.settings import dp, bot, WEB_APP_URL
from database.db_operations import get_user, update_user_balance, add_task_submission
from keyboards.task_keyboards import get_task_menu_keyboard, get_back_to_main_keyboard, get_webapp_keyboard

# URL админ панели для уведомлений
ADMIN_PANEL_URL = "https://adminpanelseoserm-angel2804.amvera.io"

class TaskStates(StatesGroup):
    waiting_for_task_proof = State()

async def notify_admin_about_submission(submission_id, user_id, task_id):
    """Уведомляет админ панель о новом выполнении задания"""
    try:
        data = {
            'submission_id': submission_id,
            'user_id': user_id,
            'task_id': task_id
        }
        
        # Отправляем асинхронный запрос к админ панели
        # В продакшене лучше использовать aiohttp
        def send_request():
            try:
                response = requests.post(
                    f"{ADMIN_PANEL_URL}/api/notify_submission",
                    json=data,
                    timeout=5
                )
                return response.status_code == 200
            except Exception as e:
                logging.error(f"Error notifying admin panel: {e}")
                return False
        
        # Запускаем в отдельном потоке чтобы не блокировать бот
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, send_request)
        
    except Exception as e:
        logging.error(f"Error in notify_admin_about_submission: {e}")

# ============================================
# ВРЕМЕННО ОТКЛЮЧЕНО - Обработчик кнопки "Заработать"
# Пользователи, которые не обновили бота, не смогут перейти
# ============================================
# @dp.message_handler(lambda message: message.text == "💼 Заработать", state="*")
# async def show_task_menu(message: types.Message, state: FSMContext):
#     """Показать меню заданий"""
#     await state.finish()

#     user = get_user(message.from_user.id)
#     if not user:
#         await message.answer("❌ Пользователь не найден в системе. Нажмите /start для регистрации.")
#         return

#     keyboard = get_task_menu_keyboard()

#     await message.answer(
#         "💼 <b>Заработок</b>\n\n"
#         "Выберите способ выполнения заданий:\n\n"
#         "🌐 <b>WebApp заработок</b> - современный интерфейс в веб-приложении\n"
#         "📝 <b>Задания в боте</b> - классический способ через сообщения\n\n"
#         "💡 <i>Рекомендуем WebApp для удобства!</i>",
#         reply_markup=keyboard,
#         parse_mode="HTML"
#     )


@dp.message_handler(lambda message: message.text == "🌐 WebApp заработок", state="*")
async def open_webapp(message: types.Message, state: FSMContext):
    """Открыть WebApp для заработка - ИСПРАВЛЕНО"""
    await state.finish()
    
    user = get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Пользователь не найден в системе. Нажмите /start для регистрации.")
        return
    
    # 🔥 ИСПРАВЛЕНИЕ: Используем функцию с user_id
    webapp_keyboard = get_webapp_keyboard(message.from_user.id)
    
    await message.answer(
        "🌐 <b>WebApp заработок</b>\n\n"
        "Нажмите кнопку ниже, чтобы открыть веб-приложение для выполнения заданий.\n\n"
        "В WebApp вы сможете:\n"
        "• 📋 Просматривать доступные задания\n"
        "• 💰 Видеть размер вознаграждения\n"
        "• 📸 Загружать скриншоты выполнения\n"
        "• 📊 Отслеживать статус проверки\n\n"
        "✨ <i>Удобный интерфейс и быстрое выполнение заданий!</i>",
        reply_markup=webapp_keyboard,
        parse_mode="HTML"
    )

@dp.message_handler(lambda message: message.text == "📝 Задания в боте", state="*")
async def show_bot_tasks(message: types.Message, state: FSMContext):
    """Показать задания в боте (заглушка)"""
    await message.answer(
        "📝 <b>Задания в боте</b>\n\n"
        "🚧 Раздел находится в разработке.\n\n"
        "Пока используйте WebApp заработок для выполнения заданий.",
        parse_mode="HTML"
    )

@dp.callback_query_handler(lambda c: c.data.startswith("task_complete:"))
async def process_task_completion(callback_query: types.CallbackQuery):
    """Обработка завершения задания"""
    task_id = int(callback_query.data.split(":")[1])
    user_id = callback_query.from_user.id
    
    await callback_query.answer("Задание отмечено как выполненное!")
    
    # Здесь можно добавить логику проверки выполнения
    await callback_query.message.edit_text(
        f"✅ Задание #{task_id} отмечено как выполненное!\n\n"
        "Ожидайте проверки модератором.",
        parse_mode="HTML"
    )

@dp.callback_query_handler(lambda c: c.data.startswith("task_cancel:"))
async def process_task_cancellation(callback_query: types.CallbackQuery):
    """Обработка отказа от задания"""
    task_id = int(callback_query.data.split(":")[1])
    
    await callback_query.answer("Вы отказались от задания")
    
    await callback_query.message.edit_text(
        f"❌ Вы отказались от задания #{task_id}\n\n"
        "Можете выбрать другое задание.",
        parse_mode="HTML"
    )
