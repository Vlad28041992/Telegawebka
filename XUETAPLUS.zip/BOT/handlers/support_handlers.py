
import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from config.settings import dp
from states.support_states import SupportStates
from keyboards.support_keyboards import support_menu_kb, ticket_actions_kb
from database.db_operations import (
    create_support_ticket, get_user_tickets, get_ticket_by_id,
    get_ticket_messages, add_support_message, update_ticket_status
)

STATUS_RU = {
    'open': 'Открыт',
    'pending': 'В ожидании',
    'answered': 'С ответом',
    'closed': 'Закрыт'
}


@dp.message_handler(commands=['support'], state='*')
async def cmd_support(message: types.Message, state: FSMContext):
    await state.finish()
    await message.answer('🆘 Центр поддержки. Что делаем?', reply_markup=support_menu_kb())

@dp.message_handler(Text(equals=['ТП','тп','Поддержка','поддержка','🆘 Поддержка'], ignore_case=True), state='*')
async def text_support(message: types.Message, state: FSMContext):
    await cmd_support(message, state)

@dp.callback_query_handler(lambda c: c.data == 'support_list', state='*')
async def cb_support_list(callback: types.CallbackQuery, state: FSMContext):
    tickets = get_user_tickets(callback.from_user.id)
    if not tickets:
        await callback.message.edit_text('У тебя пока нет тикетов. Нажми «Создать тикет», чтобы создать новый.', reply_markup=support_menu_kb())
        await callback.answer()
        return
    kb = types.InlineKeyboardMarkup(row_width=1)
    for t in tickets:
        kb.add(types.InlineKeyboardButton(f"#{t['id']} • {t['subject']} [{STATUS_RU.get(t['status'], t['status'])}]", callback_data=f"support_open:{t['id']}"))
    await callback.message.edit_text('📂 Мои тикеты:', reply_markup=kb)
    await callback.answer()

@dp.callback_query_handler(lambda c: c.data.startswith('support_open:'), state='*')
async def cb_support_open(callback: types.CallbackQuery, state: FSMContext):
    ticket_id = int(callback.data.split(':')[1])
    t = get_ticket_by_id(ticket_id)
    if not t or t.get('user_id') != callback.from_user.id:
        await callback.answer('Тикет не найден', show_alert=True)
        return
    msgs = get_ticket_messages(ticket_id, limit=100)
    lines = [f'Тикет #{ticket_id}', f"<b>{t['subject']}</b>", f"Статус: {STATUS_RU.get(t['status'], t['status'])}", '---']
    for m in (msgs or []):
        sender = 'Пользователь' if m.get('sender') == 'user' else 'Админ'
        created = m.get('created_at')
        created = created if isinstance(created, str) else str(created)
        message_text = m.get('message', '')
        lines.append(f"{sender} | {created}\n{message_text}")
        lines.append('---')
    text = '\n'.join(lines)
    try:
        await callback.message.edit_text(text, parse_mode='HTML', reply_markup=ticket_actions_kb(ticket_id, can_close=t.get('status') != 'closed'))
    except Exception:
        await callback.message.answer(text, parse_mode='HTML', reply_markup=ticket_actions_kb(ticket_id, can_close=t.get('status') != 'closed'))
    await callback.answer()
@dp.callback_query_handler(lambda c: c.data == 'support_create', state='*')
async def cb_support_create(callback: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await SupportStates.waiting_subject.set()
    await callback.message.edit_text('📝 Введи тему тикета (коротко):')
    await callback.answer()

@dp.message_handler(state=SupportStates.waiting_subject)
async def support_subject(message: types.Message, state: FSMContext):
    await state.update_data(subject=(message.text or '').strip()[:200])
    await SupportStates.waiting_message.set()
    await message.answer('✍️ Опиши проблему подробно:')

@dp.message_handler(state=SupportStates.waiting_message)
async def support_message(message: types.Message, state: FSMContext):
    data = await state.get_data()
    subject = data.get('subject')
    text = (message.text or '').strip()
    user = message.from_user
    tid = create_support_ticket(user.id, user.username or '', f"{user.first_name or ''} {user.last_name or ''}".strip(), subject, text)
    if not tid:
        await message.answer('❌ Не удалось создать тикет. Попробуй позже.')
        await state.finish()
        return
    await state.finish()
    await message.answer(f'✅ Тикет #{tid} создан! Мы ответим как можно скорее.')

@dp.callback_query_handler(lambda c: c.data.startswith('support_reply:'), state='*')
async def cb_support_reply(callback: types.CallbackQuery, state: FSMContext):
    ticket_id = int(callback.data.split(':')[1])
    t = get_ticket_by_id(ticket_id)
    if not t or t.get('user_id') != callback.from_user.id:
        await callback.answer('Тикет не найден', show_alert=True)
        return
    if (t.get('status') or '').lower() == 'closed':
        await callback.answer('Этот тикет закрыт. Ответить нельзя.', show_alert=True)
        return
    await state.update_data(ticket_id=ticket_id)
    await SupportStates.waiting_reply_message.set()
    await callback.message.answer('💬 Напиши сообщение для поддержки:')
    await callback.answer()

@dp.message_handler(state=SupportStates.waiting_reply_message)
async def support_reply_message(message: types.Message, state: FSMContext):
    data = await state.get_data()
    ticket_id = data.get('ticket_id')
    text = (message.text or '').strip()
    if not ticket_id or not text:
        await message.answer('Сообщение пустое.')
        return
    t = get_ticket_by_id(ticket_id)
    if not t or (t.get('status') or '').lower() == 'closed':
        await state.finish()
        await message.answer('❌ Тикет закрыт. Нельзя отправить сообщение.')
        return
    add_support_message(ticket_id, 'user', text)
    update_ticket_status(ticket_id, 'pending')
    await state.finish()
    await message.answer('✅ Сообщение отправлено в поддержку.')

@dp.callback_query_handler(lambda c: c.data.startswith('support_close:'), state='*')
async def cb_support_close(callback: types.CallbackQuery, state: FSMContext):
    ticket_id = int(callback.data.split(':')[1])
    t = get_ticket_by_id(ticket_id)
    if not t or t.get('user_id') != callback.from_user.id:
        await callback.answer('Тикет не найден', show_alert=True)
        return
    update_ticket_status(ticket_id, 'closed')
    await callback.message.edit_text(f'✅ Тикет #{ticket_id} закрыт.')
    await callback.answer('Тикет закрыт')