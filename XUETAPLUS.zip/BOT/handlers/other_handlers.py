# handlers/other_handlers_fixed.py
"""
ПОЛНОСТЬЮ ИСПРАВЛЕННЫЕ ОБРАБОТЧИКИ ВЫПЛАТ - БЕЗ ОШИБОК!
Все проблемы с падением бота после ввода реквизитов исправлены
"""

import logging
import datetime
import time
import asyncio
import os
from aiogram import types
from aiogram.dispatcher import FSMContext
from config.settings import dp, bot, ADMINS, MIN_WITHDRAWAL_AMOUNT
from keyboards.main_keyboards import main_keyboard
from database.db_operations import (
    get_user_balance, get_db_connection, 
    create_withdrawal_request_safe, is_admin,
    process_withdrawal, get_withdraw_request_by_id
)
from states.user_states import WithdrawFlow
from .profile_handlers import get_profile_data


# ========================================
# 🔥 НОВЫЙ ОБРАБОТЧИК - КНОПКА "НА ГЛАВНУЮ"
# ========================================
@dp.message_handler(lambda m: m.text and ("На Главную" in m.text or "На главную" in m.text or "🔙" in m.text), state="*")
async def back_to_main_menu(message: types.Message, state: FSMContext):
    """Обработчик кнопки 'На Главную' - возвращает в главное меню"""
    try:
        await state.finish()
    except Exception:
        pass
    
    await message.answer(
        "🏠 <b>Главное меню</b>\n\nВыбери нужное действие:",
        parse_mode="HTML",
        reply_markup=main_keyboard(message.from_user.id)
    )
    logger.info(f"Пользователь {message.from_user.id} вернулся в главное меню")

# Настройка логирования для отладки
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dp.callback_query_handler(lambda c: c.data == 'profile_withdraw', state='*')
async def profile_withdraw(callback_query: types.CallbackQuery, state: FSMContext):
    """Начало процесса вывода средств - ИСПРАВЛЕНО"""
    try:
        # Очищаем состояние перед началом нового процесса
        await state.finish()
        
        user_id = callback_query.from_user.id
        current_balance = get_user_balance(user_id)
        
        logger.info(f"Пользователь {user_id} начинает процесс вывода, баланс: {current_balance}₽")
        
        if current_balance < MIN_WITHDRAWAL_AMOUNT:
            await callback_query.answer(
                f"❌ Недостаточно средств для вывода.\nМинимум: {MIN_WITHDRAWAL_AMOUNT}₽\nВаш баланс: {current_balance}₽", 
                show_alert=True
            )
            return
        
        # Создаём клавиатуру с методами вывода
        kb = types.InlineKeyboardMarkup(row_width=1)
        kb.add(
            types.InlineKeyboardButton("⚡️ СБП (Комиссия 0%)", callback_data="withdraw_sbp"),
            types.InlineKeyboardButton("🥝 QIWI (Комиссия 0%)", callback_data="withdraw_qiwi"),
            types.InlineKeyboardButton("💰 ЮMoney (Комиссия 0%)", callback_data="withdraw_yoomoney"),
            types.InlineKeyboardButton("💳 Банковская карта (Комиссия 30Р)", callback_data="withdraw_card"),
            types.InlineKeyboardButton("🔙 Назад к профилю", callback_data="back_to_profile")
        )
        
        await callback_query.message.edit_text(
            f"💳 <b>Вывод средств</b>\n\n"
            f"💰 Ваш баланс: <b>{current_balance}₽</b>\n"
            f"💸 Минимум для вывода: <b>{MIN_WITHDRAWAL_AMOUNT}₽</b>\n"
            f"⚡️ Максимум: <b>50000₽</b>\n\n"
            f"Выберите способ вывода:", 
            parse_mode="HTML",
            reply_markup=kb
        )
        
        await WithdrawFlow.choosing_method.set()
        await callback_query.answer()
        
        logger.info(f"✅ Пользователь {user_id} перешёл к выбору метода вывода")
        
    except Exception as e:
        logger.error(f"❌ Ошибка profile_withdraw для пользователя {callback_query.from_user.id}: {e}")
        await callback_query.answer("❌ Произошла ошибка. Попробуйте позже.", show_alert=True)
        try:
            await state.finish()
        except:
            pass

@dp.callback_query_handler(lambda c: c.data.startswith('withdraw_') and not c.data.startswith('withdraw_action:'), state=WithdrawFlow.choosing_method)
async def withdraw_choose_method(call: types.CallbackQuery, state: FSMContext):
    """Выбор метода вывода - ИСПРАВЛЕНО"""
    try:
        method_mapping = {
            'withdraw_sbp': 'СБП',
            'withdraw_qiwi': 'QIWI',
            'withdraw_yoomoney': 'ЮMoney', 
            'withdraw_card': 'Банковская карта'
        }
        
        method = method_mapping.get(call.data, call.data.replace('withdraw_', ''))
        await state.update_data(method=method, method_key=call.data.replace('withdraw_', ''))
        
        current_balance = get_user_balance(call.from_user.id)
        
        logger.info(f"Пользователь {call.from_user.id} выбрал метод вывода: {method}")
        
        await call.message.edit_text(
            f"💳 <b>Способ вывода:</b> {method}\n"
            f"💰 <b>Доступно:</b> {current_balance}₽\n\n"
            f"💸 Введите сумму для вывода (от {MIN_WITHDRAWAL_AMOUNT}₽ до 50000₽):\n\n"
            f"💡 <i>Введите только число, например: 500</i>",
            parse_mode="HTML"
        )
        
        await WithdrawFlow.entering_amount.set()
        await call.answer()
        
    except Exception as e:
        logger.error(f"❌ Ошибка withdraw_choose_method для пользователя {call.from_user.id}: {e}")
        await call.answer("❌ Ошибка выбора метода", show_alert=True)
        try:
            await state.finish()
        except:
            pass

@dp.callback_query_handler(lambda c: c.data == 'back_to_profile', state='*')
async def back_to_profile_from_stats(call: types.CallbackQuery, state: FSMContext):
    try:
        await state.finish()
        user_id = call.from_user.id
        profile_data = await asyncio.get_event_loop().run_in_executor(None, get_profile_data, user_id)
        if not profile_data:
            await call.message.edit_text('❌ Произошла ошибка при загрузке профиля.')
            await call.answer()
            return
        profile_kb = types.InlineKeyboardMarkup(row_width=2)
        profile_kb.add(
            types.InlineKeyboardButton('📊 Статистика', callback_data='profile_stats'),
            types.InlineKeyboardButton('🏆 Топ пользователей', callback_data='profile_top'),
            types.InlineKeyboardButton('💳 Вывод средств', callback_data='profile_withdraw')
        )
        profile_text = f"""👤 <b>Мой Профиль:</b>

💸 <b>Реальные деньги (₽):</b>
  💰 Баланс: <b>{profile_data['balance']} ₽</b>
  💵 Заработано за неделю: <b>{profile_data['weekly_earnings']:.2f} ₽</b>
  💵 Всего заработано: <b>{profile_data['total_earnings_calc']:.2f} ₽</b>
  📝 На заданиях: <b>{profile_data['earnings_from_tasks_calc']:.2f} ₽</b>
  🎁 С рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>

🏅 <b>Игровые баллы:</b>
  🏅 Баллы: <b>{profile_data['points']}</b>
  ✨ Баллы за неделю: <b>{profile_data['weekly_points_calc']}</b>
  📊 Всего баллов: <b>{profile_data['total_points_calc']}</b>

📈 <b>Статистика:</b>
  🧑‍💻 Заданий на проверке: <b>{profile_data['on_check']}</b>
  ✅ Выполнено заданий: <b>{profile_data['completed_tasks']}</b>

🤝 <b>Реферальная программа:</b>
  👥 Приглашено друзей: <b>{profile_data['total_referrals']}</b>
  🥇 Рефералы 1 уровня: <b>{profile_data['ref_1_level']}</b>
  🥈 Рефералы 2 уровня: <b>{profile_data['ref_2_level']}</b>
  🎁 Доход от рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>

"""
        await call.message.edit_text(profile_text, parse_mode='HTML', reply_markup=profile_kb)
        await call.answer('↩️ Возврат к профилю')
    except Exception as e:
        logger.error(f'❌ Ошибка возврата к профилю: {e}')
        await call.answer('❌ Ошибка', show_alert=True)
@dp.message_handler(state=WithdrawFlow.entering_amount)
async def withdraw_enter_amount(message: types.Message, state: FSMContext):
    """Ввод суммы вывода - ПОЛНОСТЬЮ ИСПРАВЛЕНО"""
    try:
        user_id = message.from_user.id
        input_text = message.text.strip()
        
        logger.info(f"Пользователь {user_id} ввёл сумму: '{input_text}'")
        
        # Удаляем сообщение пользователя для чистоты
        try:
            await message.delete()
        except:
            pass
        
        # Валидация ввода - только цифры
        if not input_text.replace('.', '').replace(',', '').isdigit():
            await message.answer(
                "🔢 <b>Ошибка ввода!</b>\n\n"
                "Введите сумму только цифрами без пробелов и символов\n"
                "Например: <code>500</code> или <code>1000</code>\n\n"
                "💡 <i>Попробуйте ещё раз:</i>",
                parse_mode="HTML"
            )
            return
            
        # Конвертируем в целое число
        try:
            amount = int(float(input_text.replace(',', '.')))
        except ValueError:
            await message.answer(
                "❌ <b>Некорректная сумма!</b>\n\n"
                "Введите число от {MIN_WITHDRAWAL_AMOUNT} до 50000\n"
                "Например: <code>500</code>",
                parse_mode="HTML"
            )
            return
        
        # Проверяем лимиты
        if amount < MIN_WITHDRAWAL_AMOUNT:
            await message.answer(
                f"❗ <b>Минимальная сумма вывода - {MIN_WITHDRAWAL_AMOUNT}₽</b>\n\n"
                f"💡 Введите сумму от {MIN_WITHDRAWAL_AMOUNT}₽ до 50000₽", 
                parse_mode="HTML"
            )
            return
            
        if amount > 50000:
            await message.answer(
                "❗ <b>Максимальная сумма вывода - 50000₽</b>\n\n"
                "💡 Введите сумму до 50000₽", 
                parse_mode="HTML"
            )
            return
            
        # Проверяем баланс пользователя
        actual_balance = get_user_balance(user_id)
        
        if amount > actual_balance:
            await message.answer(
                f"❌ <b>Недостаточно средств!</b>\n\n"
                f"💰 На балансе: <b>{actual_balance}₽</b>\n"
                f"💸 Пытаетесь вывести: <b>{amount}₽</b>\n\n"
                f"Введите сумму до <b>{actual_balance}₽</b>",
                parse_mode="HTML"
            )
            return
        
        # Сохраняем сумму и переходим к реквизитам
        await state.update_data(amount=amount)
        
        data = await state.get_data()
        method = data.get('method', 'Неизвестно')
        
        logger.info(f"✅ Пользователь {user_id} ввёл валидную сумму {amount}₽ для метода {method}")
        
        # Инструкции по вводу реквизитов
        # Для СБП спрашиваем банк перед реквизитами
        if method == 'СБП':
            await message.answer(
                f"💸 <b>Сумма вывода:</b> {amount}₽\n"
                f"💳 <b>Способ:</b> {method}\n\n"
                f"🏦 <b>Введите название банка</b> (например: Сбербанк, Тинькофф, ВТБ, Альфа-Банк и т.д.)\n\n"
                f"⚠️ <i>Укажите банк, к которому привязан ваш номер телефона в СБП</i>",
                reply_markup=types.ReplyKeyboardRemove(),
                parse_mode='HTML'
            )
            await WithdrawFlow.entering_bank.set()
            return
        
        instructions = {
            'СБП': '⚡️ Введите номер телефона и ФИО получателя\n<b>Формат:</b> <code>+79001234567 Иванов Иван Иванович</code>\n\n⚠️ <i>Внимательно проверьте данные!</i>',
            'QIWI': '📱 Введите номер QIWI кошелька\nНапример: <code>+79001234567</code>',
            'ЮMoney': '💰 Введите номер ЮMoney кошелька\nНапример: <code>410011234567890</code>', 
            'Банковская карта': '💳 Введите номер банковской карты\nНапример: <code>1111 2222 3333 4444</code>'
        }
        
        instruction = instructions.get(method, '💳 Введите реквизиты для вывода')
        
        await message.answer(
            f"💸 <b>Сумма вывода:</b> {amount}₽\n"
            f"💳 <b>Способ:</b> {method}\n\n"
            f"{instruction}\n\n"
            f"⚠️ <i>Проверьте реквизиты перед отправкой!</i>",
            parse_mode="HTML"
        )
        
        await WithdrawFlow.entering_details.set()
        
    except Exception as e:
        logger.error(f"❌ Критическая ошибка withdraw_enter_amount для пользователя {message.from_user.id}: {e}")
        await message.answer(
            "❌ <b>Произошла ошибка!</b>\n\n"
            "Попробуйте начать заново или обратитесь в поддержку.",
            parse_mode="HTML",
            reply_markup=main_keyboard(message.from_user.id)
        )
        try:
            await state.finish()
        except:
            pass



@dp.message_handler(state=WithdrawFlow.entering_bank)
async def withdraw_enter_bank(message: types.Message, state: FSMContext):
    """Ввод названия банка для СБП"""
    try:
        bank_name = message.text.strip()
        user_id = message.from_user.id
        
        # Валидация названия банка
        if len(bank_name) < 3:
            await message.answer(
                "❌ <b>Название банка слишком короткое!</b>\n\n"
                "💡 Введите корректное название банка (минимум 3 символа)",
                parse_mode='HTML'
            )
            return
        
        if len(bank_name) > 100:
            await message.answer(
                "❌ <b>Название банка слишком длинное!</b>\n\n"
                "💡 Введите название банка (максимум 100 символов)",
                parse_mode='HTML'
            )
            return
        
        # Сохраняем банк в state
        await state.update_data(bank_name=bank_name)
        
        # Получаем сохранённые данные
        data = await state.get_data()
        amount = data.get('amount')
        method = data.get('method', 'СБП')
        
        logger.info(f"Пользователь {user_id} указал банк: {bank_name}")
        
        # Переходим к вводу реквизитов
        await message.answer(
            f"💸 <b>Сумма вывода:</b> {amount}₽\n"
            f"💳 <b>Способ:</b> {method}\n"
            f"🏦 <b>Банк:</b> {bank_name}\n\n"
            f"⚡️ Теперь введите <b>номер телефона и ФИО получателя</b>\n"
            f"<b>Формат:</b> <code>+79001234567 Иванов Иван Иванович</code>\n\n"
            f"⚠️ <i>Внимательно проверьте данные!</i>",
            reply_markup=types.ReplyKeyboardRemove(),
            parse_mode='HTML'
        )
        
        await WithdrawFlow.entering_details.set()
        
    except Exception as e:
        logger.error(f"❌ Ошибка withdraw_enter_bank для пользователя {message.from_user.id}: {e}")
        await message.answer(
            "❌ <b>Произошла ошибка</b>\n\n"
            "Попробуйте ещё раз или обратитесь в поддержку.",
            parse_mode='HTML'
        )
        await state.finish()


@dp.message_handler(state=WithdrawFlow.entering_details)
async def withdraw_enter_details(message: types.Message, state: FSMContext):
    """Ввод реквизитов и создание заявки - КРИТИЧЕСКИ ИСПРАВЛЕНО"""
    try:
        user_id = message.from_user.id
        details = message.text.strip()
        
        logger.info(f"🔄 Пользователь {user_id} вводит реквизиты: {details[:10]}...")
        
        # Удаляем сообщение с реквизитами для безопасности
        try:
            await message.delete()
        except:
            pass
        
        
        # Получаем данные из состояния
        data = await state.get_data()
        amount = data.get('amount')
        method = data.get('method', 'Неизвестно')
        
        # ВАЛИДАЦИЯ РЕКВИЗИТОВ ДЛЯ СБП
        if method == 'СБП':
            # Проверяем формат: номер телефона + ФИО
            parts = details.split(maxsplit=1)
            if len(parts) < 2:
                await message.answer(
                    "❌ <b>Некорректный формат данных для СБП!</b>\\n\\n"
                    "Введите номер телефона и ФИО через пробел:\\n"
                    "<b>Формат:</b> <code>+79001234567 Иванов Иван Иванович</code>\\n\\n"
                    "💡 <i>Попробуйте ещё раз:</i>",
                    parse_mode="HTML"
                )
                return
            
            phone = parts[0]
            full_name = parts[1]
            
            # Проверяем номер телефона (должен начинаться с + или цифры)
            if not phone.replace('+', '').replace(' ', '').replace('-', '').replace('(', '').replace(')', '').isdigit():
                await message.answer(
                    "❌ <b>Некорректный номер телефона!</b>\\n\\n"
                    "Введите корректный номер телефона:\\n"
                    "Например: <code>+79001234567</code> или <code>89001234567</code>\\n\\n"
                    "💡 <i>Попробуйте ещё раз:</i>",
                    parse_mode="HTML"
                )
                return
            
            # Проверяем ФИО (минимум 2 слова)
            if len(full_name.split()) < 2:
                await message.answer(
                    "❌ <b>Некорректное ФИО!</b>\\n\\n"
                    "Введите полное ФИО (минимум Фамилия и Имя):\\n"
                    "Например: <code>Иванов Иван</code> или <code>Иванов Иван Иванович</code>\\n\\n"
                    "💡 <i>Попробуйте ещё раз:</i>",
                    parse_mode="HTML"
                )
                return
            
            logger.info(f"✅ СБП реквизиты валидны для пользователя {user_id}: {phone} {full_name}")
        
        # Валидация реквизитов
        if len(details) < 5:
            await message.answer(
                "❌ <b>Некорректные реквизиты!</b>\n\n"
                "Введите корректные реквизиты (минимум 5 символов)\n"
                "Пример для СБП: <code>+79001234567 Иванов Иван</code>\n"
                "Пример для QIWI: <code>+79001234567</code>\n"
                "Пример для карты: <code>1111 2222 3333 4444</code>",
                parse_mode="HTML"
            )
            return
        
        if len(details) > 100:
            await message.answer(
                "❌ <b>Слишком длинные реквизиты!</b>\n\n"
                "Максимум 100 символов. Введите корректные данные.",
                parse_mode="HTML"
            )
            return

        # Получаем данные из состояния
        data = await state.get_data()
        amount = data.get('amount')
        method = data.get('method', 'Неизвестно')
        bank_name = data.get('bank_name')  # Получаем название банка (если есть)
        
        if not amount:
            logger.error(f"❌ Пользователь {user_id}: сумма не найдена в состоянии!")
            await message.answer(
                "❌ <b>Ошибка: сумма не определена</b>\n\n"
                "Начните процесс вывода заново.", 
                reply_markup=main_keyboard(user_id)
            )
            await state.finish()
            return

        logger.info(f"📝 Создание заявки: пользователь {user_id}, сумма {amount}₽, метод {method}")
        
        # Показываем пользователю что запрос обрабатывается
        processing_msg = await message.answer(
            "⏳ <b>Обрабатываем заявку...</b>\n\n"
            "Пожалуйста, подождите несколько секунд.",
            parse_mode="HTML"
        )
        
        # КРИТИЧЕСКИ ВАЖНО: Используем безопасную функцию создания заявки
        loop = asyncio.get_event_loop()
        success, message_text, request_id = await loop.run_in_executor(
            None, lambda: create_withdrawal_request_safe(user_id, amount, method, details, bank_name)
        )
        
        # Удаляем сообщение об обработке
        try:
            await processing_msg.delete()
        except:
            pass
        
        if not success:
            logger.error(f"❌ Ошибка создания заявки для пользователя {user_id}: {message_text}")
            await message.answer(
                f"❌ <b>Ошибка создания заявки!</b>\n\n"
                f"{message_text}\n\n"
                f"Попробуйте ещё раз или обратитесь в поддержку.",
                parse_mode="HTML",
                reply_markup=main_keyboard(user_id)
            )
            await state.finish()
            return
        
        # ✅ УСПЕХ! Заявка создана
        logger.info(f"✅ Заявка #{request_id} успешно создана для пользователя {user_id}")
        
        await message.answer(
            f"✅ <b>Заявка на вывод создана!</b>\n\n"
            f"📋 <b>Заявка №:</b> {request_id}\n"
            f"💸 <b>Сумма:</b> {amount}₽\n"
            f"💳 <b>Способ:</b> {method}\n"
            f"📝 <b>Реквизиты:</b> <code>{details}</code>\n\n"
            f"⏳ <b>Статус:</b> На рассмотрении\n"
            f"🕐 <b>Срок перевода:</b> ⏳ Срок перевода от 1 до 3 дней\n"
            f"📬 Вы получите уведомление о статусе заявки!",
            parse_mode="HTML",
            reply_markup=main_keyboard(user_id)
        )
        
        # Завершаем состояние
        await state.finish()

        # Уведомляем админов о новой заявке (безопасно)
        # Админ-уведомления отключены: управление выводами через отдельную админ-панель
            
    except Exception as e:
        logger.error(f"❌ КРИТИЧЕСКАЯ ОШИБКА withdraw_enter_details для пользователя {message.from_user.id}: {e}")
        
        try:
            await state.finish()
        except:
            pass
            
        await message.answer(
            "❌ <b>Произошла техническая ошибка!</b>\n\n"
            "Попробуйте создать заявку позже или обратитесь в поддержку.\n\n"
            "🆘 <b>Поддержка:</b> @support (если есть)",
            parse_mode="HTML",
            reply_markup=main_keyboard(message.from_user.id)
        )

# ============= АДМИНСКИЕ ОБРАБОТЧИКИ =============

@dp.callback_query_handler(lambda c: c.data.startswith("approve_withdraw:") or c.data.startswith("reject_withdraw:"))
async def process_withdraw_action(callback_query: types.CallbackQuery):
    """Обработка одобрения/отклонения заявки админом - ИСПРАВЛЕНО"""
    try:
        if not is_admin(callback_query.from_user.id):
            await callback_query.answer("⛔️ У вас нет прав для этого действия!", show_alert=True)
            return

        action, request_id = callback_query.data.split(":")
        request_id = int(request_id)
        admin_id = callback_query.from_user.id

        logger.info(f"🔧 Админ {admin_id} обрабатывает заявку #{request_id}, действие: {action}")

        # Получаем данные заявки
        request_data = get_withdraw_request_by_id(request_id)
        if not request_data:
            await callback_query.answer("❌ Заявка не найдена!", show_alert=True)
            return

        user_id = request_data[1]  # user_id
        amount = request_data[2]   # amount

        if action == "approve_withdraw":
            success, result_message = process_withdrawal(request_id, 'approve', admin_id, "Одобрено администратором")
            
            if success:
                await callback_query.message.edit_text(
                    callback_query.message.text + "\n\n✅ <b>ОДОБРЕНО</b> администратором",
                    parse_mode="HTML"
                )
                
                # Уведомляем пользователя об одобрении
                try:
                    await bot.send_message(
                        user_id,
                        f"✅ <b>Заявка на вывод #{request_id} одобрена!</b>\n\n"
                        f"💸 <b>Сумма:</b> {amount}₽\n"
                        f"⏳ Выплата будет произведена в течение 1–3 дней\n",
                        parse_mode="HTML"
                    )
                    logger.info(f"✅ Пользователь {user_id} уведомлен об одобрении заявки #{request_id}")
                except Exception as notify_error:
                    logger.error(f"❌ Ошибка уведомления пользователя {user_id}: {notify_error}")
                
                await callback_query.answer("✅ Заявка одобрена!")
            else:
                await callback_query.answer(f"❌ Ошибка: {result_message}", show_alert=True)

        elif action == "reject_withdraw":
            success, result_message = process_withdrawal(request_id, 'reject', admin_id, "Отклонено администратором")
            
            if success:
                await callback_query.message.edit_text(
                    callback_query.message.text + "\n\n❌ <b>ОТКЛОНЕНО</b> администратором",
                    parse_mode="HTML"
                )
                
                # Уведомляем пользователя об отклонении
                try:
                    await bot.send_message(
                        user_id,
                        f"❌ <b>Заявка на вывод #{request_id} отклонена</b>\n\n"
                        f"💵 <b>Сумма {amount}₽ возвращена на баланс</b>\n"
                        f"📝 Причина: Отклонено администратором\n\n"
                        f"Вы можете создать новую заявку в любое время.",
                        parse_mode="HTML"
                    )
                    logger.info(f"✅ Пользователь {user_id} уведомлен об отклонении заявки #{request_id}")
                except Exception as notify_error:
                    logger.error(f"❌ Ошибка уведомления пользователя {user_id}: {notify_error}")
                
                await callback_query.answer("❌ Заявка отклонена, средства возвращены!")
            else:
                await callback_query.answer(f"❌ Ошибка: {result_message}", show_alert=True)

    except ValueError:
        await callback_query.answer("❌ Неверный ID заявки", show_alert=True)
    except Exception as e:
        logger.error(f"❌ Критическая ошибка process_withdraw_action: {e}")
        await callback_query.answer("❌ Произошла ошибка при обработке заявки", show_alert=True)

# ============= ДОПОЛНИТЕЛЬНЫЕ ОБРАБОТЧИКИ =============

@dp.message_handler(content_types=['web_app_data'])
async def process_webapp_data(message: types.Message):
    """Обработчик данных от WebApp"""
    user_id = message.from_user.id
    web_app_data = message.web_app_data.data
    
    logger.info(f"Получены данные от WebApp для пользователя {user_id}: {web_app_data}")
    
    try:
        import json
        data = json.loads(web_app_data)
        
        await message.answer("✅ Данные успешно получены!", reply_markup=main_keyboard(user_id))
        
    except Exception as e:
        logger.error(f"Ошибка при обработке данных WebApp: {e}")
        await message.answer("❌ Ошибка при обработке данных.", reply_markup=main_keyboard(user_id))

# Логируем успешную загрузку
logger.info("✅ ИСПРАВЛЕННЫЕ обработчики выплат загружены успешно - БЕЗ ОШИБОК!")