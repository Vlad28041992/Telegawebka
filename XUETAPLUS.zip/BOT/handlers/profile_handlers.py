# handlers/profile_handlers.py - ИСПРАВЛЕНА СТАТИСТИКА
import logging
import datetime
import asyncio
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from config.settings import dp, bot
from utils.safe_send import safe_answer
from keyboards.main_keyboards import main_keyboard, back_to_menu_kb_reply
from keyboards.profile_keyboards import profile_keyboard, top_keyboard, top_period_keyboard
from database.connection import get_connection
from database.db_operations import get_user_balance, get_db_connection

def get_profile_data(user_id):
    """Исправленная функция для получения данных профиля"""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Базовые данные пользователя из таблицы users
        cursor.execute("""
            SELECT
                balance, points, total_points, total_earnings, earnings_from_tasks,
                referral_1_level, referral_2_level, earnings_from_referrals,
                referral_earnings_1, referral_earnings_2
            FROM users WHERE user_id=%s
        """, (user_id,))
        user_data = cursor.fetchone()
        
        if user_data is None:
            return None
            
        balance, points, total_points, total_earnings, earnings_from_tasks, ref_1_level, ref_2_level, earnings_from_referrals, ref_earn_1, ref_earn_2 = user_data

        # ИСПРАВЛЕНИЕ 1: Заработок за неделю (по одобренным заданиям)
        cursor.execute("""
            SELECT COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0)
            FROM submissions s
            JOIN tasks t ON s.task_id = t.id
            WHERE s.user_id = %s AND s.status = 'approved'
              AND s.approved_at >= NOW() - INTERVAL '7 days'
        """, (user_id,))
        weekly_earnings_result = cursor.fetchone()
        weekly_earnings = float(weekly_earnings_result[0]) if weekly_earnings_result[0] else 0.0
        
        # ИСПРАВЛЕНИЕ 2: Баллы за неделю (по одобренным заданиям)
        cursor.execute("""
            SELECT COALESCE(SUM(t.reward_points), 0)
            FROM submissions s
            JOIN tasks t ON s.task_id = t.id
            WHERE s.user_id = %s AND s.status = 'approved'
            AND s.approved_at >= NOW() - INTERVAL '7 days'
        """, (user_id,))
        weekly_points_result = cursor.fetchone()
        weekly_points_calc = int(weekly_points_result[0]) if weekly_points_result[0] else 0

        # ИСПРАВЛЕНИЕ 3: Всего баллов из всех одобренных заданий
        cursor.execute("""
            SELECT COALESCE(SUM(t.reward_points), 0)
            FROM submissions s
            JOIN tasks t ON s.task_id = t.id
            WHERE s.user_id = %s AND s.status = 'approved'
        """, (user_id,))
        total_points_result = cursor.fetchone()
        total_points_calc = int(total_points_result[0]) if total_points_result[0] else 0

        # ИСПРАВЛЕНИЕ 4: Доход с заданий (всего) по одобренным заданиям
        cursor.execute("""
            SELECT COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0)
            FROM submissions s
            JOIN tasks t ON s.task_id = t.id
            WHERE s.user_id = %s AND s.status = 'approved'
        """, (user_id,))
        earnings_from_tasks_result = cursor.fetchone()
        earnings_from_tasks_calc = float(earnings_from_tasks_result[0]) if earnings_from_tasks_result[0] else 0.0
        
        # ИСПРАВЛЕНИЕ 5: Доходы от рефералов (из таблицы users)
        ref_earn_1_val = float(ref_earn_1) if ref_earn_1 else 0.0
        ref_earn_2_val = float(ref_earn_2) if ref_earn_2 else 0.0
        earnings_from_referrals_calc = ref_earn_1_val + ref_earn_2_val
        
        # ИСПРАВЛЕНИЕ 6: Статистика заданий
        cursor.execute("SELECT COUNT(*) FROM submissions WHERE user_id=%s AND status='pending'", (user_id,))
        on_check = cursor.fetchone()[0] or 0
        cursor.execute("SELECT COUNT(*) FROM submissions WHERE user_id=%s AND status='approved'", (user_id,))
        completed_tasks = cursor.fetchone()[0] or 0
        
        # ИСПРАВЛЕНИЕ 7: Статистика рефералов 
        cursor.execute("SELECT COUNT(*) FROM users WHERE referrer_id=%s", (user_id,))
        total_referrals = cursor.fetchone()[0] or 0
        
        # ИСПРАВЛЕНИЕ 8: Правильный расчет общего заработка
        total_earnings_calc = earnings_from_tasks_calc + earnings_from_referrals_calc
        
        return {
            'balance': balance or 0,
            'weekly_earnings': weekly_earnings,
            'total_earnings_calc': total_earnings_calc,
            'earnings_from_tasks_calc': earnings_from_tasks_calc,
            'earnings_from_referrals_calc': earnings_from_referrals_calc,
            'points': points or 0,
            'weekly_points_calc': weekly_points_calc,
            'total_points_calc': total_points_calc,
            'on_check': on_check,
            'completed_tasks': completed_tasks,
            'total_referrals': total_referrals,
            'ref_1_level': ref_1_level or 0,
            'ref_2_level': ref_2_level or 0
        }
        
    except Exception as e:
        logging.error(f"Ошибка get_profile_data: {e}")
        return None
    finally:
        if conn: 
            conn.close()

@dp.message_handler(lambda m: m.text == "😎 Мой Профиль", state="*")
async def personal_cabinet(message: types.Message, state: FSMContext):
    logging.info(f"Обработчик profile вызван - текст: {message.text}")
    await state.finish()
    user_id = message.from_user.id
    
    profile_data = await asyncio.get_event_loop().run_in_executor(None, get_profile_data, user_id)
    if not profile_data:
        await message.answer("⚠️ Ой, похоже, вас нет в нашей системе. Нажмите /start для регистрации.", reply_markup=main_keyboard(message.from_user.id))
        return

    profile_text = (
        "👤 <b>Мой Профиль:</b>\n\n"
        "💸 <b>Реальные деньги (₽):</b>\n"
        f"  💰 Баланс: <b>{profile_data['balance']} ₽</b>\n"
        f"  💵 Заработано за неделю: <b>{profile_data['weekly_earnings']:.2f} ₽</b>\n"
        f"  💵 Всего заработано: <b>{profile_data['total_earnings_calc']:.2f} ₽</b>\n"
        f"  📝 На заданиях: <b>{profile_data['earnings_from_tasks_calc']:.2f} ₽</b>\n"
        f"  🎁 С рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>\n\n"
        "🏅 <b>Игровые баллы:</b>\n"
        f"  🏅 Баллы: <b>{profile_data['points']}</b>\n"
        f"  ✨ Баллы за неделю: <b>{profile_data['weekly_points_calc']}</b>\n"
        f"  📊 Всего баллов: <b>{profile_data['total_points_calc']}</b>\n\n"
        "📈 <b>Статистика:</b>\n"
        f"  🧑‍💻 Заданий на проверке: <b>{profile_data['on_check']}</b>\n"
        f"  ✅ Выполнено заданий: <b>{profile_data['completed_tasks']}</b>\n\n"
        "🤝 <b>Реферальная программа:</b>\n"
        f"  👥 Приглашено друзей: <b>{profile_data['total_referrals']}</b>\n"
        f"  🥇 Рефералы 1 уровня: <b>{profile_data['ref_1_level']}</b>\n"
        f"  🥈 Рефералы 2 уровня: <b>{profile_data['ref_2_level']}</b>\n"
        f"  🎁 Доход от рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>\n"
    )
    
    await safe_answer(message, profile_text, parse_mode="HTML", reply_markup=profile_keyboard())
    await safe_answer(message, "Или вернитесь в главное меню:", reply_markup=back_to_menu_kb_reply())

@dp.callback_query_handler(lambda c: c.data == 'profile_stats')
async def profile_stats(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.platform, COUNT(*)
            FROM submissions s
            JOIN tasks t ON s.task_id = t.id
            WHERE s.user_id = %s AND s.status = 'approved'
            GROUP BY t.platform
        ''', (user_id,))
        platform_stats = cursor.fetchall()
        cursor.execute('''
            SELECT COUNT(*)
            FROM submissions s
            WHERE s.user_id = %s AND s.status = 'approved'
        ''', (user_id,))
        total_tasks = cursor.fetchone()[0] or 0
    except Exception as e:
        logging.error(f"Ошибка profile_stats: {e}")
        await callback_query.message.edit_text("❌ Произошла ошибка при загрузке статистики.")
        return
    finally:
        if conn: 
            conn.close()

    stats_text = "📊 <b>Ваша статистика по платформам:</b>\n\n"
    if platform_stats:
        for platform, count in platform_stats:
            stats_text += f"<b>{platform}:</b> {count}\n"
    else:
        stats_text += "Нет выполненных заданий.\n"
    stats_text += f"\n<b>Всего выполнено заданий:</b> {total_tasks}"
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    await callback_query.message.edit_text(stats_text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup().add(
        InlineKeyboardButton("🔙 Назад к Профилю", callback_data="back_to_profile")
    ))
    await callback_query.answer()

@dp.callback_query_handler(lambda c: c.data == 'profile_top')
async def profile_top(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text("Выберите тип топа:", reply_markup=top_keyboard())
    await callback_query.answer()

@dp.callback_query_handler(lambda c: c.data in ['top_money', 'top_points'])
async def top_type_selected(callback_query: types.CallbackQuery):
    top_type = callback_query.data
    await callback_query.message.edit_text("Выберите период:", reply_markup=top_period_keyboard(top_type))
    await callback_query.answer()

@dp.callback_query_handler(lambda c: c.data in [
    'top_money_week', 'top_money_month', 'top_money_all',
    'top_points_week', 'top_points_month', 'top_points_all'
])
async def top_period_selected(callback_query: types.CallbackQuery):
    data = callback_query.data
    parts = data.split('_')
    top_type = parts[1]  # money или points
    period = parts[2]    # week, month, all
    
    now = datetime.datetime.now()
    
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if top_type == 'money':
            # ИСПРАВЛЕННЫЕ SQL-запросы для топа по деньгам
            if period == 'week':
                start_date = now - datetime.timedelta(days=7)
                cursor.execute('''
                    SELECT 
                        COALESCE(u.full_name, u.username, 'Пользователь') as name,
                        COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0) as total_earnings
                    FROM users u
                    LEFT JOIN submissions s ON u.user_id = s.user_id AND s.status = 'approved'
                        AND s.approved_at >= %s
                    LEFT JOIN tasks t ON s.task_id = t.id
                    GROUP BY u.user_id, u.full_name, u.username
                    HAVING COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0) > 0
                    ORDER BY total_earnings DESC
                    LIMIT 10
                ''', (start_date,))
            elif period == 'month':
                start_date = now - datetime.timedelta(days=30)
                cursor.execute('''
                    SELECT 
                        COALESCE(u.full_name, u.username, 'Пользователь') as name,
                        COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0) as total_earnings
                    FROM users u
                    LEFT JOIN submissions s ON u.user_id = s.user_id AND s.status = 'approved'
                        AND s.approved_at >= %s
                    LEFT JOIN tasks t ON s.task_id = t.id
                    GROUP BY u.user_id, u.full_name, u.username
                    HAVING COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0) > 0
                    ORDER BY total_earnings DESC
                    LIMIT 10
                ''', (start_date,))
            else:  # all time
                cursor.execute('''
                    SELECT 
                        COALESCE(u.full_name, u.username, 'Пользователь') as name,
                        COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0) as total_earnings
                    FROM users u
                    LEFT JOIN submissions s ON u.user_id = s.user_id AND s.status = 'approved'
                    LEFT JOIN tasks t ON s.task_id = t.id
                    GROUP BY u.user_id, u.full_name, u.username
                    HAVING COALESCE(SUM(COALESCE(t.reward_money, t.price, 0)), 0) > 0
                    ORDER BY total_earnings DESC
                    LIMIT 10
                ''')
            
            top_users = cursor.fetchall()
            label = '₽'
            
        else:  # top_points
            # ИСПРАВЛЕННЫЕ SQL-запросы для топа по баллам
            if period == 'week':
                start_date = now - datetime.timedelta(days=7)
                cursor.execute('''
                    SELECT 
                        COALESCE(u.full_name, u.username, 'Пользователь') as name,
                        COALESCE(SUM(t.reward_points), 0) as total_points
                    FROM users u
                    LEFT JOIN submissions s ON u.user_id = s.user_id AND s.status = 'approved'
                        AND s.approved_at >= %s
                    LEFT JOIN tasks t ON s.task_id = t.id
                    GROUP BY u.user_id, u.full_name, u.username
                    HAVING COALESCE(SUM(t.reward_points), 0) > 0
                    ORDER BY total_points DESC
                    LIMIT 10
                ''', (start_date,))
            elif period == 'month':
                start_date = now - datetime.timedelta(days=30)
                cursor.execute('''
                    SELECT 
                        COALESCE(u.full_name, u.username, 'Пользователь') as name,
                        COALESCE(SUM(t.reward_points), 0) as total_points
                    FROM users u
                    LEFT JOIN submissions s ON u.user_id = s.user_id AND s.status = 'approved'
                        AND s.approved_at >= %s
                    LEFT JOIN tasks t ON s.task_id = t.id
                    GROUP BY u.user_id, u.full_name, u.username
                    HAVING COALESCE(SUM(t.reward_points), 0) > 0
                    ORDER BY total_points DESC
                    LIMIT 10
                ''', (start_date,))
            else:  # all time
                cursor.execute('''
                    SELECT 
                        COALESCE(u.full_name, u.username, 'Пользователь') as name,
                        COALESCE(SUM(t.reward_points), 0) as total_points
                    FROM users u
                    LEFT JOIN submissions s ON u.user_id = s.user_id AND s.status = 'approved'
                    LEFT JOIN tasks t ON s.task_id = t.id
                    GROUP BY u.user_id, u.full_name, u.username
                    HAVING COALESCE(SUM(t.reward_points), 0) > 0
                    ORDER BY total_points DESC
                    LIMIT 10
                ''')
            
            top_users = cursor.fetchall()
            label = 'баллов'
            
    except Exception as e:
        logging.error(f"Ошибка top_period_selected: {e}")
        await callback_query.message.edit_text("❌ Произошла ошибка при загрузке топа.")
        return
    finally:
        if conn: 
            conn.close()

    if not top_users:
        await callback_query.message.edit_text("🏆 Пока что топ пуст. Стань первым!", parse_mode="HTML", reply_markup=top_keyboard())
        await callback_query.answer()
        return

    period_labels = {'week': 'за неделю', 'month': 'за месяц', 'all': 'за всё время'}
    period_label = period_labels[period]
    
    top_text = f"🏆 <b>Топ-10 пользователей по {'деньгам' if top_type == 'money' else 'баллам'} ({period_label}):</b>\n\n"
    medals = ["🥇", "🥈", "🥉"]
    
    for i, user in enumerate(top_users):
        name, total = user
        place = f"{medals[i]}" if i < 3 else f"<b>{i+1}.</b>"
        if top_type == 'money':
            top_text += f"{place} {name} — <b>{float(total):.2f} {label}</b>\n"
        else:
            top_text += f"{place} {name} — <b>{int(total)} {label}</b>\n"
            
    await callback_query.message.edit_text(top_text, parse_mode="HTML", reply_markup=top_keyboard())
    await callback_query.answer()

@dp.callback_query_handler(lambda c: c.data == 'back_to_profile')
async def back_to_profile_from_stats(callback_query: types.CallbackQuery):
    await callback_query.answer()
    user_id = callback_query.from_user.id
    
    profile_data = await asyncio.get_event_loop().run_in_executor(None, get_profile_data, user_id)
    if not profile_data:
        await callback_query.message.edit_text("❌ Произошла ошибка при загрузке профиля.")
        return

    profile_text = (
        "👤 <b>Мой Профиль:</b>\n\n"
        "💸 <b>Реальные деньги (₽):</b>\n"
        f"  💰 Баланс: <b>{profile_data['balance']} ₽</b>\n"
        f"  💵 Заработано за неделю: <b>{profile_data['weekly_earnings']:.2f} ₽</b>\n"
        f"  💵 Всего заработано: <b>{profile_data['total_earnings_calc']:.2f} ₽</b>\n"
        f"  📝 На заданиях: <b>{profile_data['earnings_from_tasks_calc']:.2f} ₽</b>\n"
        f"  🎁 С рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>\n\n"
        "🏅 <b>Игровые баллы:</b>\n"
        f"  🏅 Баллы: <b>{profile_data['points']}</b>\n"
        f"  ✨ Баллы за неделю: <b>{profile_data['weekly_points_calc']}</b>\n"
        f"  📊 Всего баллов: <b>{profile_data['total_points_calc']}</b>\n\n"
        "📈 <b>Статистика:</b>\n"
        f"  🧑‍💻 Заданий на проверке: <b>{profile_data['on_check']}</b>\n"
        f"  ✅ Выполнено заданий: <b>{profile_data['completed_tasks']}</b>\n\n"
        "🤝 <b>Реферальная программа:</b>\n"
        f"  👥 Приглашено друзей: <b>{profile_data['total_referrals']}</b>\n"
        f"  🥇 Рефералы 1 уровня: <b>{profile_data['ref_1_level']}</b>\n"
        f"  🥈 Рефералы 2 уровня: <b>{profile_data['ref_2_level']}</b>\n"
        f"  🎁 Доход от рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>\n"
    )
    
    await callback_query.message.edit_text(profile_text, parse_mode="HTML", reply_markup=profile_keyboard())

@dp.callback_query_handler(lambda c: c.data == 'back_to_profile_from_top')
async def back_to_profile_from_top(callback_query: types.CallbackQuery):
    await callback_query.answer()
    user_id = callback_query.from_user.id
    
    profile_data = await asyncio.get_event_loop().run_in_executor(None, get_profile_data, user_id)
    if not profile_data:
        await callback_query.message.edit_text("❌ Произошла ошибка при загрузке профиля.")
        return

    profile_text = (
        "👤 <b>Мой Профиль:</b>\n\n"
        "💸 <b>Реальные деньги (₽):</b>\n"
        f"  💰 Баланс: <b>{profile_data['balance']} ₽</b>\n"
        f"  💵 Заработано за неделю: <b>{profile_data['weekly_earnings']:.2f} ₽</b>\n"
        f"  💵 Всего заработано: <b>{profile_data['total_earnings_calc']:.2f} ₽</b>\n"
        f"  📝 На заданиях: <b>{profile_data['earnings_from_tasks_calc']:.2f} ₽</b>\n"
        f"  🎁 С рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>\n\n"
        "🏅 <b>Игровые баллы:</b>\n"
        f"  🏅 Баллы: <b>{profile_data['points']}</b>\n"
        f"  ✨ Баллы за неделю: <b>{profile_data['weekly_points_calc']}</b>\n"
        f"  📊 Всего баллов: <b>{profile_data['total_points_calc']}</b>\n\n"
        "📈 <b>Статистика:</b>\n"
        f"  🧑‍💻 Заданий на проверке: <b>{profile_data['on_check']}</b>\n"
        f"  ✅ Выполнено заданий: <b>{profile_data['completed_tasks']}</b>\n\n"
        "🤝 <b>Реферальная программа:</b>\n"
        f"  👥 Приглашено друзей: <b>{profile_data['total_referrals']}</b>\n"
        f"  🥇 Рефералы 1 уровня: <b>{profile_data['ref_1_level']}</b>\n"
        f"  🥈 Рефералы 2 уровня: <b>{profile_data['ref_2_level']}</b>\n"
        f"  🎁 Доход от рефералов: <b>{profile_data['earnings_from_referrals_calc']:.2f} ₽</b>\n"
    )
    
    await callback_query.message.edit_text(profile_text, parse_mode="HTML", reply_markup=profile_keyboard())

@dp.message_handler(commands=['history'])
async def show_history(message: types.Message):
    user_id = message.from_user.id
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT amount, operation_type, created_at
            FROM balance_transactions
            WHERE user_id = %s
            ORDER BY created_at DESC
            LIMIT 10
        """, (user_id,))
        history = cursor.fetchall()
    except Exception as e:
        logging.error(f"Ошибка show_history: {e}")
        await message.answer("❌ Произошла ошибка при загрузке истории.")
        return
    finally:
        if conn: 
            conn.close()

    text = "📊 <b>Последние 10 операций:</b>\n\n"
    if history:
        for amount, op_type, timestamp in history:
            dt_object = datetime.datetime.fromtimestamp(timestamp)
            text += f"{'➖' if amount < 0 else '➕'} {abs(amount)}₽ ({op_type}) - {dt_object.strftime('%d.%m.%Y %H:%M')}\n"
    else:
        text += "История операций пуста.\n"

    text += f"\n💰 <b>Текущий баланс:</b> {get_user_balance(user_id)}₽"
    await message.answer(text, parse_mode="HTML")
