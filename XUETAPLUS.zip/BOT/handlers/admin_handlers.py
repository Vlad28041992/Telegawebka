# handlers/admin_handlers.py
import logging
import asyncio
from aiogram import types
from aiogram.dispatcher.filters import Command
from config.settings import dp, bot, ADMINS
from database.db_operations import is_admin, approve_submission, reject_submission, log_balance_transaction, get_db_connection
from database.connection import get_connection
from utils.notifications import notify_user_submission_status, notify_user_achievement

@dp.message_handler(commands=["approve"])
async def approve_submission_handler(message: types.Message):
    """Одобрение заявки на задание по команде /approve ID"""
    user_id = message.from_user.id
    if not is_admin(user_id):
        await message.reply("⛔️ Доступ запрещен!")
        return
    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.reply("Формат: /approve <ID_ЗАЯВКИ>")
        return
    submission_id = int(args[0])
    conn = None
    try:
        success, target_user_id, unlocked_achievements = approve_submission(submission_id, admin_id=message.from_user.id)
        if success:
            await message.reply(f"✅ Заявка {submission_id} одобрена. Пользователь будет уведомлен!")
            await notify_user_submission_status(target_user_id, approved=True)
            for achievement in unlocked_achievements:
                await notify_user_achievement(target_user_id, achievement)
        else:
            await message.reply(f"❌ Ошибка при одобрении заявки {submission_id}.")
    except Exception as e:
        logging.error(f"Ошибка approve_submission_handler: {e}")
        await message.reply("❌ Произошла ошибка при обработке команды.")

@dp.message_handler(commands=["reject"])
async def reject_submission_handler(message: types.Message):
    """Отклонение заявки на задание по команде /reject ID"""
    user_id = message.from_user.id
    if not is_admin(user_id):
        await message.reply("⛔️ Доступ запрещен!")
        return
    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.reply("Формат: /reject <ID_ЗАЯВКИ>")
        return
    submission_id = int(args[0])
    try:
        success, target_user_id = reject_submission(submission_id, admin_id=message.from_user.id)
        if success:
            await message.reply(f"❌ Заявка {submission_id} отклонена. Пользователь уведомлен.")
            await notify_user_submission_status(target_user_id, approved=False)
        else:
            await message.reply(f"❌ Ошибка при отклонении заявки {submission_id}.")
    except Exception as e:
        logging.error(f"Ошибка reject_submission_handler: {e}")
        await message.reply("❌ Произошла ошибка при обработке команды.")

@dp.callback_query_handler(lambda c: c.data.startswith('approve_sub:'))
async def approve_submission_callback(callback_query: types.CallbackQuery):
    """Обработка одобрения заявки через inline кнопку"""
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer("⛔️ Доступ запрещен!", show_alert=True)
        return
        
    submission_id = int(callback_query.data.split(':')[1])
    try:
        success, target_user_id, unlocked_achievements = approve_submission(submission_id, admin_id=callback_query.from_user.id)
        if success:
            await callback_query.message.edit_text(f"✅ Заявка {submission_id} одобрена админом {callback_query.from_user.first_name}")
            await notify_user_submission_status(target_user_id, approved=True)
            for achievement in unlocked_achievements:
                await notify_user_achievement(target_user_id, achievement)
            await callback_query.answer("✅ Заявка одобрена!")
        else:
            await callback_query.answer("❌ Ошибка при одобрении", show_alert=True)
    except Exception as e:
        logging.error(f"Ошибка approve_submission_callback: {e}")
        await callback_query.answer("❌ Произошла ошибка", show_alert=True)

@dp.callback_query_handler(lambda c: c.data.startswith('reject_sub:'))  
async def reject_submission_callback(callback_query: types.CallbackQuery):
    """Обработка отклонения заявки через inline кнопку"""
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer("⛔️ Доступ запрещен!", show_alert=True)
        return
        
    submission_id = int(callback_query.data.split(':')[1])
    try:
        success, target_user_id = reject_submission(submission_id, admin_id=callback_query.from_user.id)
        if success:
            await callback_query.message.edit_text(f"❌ Заявка {submission_id} отклонена админом {callback_query.from_user.first_name}")
            await notify_user_submission_status(target_user_id, approved=False)
            await callback_query.answer("❌ Заявка отклонена!")
        else:
            await callback_query.answer("❌ Ошибка при отклонении", show_alert=True)
    except Exception as e:
        logging.error(f"Ошибка reject_submission_callback: {e}")
        await callback_query.answer("❌ Произошла ошибка", show_alert=True)

# ============= КОМАНДЫ ДЛЯ УПРАВЛЕНИЯ ВЫПЛАТАМИ =============

@dp.message_handler(commands=['withdraw_list'])
async def withdraw_list_admin(message: types.Message):
    """Список всех заявок на вывод"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT w.id, w.user_id, w.amount, w.method, w.status, w.request_time, u.full_name
            FROM withdraw_requests w
            LEFT JOIN users u ON w.user_id = u.user_id
            ORDER BY w.request_time DESC
            LIMIT 20
        """)
        requests = cursor.fetchall()
        
        if not requests:
            await message.answer("📋 Заявок на вывод не найдено.")
            return
            
        text = "📋 <b>Последние 20 заявок на вывод:</b>\n\n"
        
        for req_id, user_id, amount, method, status, req_time, full_name in requests:
            status_emoji = {"pending": "⏳", "approved": "✅", "rejected": "❌", "paid": "💸"}.get(status, "❓")
            name = full_name or f"ID{user_id}"
            text += f"{status_emoji} <b>#{req_id}</b> | {name} | {amount}₽ | {method} | {status}\n"
            
        text += "\n<i>Используйте /withdraw_info ID для подробностей</i>"
        await message.answer(text, parse_mode="HTML")
        
    except Exception as e:
        logging.error(f"Ошибка withdraw_list_admin: {e}")
        await message.answer("❌ Ошибка получения списка заявок.")
    finally:
        if conn: conn.close()

@dp.message_handler(commands=['reject_withdraw'])
async def reject_withdraw_admin(message: types.Message):
    """Отклонение заявки на вывод с возвратом средств"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer("Неверный формат. Используй: `/reject_withdraw <ID_заявки>`", parse_mode="Markdown")
        return
    
    withdraw_id = int(args[0])
    conn = None
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Начинаем транзакцию
        cursor.execute("BEGIN")
        
        # Получаем данные заявки
        cursor.execute("""
            SELECT user_id, amount FROM withdraw_requests
            WHERE id = %s AND status = 'pending'
        """, (withdraw_id,))
        withdraw_data = cursor.fetchone()
        
        if not withdraw_data:
            await message.answer(f"❌ Заявка #{withdraw_id} не найдена или уже была обработана.")
            conn.rollback()
            return
        
        user_id, amount = withdraw_data
        
        logging.info(f"Admin ({message.from_user.id}) rejected withdraw {withdraw_id}. Returning {amount} to user {user_id}.")
        
        # Обновляем статус заявки
        cursor.execute("""
            UPDATE withdraw_requests SET status = 'rejected', processed_at = NOW(), processor_id = %s
            WHERE id = %s
        """, (message.from_user.id, withdraw_id))
        
        # Возвращаем средства на баланс пользователя
        cursor.execute("UPDATE users SET balance = balance + %s WHERE user_id = %s", (amount, user_id))
        log_balance_transaction(user_id, amount, 'withdraw_reject', withdraw_id)
        
        conn.commit()
        
        # Уведомляем пользователя
        try:
            await bot.send_message(
                user_id,
                f"❌ Ваша заявка на вывод #{withdraw_id} на сумму {amount}₽ была отклонена.\n"
                f"💰 Средства возвращены на ваш баланс.\n"
                f"Вы можете создать новую заявку на вывод."
            )
        except Exception as e:
            logging.error(f"Не удалось уведомить пользователя {user_id}: {e}")
        
        await message.answer(f"✅ Заявка #{withdraw_id} успешно отклонена. {amount}₽ возвращены пользователю {user_id}.")
        
    except Exception as e:
        logging.error(f"Ошибка базы данных при отклонении вывода #{withdraw_id}: {e}", exc_info=True)
        if conn: conn.rollback()
        await message.answer(f"❌ Ошибка при отклонении заявки #{withdraw_id}.")
    finally:
        if conn: conn.close()

@dp.message_handler(commands=['approve_withdraw'])
async def approve_withdraw_admin(message: types.Message):
    """Одобрение заявки на вывод"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return

    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer("Формат: /approve_withdraw <ID_заявки>")
        return

    withdraw_id = int(args[0])
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, amount FROM withdraw_requests WHERE id = %s AND status = 'pending'", (withdraw_id,))
        withdraw_data = cursor.fetchone()

        if not withdraw_data:
            await message.answer(f"❌ Заявка на вывод #{withdraw_id} не найдена или уже обработана.")
            return

        user_id, amount = withdraw_data

        cursor.execute("""
            UPDATE withdraw_requests 
            SET status = 'approved', processed_at = NOW(), processor_id = %s 
            WHERE id = %s
        """, (message.from_user.id, withdraw_id))
        conn.commit()

        # Уведомляем пользователя
        try:
            await bot.send_message(
                user_id,
                f"✅ Ваш вывод #{withdraw_id} на сумму {amount}₽ одобрен и отправлен в обработку!"
            )
        except Exception as e:
            logging.error(f"Не удалось уведомить пользователя {user_id}: {e}")

        await message.answer(f"✅ Вывод #{withdraw_id} для пользователя {user_id} на {amount}₽ одобрен.")

    except Exception as e:
        logging.error(f"Ошибка approve_withdraw: {e}")
        await message.answer("❌ Произошла ошибка при одобрении заявки.")
    finally:
        if conn: conn.close()

@dp.message_handler(commands=['withdraw_info'])
async def withdraw_info(message: types.Message):
    """Подробная информация о заявке на вывод"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return

    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer("Формат: /withdraw_info <ID_заявки>")
        return

    withdraw_id = int(args[0])
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT w.id, w.user_id, w.amount, w.method, w.details, w.status, 
                   w.request_time, w.processed_at, w.processor_id,
                   u.full_name, u.username, u.balance
            FROM withdraw_requests w
            LEFT JOIN users u ON w.user_id = u.user_id
            WHERE w.id = %s
        """, (withdraw_id,))
        
        result = cursor.fetchone()
        if not result:
            await message.answer(f"ℹ️ Заявка с ID {withdraw_id} не найдена.")
            return

        (req_id, user_id, amount, method, details, status, request_time, 
         processed_at, processor_id, full_name, username, balance) = result

        status_emoji = {"pending": "⏳", "approved": "✅", "rejected": "❌", "paid": "💸"}.get(status, "❓")
        
        info_text = f"""
📋 <b>Информация о заявке #{req_id}</b>

👤 <b>Пользователь:</b>
• ID: {user_id}
• Имя: {full_name or 'Не указано'}
• Username: @{username or 'Отсутствует'}
• Текущий баланс: {balance}₽

💳 <b>Заявка:</b>
• Сумма: <b>{amount}₽</b>
• Способ: {method}  
• Реквизиты: <code>{details}</code>
• Статус: {status_emoji} {status}

🕐 <b>Время:</b>
• Создана: {request_time}
• Обработана: {processed_at or 'Не обработана'}
• Обработчик: {processor_id or 'Нет'}
        """

        # Добавляем кнопки управления если заявка на рассмотрении
        if status == 'pending':
            keyboard = types.InlineKeyboardMarkup(row_width=2)
            keyboard.add(
                types.InlineKeyboardButton("✅ Одобрить", callback_data=f"approve_withdraw:{req_id}"),
                types.InlineKeyboardButton("❌ Отклонить", callback_data=f"reject_withdraw:{req_id}")
            )
            await message.answer(info_text, parse_mode="HTML", reply_markup=keyboard)
        else:
            await message.answer(info_text, parse_mode="HTML")

    except Exception as e:
        logging.error(f"Ошибка withdraw_info: {e}")
        await message.answer("❌ Ошибка получения информации о заявке.")
    finally:
        if conn: conn.close()

@dp.message_handler(commands=['withdraw_stats'])
async def withdraw_stats_admin(message: types.Message):
    """Статистика по выплатам"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Общая статистика
        cursor.execute("""
            SELECT status, COUNT(*), SUM(amount) 
            FROM withdraw_requests 
            GROUP BY status
        """)
        stats = cursor.fetchall()
        
        # Статистика за последние 30 дней
        cursor.execute("""
            SELECT COUNT(*), SUM(amount)
            FROM withdraw_requests 
            WHERE request_time >= NOW() - INTERVAL '30 days'
        """)
        monthly = cursor.fetchone()
        
        text = "📊 <b>Статистика выплат:</b>\n\n"
        
        total_amount = 0
        total_count = 0
        
        for status, count, amount in stats:
            status_emoji = {"pending": "⏳", "approved": "✅", "rejected": "❌", "paid": "💸"}.get(status, "❓")
            amount = amount or 0
            total_amount += amount
            total_count += count
            text += f"{status_emoji} <b>{status}:</b> {count} заявок на {amount}₽\n"
        
        text += f"\n📈 <b>Всего:</b> {total_count} заявок на {total_amount}₽"
        text += f"\n🗓 <b>За 30 дней:</b> {monthly[0] or 0} заявок на {monthly[1] or 0}₽"
        
        await message.answer(text, parse_mode="HTML")
        
    except Exception as e:
        logging.error(f"Ошибка withdraw_stats_admin: {e}")
        await message.answer("❌ Ошибка получения статистики.")
    finally:
        if conn: conn.close()

@dp.message_handler(commands=['help_admin'])
async def help_admin(message: types.Message):
    """Справка по админским командам"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
        
    help_text = """
🔧 <b>АДМИНСКИЕ КОМАНДЫ</b>

<b>📝 Заявки на задания:</b>
• /approve ID - одобрить заявку
• /reject ID - отклонить заявку

<b>💳 Заявки на вывод:</b>
• /withdraw_list - список всех заявок  
• /withdraw_info ID - информация о заявке
• /approve_withdraw ID - одобрить заявку
• /reject_withdraw ID - отклонить и вернуть деньги
• /withdraw_stats - статистика выплат

<b>🔨 Управление банами:</b>
• /ban <user_id> <минуты|0> <причина> - забанить пользователя
• /unban <user_id> - разбанить пользователя
• /banlist - список всех активных банов
• /checkban <user_id> - проверить статус бана

<b>📢 Рассылка:</b>
• /broadcast <текст> - массовая рассылка

<b>ℹ️ Прочее:</b>
• /help_admin - эта справка

<i>💡 Совет: Используйте inline кнопки в уведомлениях для быстрой обработки заявок!</i>

<b>Примеры использования бана:</b>
• `/ban 123456789 0 Мошенничество` - перманентный бан
• `/ban 123456789 1440 Спам` - бан на 24 часа
• `/ban 123456789 60 Нарушение` - бан на 1 час
    """
    
    await message.answer(help_text, parse_mode="HTML")


@dp.message_handler(commands=['broadcast'])
async def broadcast_handler(message: types.Message):
    """Массовая рассылка: /broadcast <текст> или ответьте /broadcast на сообщение для копирования"""
    try:
        if not is_admin(message.from_user.id):
            await message.reply("⛔️ Доступ запрещен!")
            return
        is_copy = bool(message.reply_to_message)
        text = message.get_args().strip()
        if not is_copy and not text:
            await message.reply('Пришли текст: /broadcast Текст сообщения\nИли ответь /broadcast на сообщение, которое нужно разослать.')
            return
        conn = get_db_connection()
        if not conn:
            await message.reply('❌ Ошибка подключения к БД.')
            return
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users WHERE is_active = TRUE")
        user_ids = [row[0] for row in cur.fetchall()]
        cur.close(); conn.close()

        total = len(user_ids)
        sent = 0
        failed = 0
        status = await message.reply(f"🚀 Рассылка по {total} пользователям началась...")
        for uid in user_ids:
            try:
                if is_copy:
                    await bot.copy_message(uid, message.chat.id, message.reply_to_message.message_id)
                else:
                    await bot.send_message(uid, text)
                sent += 1
                await asyncio.sleep(0.05)
            except Exception as e:
                failed += 1
                if any(s in str(e) for s in ('Forbidden', 'chat not found', 'deactivated', 'bot was blocked')):
                    try:
                        conn2 = get_db_connection()
                        if conn2:
                            c = conn2.cursor()
                            c.execute("UPDATE users SET is_active = FALSE WHERE user_id = %s", (uid,))
                            conn2.commit(); c.close(); conn2.close()
                    except Exception:
                        pass
        try:
            await status.edit_text(f"✅ Готово. Доставлено: {sent}, ошибок: {failed} из {total}.")
        except Exception:
            pass
    except Exception:
        logging.exception('broadcast_handler error')
        try:
            await message.reply('❌ Ошибка при рассылке.')
        except Exception:
            pass


# ============= КОМАНДЫ ДЛЯ УПРАВЛЕНИЯ БАНАМИ =============

@dp.message_handler(commands=['ban'])
async def ban_user_command(message: types.Message):
    """
    Банит пользователя
    Формат: /ban <user_id> <duration_minutes|0> <причина>
    Если duration_minutes = 0, то бан перманентный
    """
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    args = message.get_args().split(maxsplit=2)
    if len(args) < 3:
        await message.answer(
            "❌ Неверный формат!\n\n"
            "Использование: `/ban <user_id> <минуты|0> <причина>`\n\n"
            "Примеры:\n"
            "• `/ban 123456789 0 Мошенничество` - перманентный бан\n"
            "• `/ban 123456789 1440 Спам` - бан на 24 часа\n"
            "• `/ban 123456789 60 Нарушение правил` - бан на 1 час",
            parse_mode='Markdown'
        )
        return
    
    try:
        user_id = int(args[0])
        duration = int(args[1])
        reason = args[2]
        
        duration_minutes = None if duration == 0 else duration
        
        from database.db_operations import ban_user_db
        
        success, msg = ban_user_db(
            user_id=user_id,
            reason=reason,
            duration_minutes=duration_minutes,
            banned_by=f"admin_{message.from_user.id}"
        )
        
        if success:
            # Формируем сообщение
            if duration_minutes:
                hours = duration_minutes // 60
                minutes = duration_minutes % 60
                duration_text = f"{hours}ч {minutes}мин" if hours > 0 else f"{minutes}мин"
                ban_type = f"на {duration_text}"
            else:
                ban_type = "перманентно"
            
            await message.answer(
                f"✅ Пользователь {user_id} забанен {ban_type}!\n"
                f"📋 Причина: {reason}\n\n"
                f"{msg}",
                parse_mode='HTML'
            )
            
            # Уведомляем пользователя
            try:
                ban_text = f"""
⛔️ <b>ВАШ АККАУНТ ЗАБЛОКИРОВАН!</b>

📋 <b>Причина:</b> {reason}
⏰ <b>Срок:</b> {ban_type}

❌ <b>Ваша реферальная ссылка заморожена.</b>
💬 Если вы считаете, что бан был выдан ошибочно, обратитесь в поддержку.
"""
                await bot.send_message(user_id, ban_text, parse_mode='HTML')
            except Exception as e:
                logging.error(f"Не удалось уведомить пользователя {user_id} о бане: {e}")
        else:
            await message.answer(f"❌ Ошибка при бане пользователя:\n{msg}")
            
    except ValueError:
        await message.answer("❌ User ID и длительность должны быть числами!")
    except Exception as e:
        logging.error(f"Ошибка ban_user_command: {e}")
        await message.answer("❌ Произошла ошибка при выполнении команды.")


@dp.message_handler(commands=['unban'])
async def unban_user_command(message: types.Message):
    """
    Разбанивает пользователя
    Формат: /unban <user_id>
    """
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer(
            "❌ Неверный формат!\n"
            "Использование: `/unban <user_id>`",
            parse_mode='Markdown'
        )
        return
    
    try:
        user_id = int(args[0])
        
        from database.db_operations import unban_user_db
        
        success, msg = unban_user_db(
            user_id=user_id,
            unbanned_by=f"admin_{message.from_user.id}"
        )
        
        if success:
            await message.answer(
                f"✅ Пользователь {user_id} разбанен!\n"
                f"{msg}"
            )
            
            # Уведомляем пользователя
            try:
                await bot.send_message(
                    user_id,
                    "✅ <b>Ваш аккаунт разблокирован!</b>\n\n"
                    "Вы снова можете пользоваться ботом и вашей реферальной ссылкой.",
                    parse_mode='HTML'
                )
            except Exception as e:
                logging.error(f"Не удалось уведомить пользователя {user_id} о разбане: {e}")
        else:
            await message.answer(f"❌ Ошибка при разбане пользователя:\n{msg}")
            
    except ValueError:
        await message.answer("❌ User ID должен быть числом!")
    except Exception as e:
        logging.error(f"Ошибка unban_user_command: {e}")
        await message.answer("❌ Произошла ошибка при выполнении команды.")


@dp.message_handler(commands=['banlist'])
async def banlist_command(message: types.Message):
    """Список всех активных банов"""
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    try:
        from database.db_operations import get_active_bans
        from datetime import datetime
        
        bans = get_active_bans()
        
        if not bans:
            await message.answer("ℹ️ Активных банов нет.")
            return
        
        text = f"📋 <b>Активные баны ({len(bans)}):</b>\n\n"
        
        for ban in bans[:20]:  # Первые 20
            user_id = ban['user_id']
            username = ban['username'] or 'Нет'
            full_name = ban['full_name'] or f"ID{user_id}"
            reason = ban['reason']
            banned_by = ban['banned_by']
            
            if ban['is_permanent']:
                duration = "⏰ Перманентно"
            else:
                banned_until = ban['banned_until']
                time_left = banned_until - datetime.utcnow()
                if time_left.total_seconds() > 0:
                    days = time_left.days
                    hours = time_left.seconds // 3600
                    duration = f"⏰ Осталось: {days}д {hours}ч" if days > 0 else f"⏰ Осталось: {hours}ч"
                else:
                    duration = "⏰ Истек"
            
            text += f"👤 <b>{full_name}</b> (@{username})\n"
            text += f"🆔 ID: <code>{user_id}</code>\n"
            text += f"📋 Причина: {reason}\n"
            text += f"{duration}\n"
            text += f"🔨 Забанил: {banned_by}\n"
            text += "━━━━━━━━━━━━━━━\n\n"
        
        if len(bans) > 20:
            text += f"<i>... и еще {len(bans) - 20} банов</i>"
        
        await message.answer(text, parse_mode='HTML')
        
    except Exception as e:
        logging.error(f"Ошибка banlist_command: {e}")
        await message.answer("❌ Ошибка при получении списка банов.")


@dp.message_handler(commands=['checkban'])
async def checkban_command(message: types.Message):
    """
    Проверяет статус бана пользователя
    Формат: /checkban <user_id>
    """
    if not is_admin(message.from_user.id):
        await message.answer("⛔️ Доступ запрещен!")
        return
    
    args = message.get_args().split()
    if len(args) != 1 or not args[0].isdigit():
        await message.answer(
            "❌ Неверный формат!\n"
            "Использование: `/checkban <user_id>`",
            parse_mode='Markdown'
        )
        return
    
    try:
        user_id = int(args[0])
        
        from database.db_operations import check_user_ban
        from datetime import datetime
        
        is_banned, ban_info = check_user_ban(user_id)
        
        if not is_banned:
            await message.answer(f"✅ Пользователь {user_id} не забанен.")
            return
        
        reason = ban_info['reason']
        banned_at = ban_info['banned_at'].strftime('%d.%m.%Y %H:%M')
        banned_by = ban_info['banned_by']
        
        text = f"""
📋 <b>Информация о бане пользователя {user_id}</b>

📝 <b>Причина:</b> {reason}
🕐 <b>Дата бана:</b> {banned_at}
🔨 <b>Забанил:</b> {banned_by}
"""
        
        if ban_info['is_permanent']:
            text += "\n⏰ <b>Срок:</b> Перманентно"
        else:
            banned_until = ban_info['banned_until'].strftime('%d.%m.%Y %H:%M')
            time_left = ban_info['banned_until'] - datetime.utcnow()
            
            if time_left.total_seconds() > 0:
                days = time_left.days
                hours = time_left.seconds // 3600
                minutes = (time_left.seconds % 3600) // 60
                
                duration_parts = []
                if days > 0:
                    duration_parts.append(f'{days} дн.')
                if hours > 0:
                    duration_parts.append(f'{hours} ч.')
                if minutes > 0:
                    duration_parts.append(f'{minutes} мин.')
                
                duration = ' '.join(duration_parts) if duration_parts else 'менее минуты'
            else:
                duration = 'Истек (будет деактивирован при следующей проверке)'
            
            text += f"\n⏰ <b>До:</b> {banned_until}"
            text += f"\n⏳ <b>Осталось:</b> {duration}"
        
        # Добавляем кнопку разбана
        keyboard = types.InlineKeyboardMarkup()
        keyboard.add(types.InlineKeyboardButton(
            "🔓 Разбанить",
            callback_data=f"unban_user:{user_id}"
        ))
        
        await message.answer(text, parse_mode='HTML', reply_markup=keyboard)
        
    except ValueError:
        await message.answer("❌ User ID должен быть числом!")
    except Exception as e:
        logging.error(f"Ошибка checkban_command: {e}")
        await message.answer("❌ Ошибка при проверке бана.")


@dp.callback_query_handler(lambda c: c.data.startswith('unban_user:'))
async def unban_user_callback(callback_query: types.CallbackQuery):
    """Обработка разбана через inline кнопку"""
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer("⛔️ Доступ запрещен!", show_alert=True)
        return
    
    try:
        user_id = int(callback_query.data.split(':')[1])
        
        from database.db_operations import unban_user_db
        
        success, msg = unban_user_db(
            user_id=user_id,
            unbanned_by=f"admin_{callback_query.from_user.id}"
        )
        
        if success:
            await callback_query.message.edit_text(
                f"✅ Пользователь {user_id} разбанен админом {callback_query.from_user.first_name}!",
                parse_mode='HTML'
            )
            
            # Уведомляем пользователя
            try:
                await bot.send_message(
                    user_id,
                    "✅ <b>Ваш аккаунт разблокирован!</b>\n\n"
                    "Вы снова можете пользоваться ботом и вашей реферальной ссылкой.",
                    parse_mode='HTML'
                )
            except Exception:
                pass
            
            await callback_query.answer("✅ Пользователь разбанен!")
        else:
            await callback_query.answer(f"❌ Ошибка: {msg}", show_alert=True)
            
    except Exception as e:
        logging.error(f"Ошибка unban_user_callback: {e}")
        await callback_query.answer("❌ Произошла ошибка", show_alert=True)
