# handlers/start_handlers.py - ВЕРСИЯ С ПРОВЕРКОЙ БАНА РЕФЕРЕРА
import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart, Command
from aiogram.utils.deep_linking import decode_payload
from config.settings import dp, ADMINS, CONTEST_ACTIVE, CONTEST_ID, DEFAULT_REFERRER_ID
from keyboards.main_keyboards import main_keyboard, back_to_menu_kb_reply
from database.db_operations import get_db_connection
from database.db_operations import get_user, add_user, release_task, is_user_banned, get_ban_info
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_referral_mode_keyboard():
    """Клавиатура для выбора реферального режима"""
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        InlineKeyboardButton(
            "💰 Реферальная система (20% + 5%)",
            callback_data="ref_mode_percentage"
        ),
        InlineKeyboardButton(
            "💵 20₽ за каждого реферала",
            callback_data="ref_mode_fixed"
        )
    )
    return keyboard

@dp.message_handler(CommandStart(), state="*")
async def cmd_start(message: types.Message, state: FSMContext):
    """Обработчик команды /start с проверкой бана"""
    await state.finish()
    user_id = message.from_user.id
    username = message.from_user.username
    full_name = message.from_user.full_name
    
    # ============= ПРОВЕРКА БАНА ПОЛЬЗОВАТЕЛЯ =============
    if is_user_banned(user_id):
        ban_info = get_ban_info(user_id)
        reason = ban_info.get('ban_reason', 'Не указана') if ban_info else 'Не указана'
        
        await message.answer(
            f"🚫 <b>Ваш аккаунт заблокирован!</b>\n\n"
            f"📝 Причина: {reason}\n\n"
            f"ℹ️ Вы не можете использовать бота. "
            f"Если считаете, что это ошибка, обратитесь в поддержку.",
            parse_mode="HTML"
        )
        return
    # ======================================================

    start_param = message.get_args()
    referrer_id = None
    
    if start_param:
        try:
            if start_param.isdigit():
                referrer_id = int(start_param)
            else:
                decoded = decode_payload(start_param)
                if decoded and str(decoded).isdigit():
                    referrer_id = int(decoded)
        except Exception:
            referrer_id = None
    
    # ============= ПРОВЕРКА БАНА РЕФЕРЕРА =============
    if referrer_id and is_user_banned(referrer_id):
        logging.warning(f"Попытка регистрации по реферальной ссылке забаненного пользователя {referrer_id}")
        referrer_id = None  # Игнорируем реферальную ссылку забаненного
    # ==================================================
    
    # Если нет реферального кода - назначаем DEFAULT_REFERRER_ID
    if not referrer_id:
        referrer_id = DEFAULT_REFERRER_ID
    
    # Проверяем, чтобы пользователь не стал рефералом самого себя
    if referrer_id == user_id:
        referrer_id = None

    user_info = get_user(user_id)
    is_new_user = False
    
    if not user_info:
        is_new_user = True
        add_user(user_id, username, full_name, referrer_id)

        # Уведомление реферера (только если он не забанен)
        if CONTEST_ACTIVE and referrer_id and not is_user_banned(referrer_id):
            try:
                await dp.bot.send_message(
                    referrer_id,
                    f"🎯 <b>Конкурс рефералов!</b>\n\n"
                    f"Твой реферал <b>{full_name}</b> зарегистрировался!\n"
                    f"Как только он выполнит задание - он будет засчитан в конкурсе.\n\n"
                    f"Следи за своим топом: /contest",
                    parse_mode='HTML'
                )
            except Exception as e:
                logging.error(f"[КОНКУРС] ❌ Не удалось уведомить реферера {referrer_id}: {e}")

        # ПРИВЕТСТВИЕ И ВЫБОР РЕФЕРАЛЬНОГО РЕЖИМА ДЛЯ НОВЫХ ПОЛЬЗОВАТЕЛЕЙ
        welcome_text = f"""🎉 <b>ДОБРО ПОЖАЛОВАТЬ В БУДУЩЕЕ ЗАРАБОТКА, {full_name}!</b> 🎉

🚀 <i>Ты только что получил доступ к самой крутой платформе для заработка!</i>

💸 <b>ТВОИ ВОЗМОЖНОСТИ:</b>
┣━━ 💰 Задания от 40₽ до 150₽ за штуку
┣━━ ⚡️ Мгновенные выплаты от 200₽
┣━━ 🔥 Реферальная программа с выбором!
┗━━ 🏆 Еженедельные бонусы и розыгрыши

🎯 <b>КАК ЭТО РАБОТАЕТ:</b>
• Выбираешь задание
• Выполняешь за 2-5 минут  
• Получаешь деньги на баланс
• Выводишь на карту/кошелек

━━━━━━━━━━━━━━━━━━━━━━━━━
🌟 <b>ПРИСОЕДИНЯЙСЯ К СООБЩЕСТВУ!</b> 🌟
━━━━━━━━━━━━━━━━━━━━━━━━━

🗞 <a href="https://t.me/SeoSermNews">Новостной канал</a> — узнавай первым!
💬 <a href="https://t.me/+rZHK4bnKGFk5MTVi">Общий чат</a> — общайся с коллегами!

━━━━━━━━━━━━━━━━━━━━━━━━━

<b>⚡️ ВАЖНО! Выбери свой тип реферальной системы:</b>

💰 <b>Реферальная система (20% + 5%)</b>
   → Получай 20% от заработка реферала 1-го уровня
   → Получай 5% от заработка реферала 2-го уровня
   → Чем больше зарабатывают твои рефералы - тем больше получаешь ты!

💵 <b>20₽ за каждого реферала</b>
   → Получай фиксированные 20₽ когда реферал выполнит задание
   → Деньги приходят сразу, независимо от модерации
   → Простая и понятная система

<i>⚠️ Ты можешь изменить выбор в любой момент в разделе "Пригласи Друзей"</i>"""

        await message.answer(
            welcome_text,
            parse_mode="HTML",
            reply_markup=get_referral_mode_keyboard()
        )

        if referrer_id and referrer_id == DEFAULT_REFERRER_ID:
            for admin_id in ADMINS:
                try:
                    await dp.bot.send_message(admin_id, f"🎯 Новый AUTO-РЕФЕРАЛ: {full_name} (ID: {user_id})")
                except Exception as e:
                    logging.error(f"Не удалось отправить сообщение админу {admin_id}: {e}")
        elif referrer_id:
            for admin_id in ADMINS:
                try:
                    await dp.bot.send_message(admin_id, f"🎯 Новый пользователь: {full_name} (ID: {user_id}), пришел от реферера с ID: {referrer_id}")
                except Exception as e:
                    logging.error(f"Не удалось отправить сообщение админу {admin_id}: {e}")
    else:
        # ПРИВЕТСТВИЕ ДЛЯ ВЕРНУВШИХСЯ ПОЛЬЗОВАТЕЛЕЙ
        welcome_back_text = f"""╔══════════════════════════════╗
║     🔥 О, да! {full_name[:12]}{'...' if len(full_name) > 12 else ''} снова в деле! 🔥     ║
╚══════════════════════════════╝

💪 <b>Готов продолжить зарабатывать?</b> 
⚡️ <b>Новые задания уже ждут тебя!</b>

━━━━━━━━━━━━━━━━━━━━━━━━━
🌟 <b>НЕ ПРОПУСКАЙ ВАЖНОЕ!</b> 🌟
━━━━━━━━━━━━━━━━━━━━━━━━━

🗞 <a href="https://t.me/SeoSermNews"><b>Новости</b></a> — акции, бонусы, новые задания!
💬 <a href="https://t.me/+rZHK4bnKGFk5MTVi"><b>Общий чат</b></a> — советы от опытных!

━━━━━━━━━━━━━━━━━━━━━━━━━

💰 <i>Время = Деньги. Поехали!</i> 🚀"""
        
        await message.answer(
            welcome_back_text,
            parse_mode="HTML",
            reply_markup=main_keyboard()
        )
