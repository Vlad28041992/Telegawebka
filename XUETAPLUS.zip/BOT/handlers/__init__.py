"""
Handlers package init. Avoid importing submodules here to prevent circular imports.
Submodules must be imported explicitly by the application (main.py/main_async.py).
"""

__all__ = [
    'start_handlers',
    'profile_handlers',
    'help_handlers',
    'referral_handlers',
    'admin_handlers',
    'other_handlers',
    'other_handlers_fixed',
    'task_handlers',
    'support_handlers',
    'command_handlers',
]
