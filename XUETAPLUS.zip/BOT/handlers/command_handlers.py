# handlers/command_handlers.py
# Bridge handlers for slash commands to existing menu handlers (aiogram 2.x)
import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from config.settings import dp

# Import real handlers to delegate logic
from .profile_handlers import personal_cabinet
from .help_handlers import help_command
from .referral_handlers import refer_friends
from keyboards.main_keyboards import main_keyboard

@dp.message_handler(commands=["menu"], state="*")
async def cmd_menu(message: types.Message, state: FSMContext):
    try:
        await state.finish()
    except Exception:
        pass
    await message.answer("🏠 Главное меню", reply_markup=main_keyboard(message.from_user.id))

@dp.message_handler(commands=["profile"], state="*")
async def cmd_profile(message: types.Message, state: FSMContext):
    # Delegate to existing handler
    await personal_cabinet(message, state)

@dp.message_handler(commands=["help"], state="*")
async def cmd_help(message: types.Message, state: FSMContext):
    # Delegate to existing handler
    await help_command(message, state)

@dp.message_handler(commands=["referrals", "referral", "referal", "invite"], state="*")
async def cmd_referrals(message: types.Message, state: FSMContext):
    # Delegate to existing handler
    await refer_friends(message, state)
