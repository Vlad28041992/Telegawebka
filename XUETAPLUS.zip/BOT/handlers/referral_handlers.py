from database.db_operations import get_db_connection
# handlers/referral_handlers.py - НОВАЯ ВЕРСИЯ С ВЫБОРОМ РЕЖИМА
import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from config.settings import dp, bot
from keyboards.main_keyboards import main_keyboard, back_to_menu_kb_reply
from keyboards.referral_keyboards import ref_keyboard, ref_cb
from database.connection import get_connection
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_referral_mode_switch_keyboard():
    """Клавиатура для переключения реферального режима"""
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        InlineKeyboardButton(
            "🔄 Изменить режим",
            callback_data="change_ref_mode"
        ),
        InlineKeyboardButton(
            "🔗 Получить реф. ссылку",
            callback_data="ref:get_link"
        ),
        InlineKeyboardButton(
            "📊 Статистика",
            callback_data="ref:stats"
        ),
        InlineKeyboardButton(
            "🏠 В главное меню",
            callback_data="ref:back_to_menu"
        )
    )
    return keyboard

def get_mode_selection_keyboard():
    """Клавиатура для выбора нового режима"""
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        InlineKeyboardButton(
            "💰 Реферальная система (20% + 5%)",
            callback_data="set_ref_mode_percentage"
        ),
        InlineKeyboardButton(
            "💵 20₽ за каждого реферала",
            callback_data="set_ref_mode_fixed"
        ),
        InlineKeyboardButton(
            "« Назад",
            callback_data="ref:back"
        )
    )
    return keyboard

@dp.message_handler(lambda m: m.text == "🤝 Пригласи Друзей", state="*")
async def refer_friends(message: types.Message, state: FSMContext):
    """Обработчик реферальной системы"""
    logging.info(f"Обработчик refer_friends вызван пользователем {message.from_user.id}")
    await state.finish()

    user_id = message.from_user.id
    
    try:
        # Получаем текущий режим пользователя
        connection = get_connection()
        if not connection:
            await message.answer("Ошибка подключения к базе данных.", reply_markup=back_to_menu_kb_reply())
            return
            
        cursor = connection.cursor()
        cursor.execute("SELECT referral_mode FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        current_mode = result[0] if result and result[0] else 'percentage'
        
        from aiogram.utils.deep_linking import get_start_link
        start_link = await get_start_link(user_id, encode=False)

        # *** Ключевое изменение: Сначала отправляем сообщение с удалением клавиатуры и сразу удаляем его. ***
        temp_msg = await message.answer("...", reply_markup=types.ReplyKeyboardRemove())
        await temp_msg.delete() # Удаляем временное сообщение

        if current_mode == 'percentage':
            mode_description = """<b>💰 Твой режим: Реферальная система (20% + 5%)</b>

Ты получаешь:
• 20% от заработка реферала 1-го уровня
• 5% от заработка реферала 2-го уровня

Чем больше зарабатывают твои рефералы - тем больше получаешь ты!"""
        else:
            mode_description = """<b>💵 Твой режим: 20₽ за каждого реферала</b>

Ты получаешь:
• 20₽ за каждого реферала, который выполнит задание
• Деньги приходят сразу, независимо от модерации"""

        text = (
            "🤝 <b>Приглашай друзей и зарабатывай!</b>\n\n"
            f"{mode_description}\n\n"
            f"🔗 <b>Твоя реферальная ссылка:</b>\n<code>{start_link}</code>\n\n"
            "Скопируй ссылку и отправь друзьям. Чем больше друзей - тем больше заработок! 💰\n\n"
            "<i>💡 Ты можешь изменить режим в любой момент</i>"
        )

        # Отправляем основной текст с клавиатурой
        await message.answer(text, parse_mode="HTML", reply_markup=get_referral_mode_switch_keyboard())
        # Отправляем ReplyKeyboard для возврата в главное меню
        await message.answer("Или вернитесь в главное меню:", reply_markup=back_to_menu_kb_reply())

    except Exception as e:
        logging.error(f"Ошибка в refer_friends: {e}")
        await message.answer("Произошла ошибка при создании реферальной ссылки. Попробуйте позже.",
                           reply_markup=back_to_menu_kb_reply())

@dp.callback_query_handler(lambda c: c.data == "change_ref_mode", state="*")
async def change_referral_mode(callback: types.CallbackQuery, state: FSMContext):
    """Обработчик для изменения реферального режима"""
    text = """<b>🔄 Изменение режима реферальной системы</b>

Выбери новый режим:

💰 <b>Реферальная система (20% + 5%)</b>
   → Получай 20% от заработка реферала 1-го уровня
   → Получай 5% от заработка реферала 2-го уровня
   → Чем больше зарабатывают твои рефералы - тем больше получаешь ты!

💵 <b>20₽ за каждого реферала</b>
   → Получай фиксированные 20₽ когда реферал выполнит задание
   → Деньги приходят сразу, независимо от модерации
   → Простая и понятная система

<i>⚠️ Смена режима применяется сразу и действует на всех будущих рефералов</i>"""
    
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_mode_selection_keyboard()
    )
    await callback.answer()

@dp.callback_query_handler(lambda c: c.data in ['set_ref_mode_percentage', 'set_ref_mode_fixed'], state="*")
async def set_referral_mode(callback: types.CallbackQuery, state: FSMContext):
    """Обработчик установки нового реферального режима"""
    user_id = callback.from_user.id
    mode = 'percentage' if callback.data == 'set_ref_mode_percentage' else 'fixed'
    
    try:
        # Обновляем режим в БД
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET referral_mode = %s WHERE user_id = %s",
                (mode, user_id)
            )
            conn.commit()
            cursor.close()
            conn.close()
            
            if mode == 'percentage':
                response_text = """✅ <b>Режим изменен на процентную систему!</b>

💰 Теперь ты будешь получать:
• 20% от заработка реферала 1-го уровня
• 5% от заработка реферала 2-го уровня"""
            else:
                response_text = """✅ <b>Режим изменен на фиксированную систему!</b>

💵 Теперь ты будешь получать:
• 20₽ за каждого реферала, который выполнит задание
• Деньги приходят сразу, независимо от модерации"""
            
            await callback.message.edit_text(
                response_text,
                parse_mode="HTML",
                reply_markup=get_referral_mode_switch_keyboard()
            )
            
            await callback.answer("✅ Режим успешно изменен!")
        else:
            await callback.answer("Ошибка подключения к БД", show_alert=True)
            
    except Exception as e:
        logging.error(f"Ошибка при установке referral_mode для {user_id}: {e}")
        await callback.answer("Произошла ошибка, попробуйте позже", show_alert=True)

@dp.callback_query_handler(lambda c: c.data == "ref:back", state="*")
async def back_to_referral_menu(callback: types.CallbackQuery, state: FSMContext):
    """Возврат к меню рефералов"""
    user_id = callback.from_user.id
    
    try:
        # Получаем текущий режим пользователя
        connection = get_connection()
        if not connection:
            await callback.answer("Ошибка подключения к БД", show_alert=True)
            return
            
        cursor = connection.cursor()
        cursor.execute("SELECT referral_mode FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        current_mode = result[0] if result and result[0] else 'percentage'
        
        from aiogram.utils.deep_linking import get_start_link
        start_link = await get_start_link(user_id, encode=False)

        if current_mode == 'percentage':
            mode_description = """<b>💰 Твой режим: Реферальная система (20% + 5%)</b>

Ты получаешь:
• 20% от заработка реферала 1-го уровня
• 5% от заработка реферала 2-го уровня"""
        else:
            mode_description = """<b>💵 Твой режим: 20₽ за каждого реферала</b>

Ты получаешь:
• 20₽ за каждого реферала, который выполнит задание"""

        text = (
            "🤝 <b>Приглашай друзей и зарабатывай!</b>\n\n"
            f"{mode_description}\n\n"
            f"🔗 <b>Твоя реферальная ссылка:</b>\n<code>{start_link}</code>\n\n"
            "Скопируй ссылку и отправь друзьям. Чем больше друзей - тем больше заработок! 💰\n\n"
            "<i>💡 Ты можешь изменить режим в любой момент</i>"
        )

        await callback.message.edit_text(
            text,
            parse_mode="HTML",
            reply_markup=get_referral_mode_switch_keyboard()
        )
        await callback.answer()

    except Exception as e:
        logging.error(f"Ошибка в back_to_referral_menu: {e}")
        await callback.answer("Произошла ошибка", show_alert=True)

@dp.callback_query_handler(ref_cb.filter(action="get_link"), state="*")
async def get_ref_link_callback(call: types.CallbackQuery, callback_data: dict, state: FSMContext):
    bot_info = await bot.get_me()
    referral_link = f"https://t.me/{bot_info.username}?start={call.from_user.id}"
    await call.message.answer(
        f"🔗 <b>Твоя реферальная ссылка:</b>\n<code>{referral_link}</code>\n\n"
        "Скопируй и поделись ею! 🚀",
        parse_mode="HTML",
        reply_markup=ref_keyboard()
    )
    await call.answer()

@dp.callback_query_handler(ref_cb.filter(action="stats"), state="*")
async def get_ref_stats_callback(call: types.CallbackQuery, callback_data: dict, state: FSMContext):
    user_id = call.from_user.id
    
    try:
        # Получаем данные о рефералах и заработке
        connection = get_db_connection()
        if not connection:
            await call.message.answer("Ошибка подключения к базе данных.", reply_markup=ref_keyboard())
            return
            
        cursor = connection.cursor()
        
        # Получаем статистику пользователя
        cursor.execute('''
            SELECT 
                COALESCE(referral_earnings_1, 0) as ref_earnings_1,
                COALESCE(referral_earnings_2, 0) as ref_earnings_2,
                COALESCE(referrals_level_1, 0) as refs_count_1,
                COALESCE(referrals_level_2, 0) as refs_count_2,
                COALESCE(referral_mode, 'percentage') as ref_mode
            FROM users 
            WHERE user_id = %s
        ''', (user_id,))
        
        user_stats = cursor.fetchone()
        if not user_stats:
            await call.message.answer("Пользователь не найден.", reply_markup=ref_keyboard())
            return
            
        ref_earnings_1, ref_earnings_2, refs_count_1, refs_count_2, ref_mode = user_stats
        
        # Получаем список активных рефералов 1 уровня
        cursor.execute('''
            SELECT username, full_name, total_earnings, created_at
            FROM users 
            WHERE referrer_id = %s 
            ORDER BY total_earnings DESC 
            LIMIT 10
        ''', (user_id,))
        
        level_1_refs = cursor.fetchall()
        
        # Подсчитываем общий заработок рефералов
        cursor.execute('''
            SELECT COALESCE(SUM(total_earnings), 0)
            FROM users 
            WHERE referrer_id = %s
        ''', (user_id,))
        
        total_ref_earnings = cursor.fetchone()[0] or 0
        
        cursor.close()
        connection.close()
        
        # Формируем сообщение в зависимости от режима
        if ref_mode == 'fixed':
            mode_text = "💵 <b>Режим: 20₽ за реферала</b>\n"
        else:
            mode_text = "💰 <b>Режим: Процентная система (20% + 5%)</b>\n"
        
        total_referral_income = float(ref_earnings_1) + float(ref_earnings_2)
        
        text = (
            "📊 <b>Статистика реферальной программы</b>\n\n"
            f"{mode_text}\n"
            f"👥 Приглашенных друзей: {refs_count_1}\n"
            f"👥 Друзей второго уровня: {refs_count_2}\n\n"
            f"💰 <b>Ваш доход с рефералов:</b>\n"
            f"• 1-й уровень: {ref_earnings_1}₽\n"
            f"• 2-й уровень: {ref_earnings_2}₽\n"
            f"• <b>Всего заработано: {total_referral_income:.0f}₽</b>\n\n"
            f"📈 Общий заработок ваших рефералов: {total_ref_earnings}₽\n\n"
        )
        
        if level_1_refs:
            text += "🏆 <b>Топ рефералов:</b>\n"
            for i, ref in enumerate(level_1_refs[:5], 1):
                username, full_name, earnings, _ = ref
                name = full_name or username or "Пользователь"
                text += f"{i}. {name[:20]} - {earnings}₽\n"
        else:
            text += "👥 У вас пока нет рефералов\n"
            
        text += "\n💡 <i>Приглашайте друзей и зарабатывайте!</i>"
        
        await call.message.answer(text, parse_mode="HTML", reply_markup=ref_keyboard())
        
    except Exception as e:
        logging.error(f"Ошибка в get_ref_stats_callback: {e}")
        await call.message.answer(
            "Произошла ошибка при получении статистики. Попробуйте позже.",
            reply_markup=ref_keyboard()
        )
    
    await call.answer()

@dp.callback_query_handler(ref_cb.filter(action="back_to_menu"), state="*")
async def back_to_menu_callback(call: types.CallbackQuery, callback_data: dict, state: FSMContext):
    await call.message.delete()
    await call.message.answer(
        "🏠 Главное меню:",
        reply_markup=main_keyboard()
    )
    await call.answer()
