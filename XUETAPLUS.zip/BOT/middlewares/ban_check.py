# middlewares/ban_check.py
import logging
from aiogram import types
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from database.db_operations import check_user_ban

logger = logging.getLogger(__name__)


class BanCheckMiddleware(BaseMiddleware):
    """Middleware для проверки бана пользователя В БОТЕ"""
    
    async def on_pre_process_message(self, message: types.Message, data: dict):
        user_id = message.from_user.id
        is_banned, ban_info = check_user_ban(user_id)
        if is_banned:
            await self.send_ban_notification(message, ban_info)
            raise CancelHandler()
    
    async def on_pre_process_callback_query(self, callback_query: types.CallbackQuery, data: dict):
        user_id = callback_query.from_user.id
        is_banned, ban_info = check_user_ban(user_id)
        if is_banned:
            await self.send_ban_notification_callback(callback_query, ban_info)
            raise CancelHandler()
    
    async def send_ban_notification(self, message: types.Message, ban_info: dict):
        try:
            ban_text = self.format_ban_message(ban_info)
            await message.reply(ban_text, parse_mode='HTML')
        except Exception as e:
            logger.error(f"Ошибка отправки уведомления о бане: {e}")
    
    async def send_ban_notification_callback(self, callback_query: types.CallbackQuery, ban_info: dict):
        try:
            ban_text = self.format_ban_message(ban_info)
            await callback_query.answer("⛔️ Ваш аккаунт заблокирован в боте!", show_alert=True)
            await callback_query.message.answer(ban_text, parse_mode='HTML')
        except Exception as e:
            logger.error(f"Ошибка отправки уведомления о бане (callback): {e}")
    
    def format_ban_message(self, ban_info: dict) -> str:
        if not ban_info:
            return "⛔️ <b>Ваш аккаунт заблокирован в боте!</b>\n\nОбратитесь в поддержку."
        
        reason = ban_info.get('reason', 'Не указана')
        banned_at = ban_info.get('banned_at')
        is_permanent = ban_info.get('is_permanent', True)
        banned_until = ban_info.get('banned_until')
        
        banned_at_str = banned_at.strftime('%d.%m.%Y %H:%M') if hasattr(banned_at, 'strftime') else 'Неизвестно'
        
        text = f"""⛔️ <b>ВАШ АККАУНТ ЗАБЛОКИРОВАН В БОТЕ!</b>

📋 <b>Причина:</b> {reason}
🕐 <b>Дата блокировки:</b> {banned_at_str}
"""
        
        if is_permanent:
            text += "\n⏰ <b>Срок:</b> Перманентно"
        else:
            if banned_until:
                from datetime import datetime
                banned_until_dt = banned_until if hasattr(banned_until, 'strftime') else datetime.fromisoformat(str(banned_until))
                banned_until_str = banned_until_dt.strftime('%d.%m.%Y %H:%M')
                
                time_left = banned_until_dt - datetime.utcnow()
                if time_left.total_seconds() > 0:
                    days = time_left.days
                    hours = time_left.seconds // 3600
                    minutes = (time_left.seconds % 3600) // 60
                    
                    parts = []
                    if days > 0:
                        parts.append(f'{days} дн.')
                    if hours > 0:
                        parts.append(f'{hours} ч.')
                    if minutes > 0:
                        parts.append(f'{minutes} мин.')
                    
                    duration = ' '.join(parts) if parts else 'менее минуты'
                else:
                    duration = 'Истек'
                
                text += f"\n⏰ <b>До:</b> {banned_until_str}"
                text += f"\n⏳ <b>Осталось:</b> {duration}"
        
        text += "\n\n❌ <b>Вы не можете использовать бота.</b>"
        text += "\n💬 Обратитесь в поддержку, если считаете это ошибкой."
        
        return text
