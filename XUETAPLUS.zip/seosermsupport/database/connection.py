"""
Подключение к базе данных
"""

import psycopg2
from psycopg2.extras import RealDictCursor
from config.settings import DATABASE_CONFIG
import logging

def get_connection():
    """Получить соединение с БД"""
    try:
        conn = psycopg2.connect(**DATABASE_CONFIG, cursor_factory=RealDictCursor)
        return conn
    except Exception as e:
        logging.error(f"Database connection error: {e}")
        return None
