"""
Операции с базой данных для бота поддержки
"""

import logging
from database.connection import get_connection

def test_db_connection():
    """Проверка подключения к базе данных"""
    try:
        conn = get_connection()
        if not conn:
            logging.error("❌ Не удалось получить подключение к БД")
            return False
        
        cur = conn.cursor()
        cur.execute("SELECT 1")
        result = cur.fetchone()
        cur.close()
        conn.close()
        
        if result:
            logging.info("✅ Подключение к базе данных успешно")
            return True
        else:
            logging.error("❌ Тестовый запрос вернул пустой результат")
            return False
            
    except Exception as e:
        logging.error(f"❌ Ошибка подключения к БД: {e}")
        return False

def init_support_tables():
    """Инициализация таблиц для системы поддержки"""
    conn = get_connection()
    if not conn:
        logging.error("Не удалось подключиться к БД")
        return False
    
    try:
        cur = conn.cursor()
        
        # Таблица тикетов
        cur.execute("""
            CREATE TABLE IF NOT EXISTS support_tickets (
                id SERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL,
                username TEXT,
                full_name TEXT,
                subject TEXT NOT NULL,
                status TEXT DEFAULT 'open',
                category TEXT DEFAULT 'general',
                created_at TIMESTAMP DEFAULT NOW(),
                updated_at TIMESTAMP DEFAULT NOW()
            )
        """)
        
        # Миграция: проверяем и добавляем колонку category если её нет
        cur.execute("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name='support_tickets' AND column_name='category'
        """)
        
        if not cur.fetchone():
            logging.info("⚙️ Добавляем колонку 'category' в таблицу support_tickets...")
            cur.execute("""
                ALTER TABLE support_tickets 
                ADD COLUMN category TEXT DEFAULT 'general'
            """)
            logging.info("✅ Колонка 'category' успешно добавлена")
        
        # Таблица сообщений в тикетах
        cur.execute("""
            CREATE TABLE IF NOT EXISTS support_messages (
                id SERIAL PRIMARY KEY,
                ticket_id INTEGER REFERENCES support_tickets(id) ON DELETE CASCADE,
                sender TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT NOW()
            )
        """)
        
        # Индексы для быстрого поиска
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_support_tickets_user_id 
            ON support_tickets(user_id)
        """)
        
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_support_messages_ticket_id 
            ON support_messages(ticket_id)
        """)
        
        conn.commit()
        cur.close()
        conn.close()
        logging.info("✅ Таблицы поддержки успешно созданы")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка при создании таблиц: {e}")
        if conn:
            conn.close()
        return False


def create_support_ticket(user_id, username, full_name, subject, message, category='general'):
    """Создать новый тикет поддержки"""
    conn = get_connection()
    if not conn:
        return None
    
    try:
        cur = conn.cursor()
        
        # ИСПРАВЛЕНО: Добавляем message в INSERT запрос
        cur.execute("""
            INSERT INTO support_tickets (user_id, username, full_name, subject, message, category)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (user_id, username, full_name, subject, message, category))
        
        ticket_id = cur.fetchone()['id']
        
        # Также добавляем первое сообщение в таблицу support_messages
        cur.execute("""
            INSERT INTO support_messages (ticket_id, sender, message)
            VALUES (%s, 'user', %s)
        """, (ticket_id, message))
        
        conn.commit()
        cur.close()
        conn.close()
        
        logging.info(f"✅ Создан тикет #{ticket_id} от пользователя {user_id}")
        return ticket_id
        
    except Exception as e:
        logging.error(f"Ошибка создания тикета: {e}")
        if conn:
            conn.close()
        return None


def get_user_tickets(user_id):
    """Получить все тикеты пользователя"""
    conn = get_connection()
    if not conn:
        return []
    
    try:
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM support_tickets 
            WHERE user_id = %s 
            ORDER BY created_at DESC
        """, (user_id,))
        
        tickets = cur.fetchall()
        cur.close()
        conn.close()
        
        return tickets
        
    except Exception as e:
        logging.error(f"Ошибка получения тикетов: {e}")
        if conn:
            conn.close()
        return []


def get_ticket_by_id(ticket_id):
    """Получить тикет по ID"""
    conn = get_connection()
    if not conn:
        return None
    
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM support_tickets WHERE id = %s", (ticket_id,))
        ticket = cur.fetchone()
        cur.close()
        conn.close()
        
        return ticket
        
    except Exception as e:
        logging.error(f"Ошибка получения тикета: {e}")
        if conn:
            conn.close()
        return None


def add_ticket_message(ticket_id, sender, message):
    """Добавить сообщение в тикет"""
    conn = get_connection()
    if not conn:
        return False
    
    try:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO support_messages (ticket_id, sender, message)
            VALUES (%s, %s, %s)
        """, (ticket_id, sender, message))
        
        # Обновляем время последнего обновления тикета
        cur.execute("""
            UPDATE support_tickets 
            SET updated_at = NOW() 
            WHERE id = %s
        """, (ticket_id,))
        
        conn.commit()
        cur.close()
        conn.close()
        
        return True
        
    except Exception as e:
        logging.error(f"Ошибка добавления сообщения: {e}")
        if conn:
            conn.close()
        return False



def add_support_message(ticket_id, sender, message):
    """Добавить сообщение в тикет (алиас для add_ticket_message)"""
    return add_ticket_message(ticket_id, sender, message)

def update_ticket_status(ticket_id, status):
    """Обновить статус тикета"""
    conn = get_connection()
    if not conn:
        return False
    
    try:
        cur = conn.cursor()
        cur.execute("""
            UPDATE support_tickets 
            SET status = %s, updated_at = NOW() 
            WHERE id = %s
        """, (status, ticket_id))
        
        conn.commit()
        cur.close()
        conn.close()
        
        logging.info(f"✅ Статус тикета #{ticket_id} изменен на '{status}'")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка обновления статуса тикета: {e}")
        if conn:
            conn.close()
        return False

def get_all_open_tickets():
    """Получить все открытые тикеты для админов"""
    conn = get_connection()
    if not conn:
        return []
    
    try:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, user_id, username, full_name, subject, status, category, created_at, updated_at
            FROM support_tickets 
            WHERE status != 'closed'
            ORDER BY updated_at DESC
        """)
        
        tickets = cur.fetchall()
        cur.close()
        conn.close()
        
        return tickets
        
    except Exception as e:
        logging.error(f"Ошибка получения открытых тикетов: {e}")
        if conn:
            conn.close()
        return []


def get_ticket_messages(ticket_id):
    """Получить все сообщения тикета"""
    conn = get_connection()
    if not conn:
        return []
    
    try:
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM support_messages 
            WHERE ticket_id = %s 
            ORDER BY created_at ASC
        """, (ticket_id,))
        
        messages = cur.fetchall()
        cur.close()
        conn.close()
        
        return messages
        
    except Exception as e:
        logging.error(f"Ошибка получения сообщений: {e}")
        if conn:
            conn.close()
        return []


def close_ticket(ticket_id):
    """Закрыть тикет"""
    conn = get_connection()
    if not conn:
        return False
    
    try:
        cur = conn.cursor()
        cur.execute("""
            UPDATE support_tickets 
            SET status = 'closed', updated_at = NOW() 
            WHERE id = %s
        """, (ticket_id,))
        
        conn.commit()
        cur.close()
        conn.close()
        
        logging.info(f"✅ Тикет #{ticket_id} закрыт")
        return True
        
    except Exception as e:
        logging.error(f"Ошибка закрытия тикета: {e}")
        if conn:
            conn.close()
        return False


def get_open_tickets():
    """Получить все открытые тикеты"""
    conn = get_connection()
    if not conn:
        return []
    
    try:
        cur = conn.cursor()
        cur.execute("""
            SELECT * FROM support_tickets 
            WHERE status != 'closed' 
            ORDER BY created_at DESC
        """)
        
        tickets = cur.fetchall()
        cur.close()
        conn.close()
        
        return tickets
        
    except Exception as e:
        logging.error(f"Ошибка получения открытых тикетов: {e}")
        if conn:
            conn.close()
        return []
