"""
Бот технической поддержки SeoSerm
"""

import logging
import asyncio
from aiogram import executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import BotCommand

# Инициализируем логирование СРАЗУ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logging.info("=" * 50)
logging.info("🚀 Запуск бота технической поддержки SeoSerm")
logging.info("=" * 50)

# Импортируем настройки
from config.settings import dp, bot
from database.db_operations import init_support_tables, test_db_connection

# ВАЖНО: Импортируем handlers ПОСЛЕ инициализации dp
# Это регистрирует все декораторы @dp.message_handler и @dp.callback_query_handler
import handlers.start_handler
import handlers.faq_handler
import handlers.ticket_handler
import handlers.admin_handler

logging.info("✅ Все хендлеры загружены")


async def set_bot_commands():
    """Устанавливаем команды бота для меню"""
    commands = [
        BotCommand(command="start", description="🏠 Главное меню"),
        BotCommand(command="admin", description="⚙️ Панель управления"),
        BotCommand(command="tickets", description="📋 Список открытых тикетов"),
        BotCommand(command="stats", description="📊 Статистика"),
    ]
    await bot.set_my_commands(commands)
    logging.info("✅ Команды бота установлены в меню")


async def on_startup(_):
    """Действия при запуске бота"""
    try:
        logging.info("=" * 50)
        logging.info("🔄 Тестирование подключения к базе данных...")
        logging.info("=" * 50)
        
        # Тестируем подключение
        if not test_db_connection():
            logging.error("❌ Не удалось подключиться к БД! Бот может работать некорректно.")
        
        logging.info("=" * 50)
        logging.info("🗄️ Инициализация таблиц базы данных...")
        logging.info("=" * 50)
        
        # Инициализируем таблицы БД
        init_support_tables()
        logging.info("✅ Таблицы поддержки успешно созданы")
        
        # Сбрасываем webhook для polling
        logging.info("=" * 50)
        logging.info("🔄 Сброс webhook...")
        logging.info("=" * 50)
        try:
            await bot.delete_webhook(drop_pending_updates=True)
            logging.info("✅ Webhook сброшен")
        except Exception as e:
            logging.warning(f"⚠️ Предупреждение при сбросе webhook: {e}")
        
        # Устанавливаем команды в меню
        logging.info("=" * 50)
        logging.info("🔄 Установка команд в меню...")
        logging.info("=" * 50)
        await set_bot_commands()
        
        # Получаем информацию о боте
        me = await bot.get_me()
        logging.info("=" * 50)
        logging.info(f"✅ Бот @{getattr(me, 'username', '')} запущен и готов к работе!")
        logging.info("=" * 50)
        
        # Отправляем уведомление админам
        from config.settings import ADMIN_IDS
        for admin_id in ADMIN_IDS:
            try:
                await bot.send_message(
                    admin_id,
                    "🟢 <b>Бот технической поддержки SeoSerm запущен!</b>\n\n"
                    "Команды для администраторов:\n"
                    "/admin - панель управления\n"
                    "/tickets - список открытых тикетов\n"
                    "/stats - статистика\n\n"
                    "💡 <i>Все команды доступны в меню (кнопка слева от поля ввода)</i>"
                )
                logging.info(f"✅ Уведомление отправлено админу {admin_id}")
            except Exception as e:
                logging.warning(f"⚠️ Не удалось отправить уведомление админу {admin_id}: {e}")
        
    except Exception as e:
        logging.error(f"❌ Ошибка при запуске: {e}")
        import traceback
        logging.error(traceback.format_exc())


async def on_shutdown(_):
    """Действия при остановке бота"""
    try:
        await bot.close()
        logging.info("✅ Бот остановлен")
    except Exception as e:
        logging.error(f"Ошибка при остановке: {e}")


if __name__ == '__main__':
    # Запуск бота
    executor.start_polling(
        dp,
        on_startup=on_startup,
        on_shutdown=on_shutdown,
        skip_updates=True
    )