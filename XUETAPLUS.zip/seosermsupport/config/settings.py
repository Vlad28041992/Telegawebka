"""
Настройки бота технической поддержки SeoSerm
"""

import os
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from urllib.parse import urlparse

# Токен бота
BOT_TOKEN = os.getenv('BOT_TOKEN', '8364481223:AAFZUnUM7VU4z5p-VR1P8-ahHoI-4Qxcgec')

# ID администраторов (получают уведомления о новых тикетах)
# Читаем из .env или используем значения по умолчанию
admin_ids_str = os.getenv('ADMIN_IDS', '858177728,108178729')
try:
    ADMIN_IDS = [int(admin_id.strip()) for admin_id in admin_ids_str.split(',') if admin_id.strip()]
except:
    ADMIN_IDS = [858177728, 108178729]

# Настройки базы данных
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://SeoSerm:Mama77660@amvera-angel2804-cnpg-seoserm-rw:5432/botinok')

# Парсим DATABASE_URL для создания DATABASE_CONFIG
try:
    parsed_url = urlparse(DATABASE_URL)
    DATABASE_CONFIG = {
        'dbname': parsed_url.path[1:],  # убираем первый слэш
        'user': parsed_url.username,
        'password': parsed_url.password,
        'host': parsed_url.hostname,
        'port': parsed_url.port or 5432
    }
except Exception as e:
    print(f"⚠️ Ошибка парсинга DATABASE_URL: {e}")
    # Fallback конфиг
    DATABASE_CONFIG = {
        'dbname': 'botinok',
        'user': 'SeoSerm',
        'password': 'Mama77660',
        'host': 'amvera-angel2804-cnpg-seoserm-rw',
        'port': 5432
    }

# Инициализация бота
bot = Bot(token=BOT_TOKEN, parse_mode='HTML')
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

# Webhook настройки для Amvera
WEBHOOK_HOST = os.getenv('WEBHOOK_HOST', 'https://seosermsupport-angel2804.amvera.io')
WEBHOOK_PATH = '/webhook'
WEBHOOK_URL = f"{WEBHOOK_HOST}{WEBHOOK_PATH}"

# Настройки сервера
WEBAPP_HOST = '0.0.0.0'
WEBAPP_PORT = int(os.getenv('PORT', 8080))
