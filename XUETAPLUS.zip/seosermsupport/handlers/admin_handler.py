"""
Обработчики для администраторов
"""

import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.utils import exceptions
from config.settings import dp, bot, ADMIN_IDS
from database.db_operations import (
    get_all_open_tickets,
    get_ticket_by_id,
    get_ticket_messages,
    add_support_message,
    update_ticket_status
)
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database.connection import get_connection
from states.support_states import SupportStates

STATUS_RU = {
    'open': '🟢 Открыт',
    'pending': '🟡 Ожидает ответа',
    'answered': '🟢 Получен ответ',
    'closed': '🔴 Закрыт'
}


def is_admin(user_id: int) -> bool:
    """Проверка, является ли пользователь админом"""
    return user_id in ADMIN_IDS


@dp.message_handler(commands=['admin'], state='*')
async def cmd_admin(message: types.Message, state: FSMContext):
    """Админ-панель"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа к этой команде")
        return
    
    await state.finish()
    
    tickets = get_all_open_tickets()
    
    text = f"""
🛠 <b>Админ-панель поддержки</b>

<b>Открытых тикетов:</b> {len(tickets)}

Команды:
/admin - эта панель
/tickets - список всех открытых тикетов
/stats - статистика поддержки
"""
    
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("📋 Открытые тикеты", callback_data="admin_tickets"),
        InlineKeyboardButton("📊 Статистика", callback_data="admin_stats")
    )
    
    await message.answer(text, reply_markup=kb)


@dp.message_handler(commands=['tickets'], state='*')
@dp.callback_query_handler(lambda c: c.data == 'admin_tickets', state='*')
async def show_admin_tickets(event, state: FSMContext):
    """Показать все открытые тикеты"""
    
    # Определяем тип события (сообщение или callback)
    if isinstance(event, types.CallbackQuery):
        user_id = event.from_user.id
        send_func = lambda text, markup: event.message.edit_text(text, reply_markup=markup)
        answer_func = event.answer
    else:
        user_id = event.from_user.id
        send_func = lambda text, markup: event.answer(text, reply_markup=markup)
        answer_func = lambda: None
    
    if not is_admin(user_id):
        if isinstance(event, types.CallbackQuery):
            await event.answer("❌ Нет доступа", show_alert=True)
        else:
            await event.answer("❌ У вас нет доступа к этой команде")
        return
    
    await state.finish()
    
    tickets = get_all_open_tickets()
    
    if not tickets:
        text = "📋 <b>Нет открытых тикетов</b>\n\nВсе обращения обработаны! 🎉"
        kb = InlineKeyboardMarkup()
        kb.add(InlineKeyboardButton("🔄 Обновить", callback_data="admin_tickets"))
        
        try:
            await send_func(text, kb)
        except:
            pass
        
        if isinstance(event, types.CallbackQuery):
            await answer_func()
        return
    
    # Формируем список тикетов
    kb = InlineKeyboardMarkup(row_width=1)
    
    for ticket in tickets[:20]:  # Показываем первые 20
        status = STATUS_RU.get(ticket['status'], ticket['status'])
        username = ticket.get('username', 'no_username')
        
        button_text = f"#{ticket['id']} | @{username} | {status}"
        kb.add(InlineKeyboardButton(button_text, callback_data=f"admin_view:{ticket['id']}"))
    
    kb.add(InlineKeyboardButton("🔄 Обновить", callback_data="admin_tickets"))
    
    text = f"<b>📋 Открытые тикеты ({len(tickets)}):</b>\n\nВыберите тикет для просмотра:"
    
    try:
        await send_func(text, kb)
    except:
        pass
    
    if isinstance(event, types.CallbackQuery):
        await answer_func()


@dp.callback_query_handler(lambda c: c.data.startswith('admin_view:'), state='*')
async def admin_view_ticket(callback: types.CallbackQuery, state: FSMContext):
    """Админ просмотр тикета"""
    
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    
    await state.finish()
    
    ticket_id = int(callback.data.split(':')[1])
    
    ticket = get_ticket_by_id(ticket_id)
    
    if not ticket:
        await callback.answer("❌ Тикет не найден", show_alert=True)
        return
    
    messages = get_ticket_messages(ticket_id)
    
    # Формируем текст
    status = STATUS_RU.get(ticket['status'], ticket['status'])
    username = ticket.get('username', 'no_username')
    full_name = ticket.get('full_name', 'Пользователь')
    
    text_parts = [
        f"<b>🛠 АДМИН: Тикет #{ticket_id}</b>",
        f"<b>Пользователь:</b> {full_name} (@{username})",
        f"<b>User ID:</b> <code>{ticket['user_id']}</code>",
        f"<b>Статус:</b> {status}",
        f"<b>Создано:</b> {ticket['created_at']}",
        "",
        "<b>История переписки:</b>",
        "━━━━━━━━━━━━━━━━━"
    ]
    
    for msg in messages:
        sender = "👤 Пользователь" if msg['sender'] == 'user' else "🛠 Support SeoSerm"
        time = str(msg['created_at']).split('.')[0]
        text_parts.append(f"\n{sender} | {time}")
        text_parts.append(msg['message'])
        text_parts.append("━━━━━━━━━━━━━━━━━")
    
    text = "\n".join(text_parts)
    
    # Кнопки действий
    kb = InlineKeyboardMarkup(row_width=2)
    
    if ticket['status'] != 'closed':
        kb.add(
            InlineKeyboardButton("💬 Ответить", callback_data=f"admin_reply:{ticket_id}"),
            InlineKeyboardButton("❌ Закрыть", callback_data=f"admin_close:{ticket_id}")
        )
    
    kb.add(InlineKeyboardButton("◀️ К списку", callback_data="admin_tickets"))
    
    try:
        await callback.message.edit_text(text, reply_markup=kb)
    except:
        await callback.message.answer(text, reply_markup=kb)
    
    await callback.answer()


@dp.callback_query_handler(lambda c: c.data.startswith('admin_reply:'), state='*')
async def admin_reply_start(callback: types.CallbackQuery, state: FSMContext):
    """Начало ответа админа"""
    
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    
    ticket_id = int(callback.data.split(':')[1])
    
    ticket = get_ticket_by_id(ticket_id)
    
    if not ticket:
        await callback.answer("❌ Тикет не найден", show_alert=True)
        return
    
    # ИСПРАВЛЕНО: Сохраняем ticket_id и флаг is_admin_reply
    await state.update_data(ticket_id=ticket_id, is_admin_reply=True)
    await SupportStates.waiting_reply.set()
    
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("❌ Отмена", callback_data="admin_tickets"))
    
    await callback.message.answer(
        f"✍️ <b>Ответ на тикет #{ticket_id}</b>\n\nНапишите ответ пользователю:",
        reply_markup=kb
    )
    await callback.answer()


# ИСПРАВЛЕНО: Этот хендлер для админов срабатывает ПЕРВЫМ
@dp.message_handler(lambda message: message.from_user.id in ADMIN_IDS, state=SupportStates.waiting_reply, content_types=['text'])
async def process_admin_reply(message: types.Message, state: FSMContext):
    """Обработка ответа админа"""
    
    data = await state.get_data()
    
    # Проверяем что это админский ответ
    if not data.get('is_admin_reply'):
        # Это не админский ответ, пропускаем
        return
    
    ticket_id = data.get('ticket_id')
    
    if not ticket_id:
        await message.answer("❌ Ошибка: тикет не найден")
        await state.finish()
        return
    
    admin_message = message.text.strip()
    
    if len(admin_message) < 5:
        await message.answer("❌ Сообщение слишком короткое.")
        return
    
    # Добавляем сообщение от админа
    success = add_support_message(ticket_id, 'admin', admin_message)
    
    if not success:
        await message.answer("❌ Не удалось отправить сообщение")
        await state.finish()
        return
    
    # Обновляем статус на "получен ответ"
    update_ticket_status(ticket_id, 'answered')
    
    ticket = get_ticket_by_id(ticket_id)
    
    await message.answer(f"✅ Ответ отправлен пользователю в тикет #{ticket_id}")
    
    # Отправляем уведомление пользователю
    try:
        user_text = f"""
🛠 <b>Получен ответ от поддержки!</b>

<b>Тикет #{ticket_id}</b>

<b>Ответ поддержки:</b>
{admin_message}

Вы можете продолжить диалог или закрыть обращение.
"""
        
        user_kb = InlineKeyboardMarkup(row_width=1)
        user_kb.add(
            InlineKeyboardButton("💬 Ответить", callback_data=f"reply_ticket:{ticket_id}"),
            InlineKeyboardButton("✅ Закрыть обращение", callback_data=f"close_ticket:{ticket_id}"),
            InlineKeyboardButton("📋 Мои обращения", callback_data="my_tickets")
        )
        
        await bot.send_message(ticket['user_id'], user_text, reply_markup=user_kb)
        
    except exceptions.BotBlocked:
        logging.warning(f"⚠️ Не удалось отправить уведомление: пользователь заблокировал бота")
        await message.answer("⚠️ Пользователь заблокировал бота, уведомление не отправлено")
    except exceptions.ChatNotFound:
        logging.warning(f"⚠️ Не удалось отправить уведомление: чат не найден")
        await message.answer("⚠️ Чат не найден, уведомление не отправлено")
    except exceptions.UserDeactivated:
        logging.warning(f"⚠️ Не удалось отправить уведомление: аккаунт деактивирован")
        await message.answer("⚠️ Аккаунт пользователя деактивирован")
    except Exception as e:
        logging.error(f"❌ Не удалось отправить уведомление: {e}")
        await message.answer(f"⚠️ Ошибка отправки уведомления: {e}")
    
    await state.finish()


@dp.callback_query_handler(lambda c: c.data.startswith('admin_close:'), state='*')
async def admin_close_ticket(callback: types.CallbackQuery, state: FSMContext):
    """Админ закрывает тикет"""
    
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    
    await state.finish()
    
    ticket_id = int(callback.data.split(':')[1])
    
    ticket = get_ticket_by_id(ticket_id)
    
    if not ticket:
        await callback.answer("❌ Тикет не найден", show_alert=True)
        return
    
    # Закрываем тикет
    update_ticket_status(ticket_id, 'closed')
    
    await callback.message.answer(f"✅ Тикет #{ticket_id} закрыт")
    
    # Уведомляем пользователя
    try:
        user_text = f"""
✅ <b>Ваше обращение #{ticket_id} закрыто</b>

Спасибо, что обратились в нашу поддержку!

Если у вас возникнут новые вопросы - создайте новое обращение.
"""
        await bot.send_message(ticket['user_id'], user_text)
        
    except exceptions.BotBlocked:
        logging.warning(f"⚠️ Не удалось отправить уведомление: пользователь заблокировал бота")
    except exceptions.ChatNotFound:
        logging.warning(f"⚠️ Не удалось отправить уведомление: чат не найден")
    except exceptions.UserDeactivated:
        logging.warning(f"⚠️ Не удалось отправить уведомление: аккаунт деактивирован")
    except Exception as e:
        logging.error(f"❌ Не удалось отправить уведомление: {e}")
    
    await callback.answer("Тикет закрыт")


@dp.callback_query_handler(lambda c: c.data == 'admin_stats', state='*')
async def show_admin_stats(callback: types.CallbackQuery, state: FSMContext):
    """Статистика поддержки"""
    
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    
    
    conn = get_connection()
    if not conn:
        await callback.answer("❌ Ошибка подключения к БД", show_alert=True)
        return
    
    try:
        cur = conn.cursor()
        
        # Общее количество тикетов
        cur.execute("SELECT COUNT(*) as total FROM support_tickets")
        total = cur.fetchone()['total']
        
        # Открытые тикеты
        cur.execute("SELECT COUNT(*) as open FROM support_tickets WHERE status != 'closed'")
        open_count = cur.fetchone()['open']
        
        # Закрытые тикеты
        cur.execute("SELECT COUNT(*) as closed FROM support_tickets WHERE status = 'closed'")
        closed = cur.fetchone()['closed']
        
        # Тикеты за последние 24 часа
        cur.execute("SELECT COUNT(*) as today FROM support_tickets WHERE created_at >= NOW() - INTERVAL '24 hours'")
        today = cur.fetchone()['today']
        
        cur.close()
        conn.close()
        
        text = f"""
📊 <b>Статистика поддержки</b>

<b>Всего обращений:</b> {total}
<b>Открытых:</b> {open_count}
<b>Закрытых:</b> {closed}
<b>За 24 часа:</b> {today}
"""
        
        kb = InlineKeyboardMarkup()
        kb.add(InlineKeyboardButton("◀️ Назад", callback_data="admin_tickets"))
        
        await callback.message.edit_text(text, reply_markup=kb)
        await callback.answer()
        
    except Exception as e:
        logging.error(f"Ошибка получения статистики: {e}")
        await callback.answer("❌ Ошибка получения статистики", show_alert=True)
        if conn:
            conn.close()
