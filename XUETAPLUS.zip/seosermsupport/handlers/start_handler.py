"""
Обработчик команды /start и главного меню
"""

import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from config.settings import dp
from keyboards.support_keyboards import get_main_menu_kb

@dp.message_handler(commands=['start'], state='*')
async def cmd_start(message: types.Message, state: FSMContext):
    """Приветствие и главное меню"""
    await state.finish()
    
    welcome_text = """
👋 <b>Добро пожаловать в техническую поддержку SeoSerm!</b>

Перед тем как написать нам, возможно ответ на ваш вопрос уже есть в разделе часто задаваемых вопросов.

Выберите интересующий вас раздел или напишите напрямую в поддержку:
"""
    
    await message.answer(
        welcome_text,
        reply_markup=get_main_menu_kb()
    )


@dp.callback_query_handler(lambda c: c.data == 'back_to_menu', state='*')
async def back_to_menu(callback: types.CallbackQuery, state: FSMContext):
    """Возврат в главное меню"""
    await state.finish()
    
    welcome_text = """
👋 <b>Техническая поддержка SeoSerm</b>

Выберите интересующий вас раздел:
"""
    
    try:
        await callback.message.edit_text(
            welcome_text,
            reply_markup=get_main_menu_kb()
        )
    except:
        await callback.message.answer(
            welcome_text,
            reply_markup=get_main_menu_kb()
        )
    
    await callback.answer()
