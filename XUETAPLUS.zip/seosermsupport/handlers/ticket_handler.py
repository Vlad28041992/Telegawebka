"""
Обработчики тикетов поддержки
"""

import logging
from aiogram import types
from aiogram.dispatcher import FSMContext
from config.settings import dp, bot, ADMIN_IDS
from states.support_states import SupportStates
from keyboards.support_keyboards import (
    get_back_to_menu_kb, 
    get_ticket_actions_kb,
    get_my_tickets_kb,
    get_cancel_kb
)
from database.db_operations import (
    create_support_ticket,
    get_user_tickets,
    get_ticket_by_id,
    get_ticket_messages,
    add_support_message,
    update_ticket_status
)

STATUS_RU = {
    'open': '🟢 Открыт',
    'pending': '🟡 Ожидает ответа',
    'answered': '🟢 Получен ответ',
    'closed': '🔴 Закрыт'
}


@dp.callback_query_handler(lambda c: c.data == 'create_ticket', state='*')
async def create_ticket_start(callback: types.CallbackQuery, state: FSMContext):
    """Начало создания тикета"""
    await state.finish()
    await SupportStates.waiting_message.set()
    
    text = """
✍️ <b>Создание обращения в техподдержку</b>

Опишите вашу проблему максимально подробно:
• Что именно произошло?
• Когда возникла проблема?
• ID задания (если проблема связана с заданием)
• Что вы уже пробовали сделать?

Чем подробнее вы опишете проблему, тем быстрее мы сможем вам помочь.

Напишите ваше обращение:
"""
    
    try:
        await callback.message.edit_text(text, reply_markup=get_cancel_kb())
    except:
        await callback.message.answer(text, reply_markup=get_cancel_kb())
    
    await callback.answer()


@dp.message_handler(state=SupportStates.waiting_message, content_types=['text'])
async def process_ticket_message(message: types.Message, state: FSMContext):
    """Обработка сообщения и создание тикета"""
    
    user_message = message.text.strip()
    
    if len(user_message) < 10:
        await message.answer(
            "❌ Сообщение слишком короткое. Пожалуйста, опишите проблему подробнее (минимум 10 символов).",
            reply_markup=get_cancel_kb()
        )
        return
    
    # Создаем тикет
    user = message.from_user
    username = user.username or "no_username"
    full_name = f"{user.first_name or ''} {user.last_name or ''}".strip() or "Пользователь"
    
    ticket_id = create_support_ticket(
        user_id=user.id,
        username=username,
        full_name=full_name,
        subject="Обращение в поддержку",
        message=user_message,
        category='general'
    )
    
    if not ticket_id:
        await message.answer(
            "❌ Произошла ошибка при создании обращения. Попробуйте позже.",
            reply_markup=get_back_to_menu_kb()
        )
        await state.finish()
        return
    
    # Уведомление пользователю
    await message.answer(
        f"""
✅ <b>Ваше обращение #{ticket_id} создано!</b>

Наши специалисты ответят вам в ближайшее время (обычно в течение 1-3 часов).

Вы получите уведомление, когда появится ответ.
""",
        reply_markup=get_my_tickets_kb()
    )
    
    # Уведомление администраторам
    admin_text = f"""
🆘 <b>Новое обращение в поддержку!</b>

<b>Тикет:</b> #{ticket_id}
<b>Пользователь:</b> {full_name} (@{username})
<b>User ID:</b> <code>{user.id}</code>

<b>Сообщение:</b>
{user_message}

<a href="https://adminpanelseoserm-angel2804.amvera.io/support/{ticket_id}">Открыть в админ-панели</a>
"""
    
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, admin_text)
        except Exception as e:
            logging.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    
    await state.finish()


@dp.callback_query_handler(lambda c: c.data == 'my_tickets', state='*')
async def show_my_tickets(callback: types.CallbackQuery, state: FSMContext):
    """Показать список тикетов пользователя"""
    await state.finish()
    
    tickets = get_user_tickets(callback.from_user.id)
    
    if not tickets:
        text = """
📋 <b>У вас пока нет обращений</b>

Если у вас возникли вопросы или проблемы - создайте обращение через кнопку "Написать в техподдержку".
"""
        try:
            await callback.message.edit_text(text, reply_markup=get_back_to_menu_kb())
        except:
            await callback.message.answer(text, reply_markup=get_back_to_menu_kb())
        await callback.answer()
        return
    
    # Формируем список тикетов
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    kb = InlineKeyboardMarkup(row_width=1)
    
    for ticket in tickets:
        status = STATUS_RU.get(ticket['status'], ticket['status'])
        subject = ticket.get('subject', 'Обращение')[:30]
        
        button_text = f"#{ticket['id']} {subject} | {status}"
        kb.add(InlineKeyboardButton(button_text, callback_data=f"view_ticket:{ticket['id']}"))
    
    kb.add(InlineKeyboardButton("◀️ Главное меню", callback_data="back_to_menu"))
    
    text = "<b>📋 Ваши обращения:</b>\n\nВыберите обращение для просмотра:"
    
    try:
        await callback.message.edit_text(text, reply_markup=kb)
    except:
        await callback.message.answer(text, reply_markup=kb)
    
    await callback.answer()


@dp.callback_query_handler(lambda c: c.data.startswith('view_ticket:'), state='*')
async def view_ticket(callback: types.CallbackQuery, state: FSMContext):
    """Просмотр конкретного тикета"""
    await state.finish()
    
    ticket_id = int(callback.data.split(':')[1])
    
    ticket = get_ticket_by_id(ticket_id)
    
    if not ticket or ticket['user_id'] != callback.from_user.id:
        await callback.answer("❌ Тикет не найден", show_alert=True)
        return
    
    messages = get_ticket_messages(ticket_id)
    
    # Формируем текст с историей сообщений
    status = STATUS_RU.get(ticket['status'], ticket['status'])
    
    text_parts = [
        f"<b>Обращение #{ticket_id}</b>",
        f"<b>Статус:</b> {status}",
        f"<b>Создано:</b> {ticket['created_at']}",
        "",
        "<b>История переписки:</b>",
        "━━━━━━━━━━━━━━━━━"
    ]
    
    for msg in messages:
        sender = "👤 <b>Вы</b>" if msg['sender'] == 'user' else "🛠 <b>Support SeoSerm</b>"
        time = str(msg['created_at']).split('.')[0]  # Убираем микросекунды
        text_parts.append(f"\n{sender} | {time}")
        text_parts.append(msg['message'])
        text_parts.append("━━━━━━━━━━━━━━━━━")
    
    text = "\n".join(text_parts)
    
    # Если тикет закрыт, нельзя отвечать
    can_reply = ticket['status'] != 'closed'
    
    try:
        await callback.message.edit_text(
            text,
            reply_markup=get_ticket_actions_kb(ticket_id, can_reply)
        )
    except:
        await callback.message.answer(
            text,
            reply_markup=get_ticket_actions_kb(ticket_id, can_reply)
        )
    
    await callback.answer()


@dp.callback_query_handler(lambda c: c.data.startswith('reply_ticket:'), state='*')
async def reply_ticket_start(callback: types.CallbackQuery, state: FSMContext):
    """Начало ответа на тикет"""
    
    ticket_id = int(callback.data.split(':')[1])
    
    ticket = get_ticket_by_id(ticket_id)
    
    if not ticket or ticket['user_id'] != callback.from_user.id:
        await callback.answer("❌ Тикет не найден", show_alert=True)
        return
    
    if ticket['status'] == 'closed':
        await callback.answer("❌ Этот тикет закрыт. Создайте новое обращение.", show_alert=True)
        return
    
    # ИСПРАВЛЕНО: НЕ устанавливаем is_admin_reply для обычных пользователей
    await state.update_data(ticket_id=ticket_id)
    await SupportStates.waiting_reply.set()
    
    await callback.message.answer(
        "✍️ Напишите ваше сообщение:",
        reply_markup=get_cancel_kb()
    )
    await callback.answer()


# ИСПРАВЛЕНО: Этот хендлер НЕ должен срабатывать для админов
@dp.message_handler(
    lambda message: message.from_user.id not in ADMIN_IDS,  # ← КЛЮЧЕВОЕ ИЗМЕНЕНИЕ!
    state=SupportStates.waiting_reply, 
    content_types=['text']
)
async def process_reply_message(message: types.Message, state: FSMContext):
    """Обработка ответа пользователя (НЕ АДМИНА!)"""
    
    data = await state.get_data()
    ticket_id = data.get('ticket_id')
    
    if not ticket_id:
        await message.answer("❌ Ошибка: тикет не найден")
        await state.finish()
        return
    
    user_message = message.text.strip()
    
    if len(user_message) < 5:
        await message.answer(
            "❌ Сообщение слишком короткое. Напишите подробнее.",
            reply_markup=get_cancel_kb()
        )
        return
    
    # Добавляем сообщение от пользователя
    success = add_support_message(ticket_id, 'user', user_message)
    
    if not success:
        await message.answer(
            "❌ Не удалось отправить сообщение. Попробуйте позже.",
            reply_markup=get_back_to_menu_kb()
        )
        await state.finish()
        return
    
    # Обновляем статус на "ожидает ответа"
    update_ticket_status(ticket_id, 'pending')
    
    await message.answer(
        f"✅ Ваше сообщение отправлено!\n\nМы ответим в ближайшее время.",
        reply_markup=get_my_tickets_kb()
    )
    
    # Уведомление админам
    ticket = get_ticket_by_id(ticket_id)
    user = message.from_user
    
    admin_text = f"""
💬 <b>Новое сообщение в тикете #{ticket_id}</b>

<b>От:</b> {user.first_name} (@{user.username or 'no_username'})
<b>User ID:</b> <code>{user.id}</code>

<b>Сообщение:</b>
{user_message}

<a href="https://adminpanelseoserm-angel2804.amvera.io/support/{ticket_id}">Открыть в админ-панели</a>
"""
    
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, admin_text)
        except Exception as e:
            logging.error(f"Не удалось отправить уведомление админу {admin_id}: {e}")
    
    await state.finish()


@dp.callback_query_handler(lambda c: c.data.startswith('close_ticket:'), state='*')
async def close_ticket(callback: types.CallbackQuery, state: FSMContext):
    """Закрытие тикета"""
    await state.finish()
    
    ticket_id = int(callback.data.split(':')[1])
    
    ticket = get_ticket_by_id(ticket_id)
    
    if not ticket or ticket['user_id'] != callback.from_user.id:
        await callback.answer("❌ Тикет не найден", show_alert=True)
        return
    
    # Закрываем тикет
    update_ticket_status(ticket_id, 'closed')
    
    text = f"""
✅ <b>Обращение #{ticket_id} закрыто</b>

Спасибо, что обратились в нашу поддержку!

Если у вас возникнут новые вопросы - создайте новое обращение.
"""
    
    try:
        await callback.message.edit_text(text, reply_markup=get_back_to_menu_kb())
    except:
        await callback.message.answer(text, reply_markup=get_back_to_menu_kb())
    
    await callback.answer("Тикет закрыт")
