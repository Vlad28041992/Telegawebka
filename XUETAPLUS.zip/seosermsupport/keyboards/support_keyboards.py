"""
Клавиатуры для бота поддержки
"""

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_main_menu_kb():
    """Главное меню с FAQ"""
    kb = InlineKeyboardMarkup(row_width=1)
    kb.add(
        InlineKeyboardButton("💰 Вывод средств", callback_data="faq_withdrawal"),
        InlineKeyboardButton("❓ Почему отзывы не проходят?", callback_data="faq_reviews"),
        InlineKeyboardButton("⏱ Сколько времени модерация?", callback_data="faq_moderation"),
        InlineKeyboardButton("✍️ Написать в техподдержку", callback_data="create_ticket")
    )
    return kb


def get_back_to_menu_kb():
    """Кнопка возврата в меню"""
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("◀️ Вернуться в меню", callback_data="back_to_menu"))
    return kb


def get_ticket_actions_kb(ticket_id, can_reply=True):
    """Действия с тикетом"""
    kb = InlineKeyboardMarkup(row_width=1)
    if can_reply:
        kb.add(InlineKeyboardButton("💬 Ответить", callback_data=f"reply_ticket:{ticket_id}"))
    kb.add(
        InlineKeyboardButton("❌ Закрыть тикет", callback_data=f"close_ticket:{ticket_id}"),
        InlineKeyboardButton("◀️ Назад к списку", callback_data="my_tickets")
    )
    return kb


def get_my_tickets_kb():
    """Кнопка просмотра моих тикетов"""
    kb = InlineKeyboardMarkup()
    kb.add(
        InlineKeyboardButton("📋 Мои обращения", callback_data="my_tickets"),
        InlineKeyboardButton("◀️ Главное меню", callback_data="back_to_menu")
    )
    return kb


def get_cancel_kb():
    """Кнопка отмены"""
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("❌ Отмена", callback_data="back_to_menu"))
    return kb
