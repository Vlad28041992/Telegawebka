"""
Состояния FSM для бота поддержки
"""

from aiogram.dispatcher.filters.state import State, StatesGroup

class SupportStates(StatesGroup):
    """Состояния для работы с поддержкой"""
    waiting_message = State()  # Ожидание сообщения от пользователя
    waiting_reply = State()    # Ожидание ответа на тикет
